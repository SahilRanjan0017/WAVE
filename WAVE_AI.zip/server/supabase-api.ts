// =====================================================
// WAVE AI - Complete Supabase Backend API
// Organized into 5 main sections
// =====================================================

import { Router } from 'express';
import { createClient } from '@supabase/supabase-js';
import { z } from 'zod';

const router = Router();

// Initialize Supabase client
const supabase = createClient(
  process.env.SUPABASE_URL || '',
  process.env.SUPABASE_SERVICE_ROLE_KEY || ''
);

// =====================================================
// SECTION 1: CORE USER MANAGEMENT
// =====================================================

// Get user profile
router.get('/api/users/profile/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    
    const { data: profile, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
    
    if (error) throw error;
    
    res.json({ success: true, data: profile });
  } catch (error) {
    console.error('Error fetching profile:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update user profile
router.put('/api/users/profile/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const { display_name, avatar_url, status_text, status_emoji, presence_status } = req.body;
    
    const { data: profile, error } = await supabase
      .from('profiles')
      .update({
        display_name,
        avatar_url,
        status_text,
        status_emoji,
        presence_status
      })
      .eq('id', userId)
      .select()
      .single();
    
    if (error) throw error;
    
    res.json({ success: true, data: profile });
  } catch (error) {
    console.error('Error updating profile:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get workspaces for user
router.get('/api/workspaces/user/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    
    const { data: workspaces, error } = await supabase
      .from('memberships')
      .select(`
        role,
        workspace:workspaces (
          id,
          name,
          brand_color,
          logo_url,
          description
        )
      `)
      .eq('user_id', userId);
    
    if (error) throw error;
    
    res.json({ success: true, data: workspaces });
  } catch (error) {
    console.error('Error fetching workspaces:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Create workspace
router.post('/api/workspaces', async (req, res) => {
  try {
    const { name, description, brand_color, created_by } = req.body;
    
    const { data: workspace, error: workspaceError } = await supabase
      .from('workspaces')
      .insert([{
        name,
        description,
        brand_color,
        created_by
      }])
      .select()
      .single();
    
    if (workspaceError) throw workspaceError;
    
    // Add creator as owner
    const { error: membershipError } = await supabase
      .from('memberships')
      .insert([{
        user_id: created_by,
        workspace_id: workspace.id,
        role: 'owner'
      }]);
    
    if (membershipError) throw membershipError;
    
    res.json({ success: true, data: workspace });
  } catch (error) {
    console.error('Error creating workspace:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// =====================================================
// SECTION 2: COMMUNICATION HUB
// =====================================================

// Get channels for workspace
router.get('/api/channels/:workspaceId', async (req, res) => {
  try {
    const { workspaceId } = req.params;
    const { userId } = req.query;
    
    const { data: channels, error } = await supabase
      .from('channels')
      .select(`
        *,
        channel_memberships!inner (
          user_id,
          role
        )
      `)
      .eq('workspace_id', workspaceId)
      .eq('channel_memberships.user_id', userId)
      .eq('is_archived', false);
    
    if (error) throw error;
    
    res.json({ success: true, data: channels });
  } catch (error) {
    console.error('Error fetching channels:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Create channel
router.post('/api/channels', async (req, res) => {
  try {
    const { workspace_id, name, description, is_private, created_by } = req.body;
    
    const { data: channel, error: channelError } = await supabase
      .from('channels')
      .insert([{
        workspace_id,
        name,
        display_name: name,
        description,
        is_private,
        created_by
      }])
      .select()
      .single();
    
    if (channelError) throw channelError;
    
    // Add creator as channel owner
    const { error: membershipError } = await supabase
      .from('channel_memberships')
      .insert([{
        channel_id: channel.id,
        user_id: created_by,
        role: 'owner'
      }]);
    
    if (membershipError) throw membershipError;
    
    res.json({ success: true, data: channel });
  } catch (error) {
    console.error('Error creating channel:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Send message
router.post('/api/messages', async (req, res) => {
  try {
    const { channel_id, dm_group_id, author_id, content, message_type, parent_message_id } = req.body;
    
    const { data: message, error } = await supabase
      .from('messages')
      .insert([{
        channel_id,
        dm_group_id,
        author_id,
        content,
        message_type: message_type || 'text',
        parent_message_id
      }])
      .select(`
        *,
        author:profiles (
          id,
          display_name,
          avatar_url
        )
      `)
      .single();
    
    if (error) throw error;
    
    res.json({ success: true, data: message });
  } catch (error) {
    console.error('Error sending message:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get messages for channel/DM
router.get('/api/messages', async (req, res) => {
  try {
    const { channel_id, dm_group_id, limit = 50, offset = 0 } = req.query;
    
    let query = supabase
      .from('messages')
      .select(`
        *,
        author:profiles (
          id,
          display_name,
          avatar_url
        ),
        attachments (
          id,
          file_url,
          file_name,
          file_type
        )
      `)
      .order('created_at', { ascending: true })
      .limit(parseInt(limit as string))
      .range(parseInt(offset as string), parseInt(offset as string) + parseInt(limit as string) - 1);
    
    if (channel_id) {
      query = query.eq('channel_id', channel_id);
    } else if (dm_group_id) {
      query = query.eq('dm_group_id', dm_group_id);
    } else {
      return res.status(400).json({ success: false, error: 'Either channel_id or dm_group_id is required' });
    }
    
    const { data: messages, error } = await query;
    
    if (error) throw error;
    
    res.json({ success: true, data: { data: messages, total: messages.length } });
  } catch (error) {
    console.error('Error fetching messages:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// =====================================================
// SECTION 3: AI COLLABORATION
// =====================================================

// Get notes for channel/DM
router.get('/api/notes/:channelId', async (req, res) => {
  try {
    const { channelId } = req.params;
    const { type = 'channel' } = req.query; // 'channel' or 'dm'
    
    const column = type === 'channel' ? 'channel_id' : 'dm_group_id';
    
    const { data: note, error } = await supabase
      .from('notes')
      .select('*')
      .eq(column, channelId)
      .single();
    
    if (error && error.code !== 'PGRST116') throw error; // PGRST116 is "not found"
    
    res.json({ success: true, data: note || { content: '', channel_id: channelId } });
  } catch (error) {
    console.error('Error fetching notes:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Create or update notes
router.post('/api/notes', async (req, res) => {
  try {
    const { channel_id, dm_group_id, content, created_by } = req.body;
    
    const column = channel_id ? 'channel_id' : 'dm_group_id';
    const value = channel_id || dm_group_id;
    
    // Check if note exists
    const { data: existingNote } = await supabase
      .from('notes')
      .select('id')
      .eq(column, value)
      .single();
    
    let result;
    
    if (existingNote) {
      // Update existing note
      result = await supabase
        .from('notes')
        .update({ content })
        .eq('id', existingNote.id)
        .select()
        .single();
    } else {
      // Create new note
      result = await supabase
        .from('notes')
        .insert([{
          channel_id,
          dm_group_id,
          content,
          created_by
        }])
        .select()
        .single();
    }
    
    if (result.error) throw result.error;
    
    res.json({ success: true, data: result.data });
  } catch (error) {
    console.error('Error saving notes:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Create whiteboard
router.post('/api/whiteboards', async (req, res) => {
  try {
    const { workspace_id, channel_id, dm_group_id, name, description, board_data, created_by } = req.body;
    
    const { data: whiteboard, error } = await supabase
      .from('whiteboards')
      .insert([{
        workspace_id,
        channel_id,
        dm_group_id,
        name,
        description,
        board_data,
        created_by,
        collaborators: [created_by]
      }])
      .select()
      .single();
    
    if (error) throw error;
    
    res.json({ success: true, data: whiteboard });
  } catch (error) {
    console.error('Error creating whiteboard:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update whiteboard
router.put('/api/whiteboards/:whiteboardId', async (req, res) => {
  try {
    const { whiteboardId } = req.params;
    const { name, description, board_data, thumbnail_url } = req.body;
    
    const { data: whiteboard, error } = await supabase
      .from('whiteboards')
      .update({
        name,
        description,
        board_data,
        thumbnail_url,
        version: supabase.sql`version + 1`
      })
      .eq('id', whiteboardId)
      .select()
      .single();
    
    if (error) throw error;
    
    res.json({ success: true, data: whiteboard });
  } catch (error) {
    console.error('Error updating whiteboard:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get whiteboards for workspace/channel
router.get('/api/whiteboards', async (req, res) => {
  try {
    const { workspace_id, channel_id, dm_group_id } = req.query;
    
    let query = supabase
      .from('whiteboards')
      .select(`
        *,
        creator:profiles!created_by (
          id,
          display_name,
          avatar_url
        )
      `)
      .order('updated_at', { ascending: false });
    
    if (workspace_id) query = query.eq('workspace_id', workspace_id);
    if (channel_id) query = query.eq('channel_id', channel_id);
    if (dm_group_id) query = query.eq('dm_group_id', dm_group_id);
    
    const { data: whiteboards, error } = await query;
    
    if (error) throw error;
    
    res.json({ success: true, data: whiteboards });
  } catch (error) {
    console.error('Error fetching whiteboards:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Create meeting
router.post('/api/meetings', async (req, res) => {
  try {
    const { workspace_id, channel_id, host_id, title, description, start_time, meeting_type } = req.body;
    
    const { data: meeting, error } = await supabase
      .from('meetings')
      .insert([{
        workspace_id,
        channel_id,
        host_id,
        title,
        description,
        start_time,
        meeting_type: meeting_type || 'instant',
        status: 'scheduled'
      }])
      .select()
      .single();
    
    if (error) throw error;
    
    res.json({ success: true, data: meeting });
  } catch (error) {
    console.error('Error creating meeting:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// =====================================================
// SECTION 4: WORKFLOW & AUTOMATION
// =====================================================

// Get action items
router.get('/api/action-items', async (req, res) => {
  try {
    const { workspace_id, assigned_to, status } = req.query;
    
    let query = supabase
      .from('action_items')
      .select(`
        *,
        assignee:profiles!assigned_to (
          id,
          display_name,
          avatar_url
        ),
        creator:profiles!created_by (
          id,
          display_name
        )
      `)
      .order('created_at', { ascending: false });
    
    if (workspace_id) query = query.eq('workspace_id', workspace_id);
    if (assigned_to) query = query.eq('assigned_to', assigned_to);
    if (status) query = query.eq('status', status);
    
    const { data: actionItems, error } = await query;
    
    if (error) throw error;
    
    res.json({ success: true, data: actionItems });
  } catch (error) {
    console.error('Error fetching action items:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Create action item
router.post('/api/action-items', async (req, res) => {
  try {
    const { 
      workspace_id, 
      channel_id, 
      meeting_id, 
      message_id, 
      assigned_to, 
      created_by, 
      title, 
      description, 
      priority, 
      due_date 
    } = req.body;
    
    const { data: actionItem, error } = await supabase
      .from('action_items')
      .insert([{
        workspace_id,
        channel_id,
        meeting_id,
        message_id,
        assigned_to,
        created_by,
        title,
        description,
        priority: priority || 'medium',
        due_date
      }])
      .select(`
        *,
        assignee:profiles!assigned_to (
          id,
          display_name,
          avatar_url
        )
      `)
      .single();
    
    if (error) throw error;
    
    res.json({ success: true, data: actionItem });
  } catch (error) {
    console.error('Error creating action item:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update action item
router.put('/api/action-items/:actionItemId', async (req, res) => {
  try {
    const { actionItemId } = req.params;
    const { status, title, description, priority, due_date } = req.body;
    
    const updateData: any = {};
    if (status !== undefined) updateData.status = status;
    if (title !== undefined) updateData.title = title;
    if (description !== undefined) updateData.description = description;
    if (priority !== undefined) updateData.priority = priority;
    if (due_date !== undefined) updateData.due_date = due_date;
    
    if (status === 'completed') {
      updateData.completed_at = new Date().toISOString();
    }
    
    const { data: actionItem, error } = await supabase
      .from('action_items')
      .update(updateData)
      .eq('id', actionItemId)
      .select()
      .single();
    
    if (error) throw error;
    
    res.json({ success: true, data: actionItem });
  } catch (error) {
    console.error('Error updating action item:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get workflows
router.get('/api/workflows', async (req, res) => {
  try {
    const { workspace_id } = req.query;
    
    const { data: workflows, error } = await supabase
      .from('workflows')
      .select(`
        *,
        creator:profiles!created_by (
          id,
          display_name
        )
      `)
      .eq('workspace_id', workspace_id)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    
    res.json({ success: true, data: workflows });
  } catch (error) {
    console.error('Error fetching workflows:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Create workflow
router.post('/api/workflows', async (req, res) => {
  try {
    const { workspace_id, created_by, name, description, trigger_type, trigger_config, actions } = req.body;
    
    const { data: workflow, error } = await supabase
      .from('workflows')
      .insert([{
        workspace_id,
        created_by,
        name,
        description,
        trigger_type,
        trigger_config,
        actions
      }])
      .select()
      .single();
    
    if (error) throw error;
    
    res.json({ success: true, data: workflow });
  } catch (error) {
    console.error('Error creating workflow:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// =====================================================
// SECTION 5: ENTERPRISE CONTROL
// =====================================================

// Get notifications
router.get('/api/notifications/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const { limit = 50, unread_only = false } = req.query;
    
    let query = supabase
      .from('notifications')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(parseInt(limit as string));
    
    if (unread_only === 'true') {
      query = query.eq('read', false);
    }
    
    const { data: notifications, error } = await query;
    
    if (error) throw error;
    
    res.json({ success: true, data: notifications });
  } catch (error) {
    console.error('Error fetching notifications:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Mark notification as read
router.put('/api/notifications/:notificationId/read', async (req, res) => {
  try {
    const { notificationId } = req.params;
    
    const { data: notification, error } = await supabase
      .from('notifications')
      .update({ 
        read: true, 
        read_at: new Date().toISOString() 
      })
      .eq('id', notificationId)
      .select()
      .single();
    
    if (error) throw error;
    
    res.json({ success: true, data: notification });
  } catch (error) {
    console.error('Error updating notification:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Create audit log
router.post('/api/audit-logs', async (req, res) => {
  try {
    const { workspace_id, user_id, action, resource_type, resource_id, details, ip_address, user_agent } = req.body;
    
    const { data: auditLog, error } = await supabase
      .from('audit_logs')
      .insert([{
        workspace_id,
        user_id,
        action,
        resource_type,
        resource_id,
        details,
        ip_address,
        user_agent
      }])
      .select()
      .single();
    
    if (error) throw error;
    
    res.json({ success: true, data: auditLog });
  } catch (error) {
    console.error('Error creating audit log:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get workspace analytics
router.get('/api/analytics/:workspaceId', async (req, res) => {
  try {
    const { workspaceId } = req.params;
    
    // Get message count by day for last 30 days
    const { data: messageStats, error: messageError } = await supabase
      .rpc('get_message_stats', { workspace_id: workspaceId });
    
    // Get active user count
    const { data: activeUsers, error: userError } = await supabase
      .from('profiles')
      .select('id')
      .eq('presence_status', 'online');
    
    // Get channel count
    const { data: channels, error: channelError } = await supabase
      .from('channels')
      .select('id')
      .eq('workspace_id', workspaceId)
      .eq('is_archived', false);
    
    if (messageError || userError || channelError) {
      throw messageError || userError || channelError;
    }
    
    const analytics = {
      message_stats: messageStats || [],
      active_users_count: activeUsers?.length || 0,
      channels_count: channels?.length || 0,
      generated_at: new Date().toISOString()
    };
    
    res.json({ success: true, data: analytics });
  } catch (error) {
    console.error('Error fetching analytics:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

export default router;
