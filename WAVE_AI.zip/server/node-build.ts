import { createServer } from "./index";
import WebSocketManager from "./websocket";
import { createServer as createHttpServer } from 'http';

const app = createServer();
const server = createHttpServer(app);

// Initialize WebSocket manager
const wsManager = new WebSocketManager(server);

// Make WebSocket manager available to routes
(app as any).wsManager = wsManager;

const port = process.env.PORT || 8080;

server.listen(port, () => {
  console.log(`🚀 Server running on port ${port}`);
  console.log(`📡 WebSocket server ready for real-time communication`);
});
