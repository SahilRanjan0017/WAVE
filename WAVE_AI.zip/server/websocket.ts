import { WebSocketServer, WebSocket } from 'ws';
import { IncomingMessage } from 'http';
import { User, Message, DirectMessage } from '@shared/api';

interface AuthenticatedWebSocket extends WebSocket {
  userId?: string;
  user?: User;
}

interface WebSocketMessage {
  type: 'message' | 'typing' | 'presence' | 'reaction' | 'thread_reply' | 'user_status' | 'join_channel' | 'leave_channel';
  data: any;
  channelId?: string;
  userId?: string;
}

class WebSocketManager {
  private wss: WebSocketServer;
  private clients: Map<string, AuthenticatedWebSocket> = new Map();
  private channelSubscriptions: Map<string, Set<string>> = new Map(); // channelId -> Set of userIds
  private userPresence: Map<string, { status: 'online' | 'away' | 'offline', lastSeen: Date }> = new Map();

  constructor(server: any) {
    this.wss = new WebSocketServer({ server });
    this.setupWebSocketServer();
  }

  private setupWebSocketServer() {
    this.wss.on('connection', (ws: AuthenticatedWebSocket, request: IncomingMessage) => {
      console.log('New WebSocket connection from:', request.socket.remoteAddress);

      ws.on('message', (data: Buffer) => {
        try {
          const messageStr = data.toString();
          console.log('Received WebSocket message:', messageStr);
          const message = JSON.parse(messageStr);
          this.handleMessage(ws, message);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error, 'Raw data:', data.toString());
          // Send error response back to client
          try {
            ws.send(JSON.stringify({
              type: 'error',
              data: { message: 'Invalid message format' }
            }));
          } catch (sendError) {
            console.error('Failed to send error response:', sendError);
          }
        }
      });

      ws.on('close', (code: number, reason: Buffer) => {
        console.log('WebSocket connection closed:', { code, reason: reason.toString(), userId: ws.userId });
        if (ws.userId) {
          this.handleUserDisconnect(ws.userId);
        }
      });

      ws.on('error', (error: Error) => {
        console.error('WebSocket connection error:', {
          error: error.message,
          stack: error.stack,
          userId: ws.userId
        });
      });

      // Send welcome message
      try {
        ws.send(JSON.stringify({
          type: 'connected',
          data: { message: 'WebSocket connection established' }
        }));
      } catch (error) {
        console.error('Failed to send welcome message:', error);
      }
    });

    this.wss.on('error', (error: Error) => {
      console.error('WebSocket Server error:', error);
    });
  }

  private handleMessage(ws: AuthenticatedWebSocket, message: any) {
    try {
      if (!message || typeof message !== 'object') {
        console.error('Invalid message format:', message);
        return;
      }

      switch (message.type) {
        case 'authenticate':
          this.authenticateConnection(ws, message.data);
          break;
        case 'join_channel':
          if (ws.userId && message.data?.channelId) {
            this.joinChannel(ws.userId, message.data.channelId);
          }
          break;
        case 'leave_channel':
          if (ws.userId && message.data?.channelId) {
            this.leaveChannel(ws.userId, message.data.channelId);
          }
          break;
        case 'typing':
          if (ws.userId && message.data?.channelId !== undefined && message.data?.isTyping !== undefined) {
            this.broadcastTyping(ws.userId, message.data.channelId, message.data.isTyping);
          }
          break;
        case 'presence':
          if (ws.userId && message.data?.status) {
            this.updateUserPresence(ws.userId, message.data.status);
          }
          break;
        case 'user_status':
          if (ws.userId && message.data) {
            this.updateUserStatus(ws.userId, message.data);
          }
          break;
        default:
          console.log('Unknown message type:', message.type, 'Full message:', message);
      }
    } catch (error) {
      console.error('Error handling WebSocket message:', error, 'Message:', message);
    }
  }

  private authenticateConnection(ws: AuthenticatedWebSocket, authData: { token: string, user: User }) {
    // In production, verify the token properly
    ws.userId = authData.user.id;
    ws.user = authData.user;
    this.clients.set(authData.user.id, ws);
    
    // Set user as online
    this.userPresence.set(authData.user.id, { status: 'online', lastSeen: new Date() });
    
    // Broadcast user presence to all users
    this.broadcastUserPresence(authData.user.id, 'online');

    ws.send(JSON.stringify({
      type: 'authenticated',
      data: { success: true }
    }));
  }

  private joinChannel(userId: string, channelId: string) {
    if (!this.channelSubscriptions.has(channelId)) {
      this.channelSubscriptions.set(channelId, new Set());
    }
    this.channelSubscriptions.get(channelId)!.add(userId);
  }

  private leaveChannel(userId: string, channelId: string) {
    if (this.channelSubscriptions.has(channelId)) {
      this.channelSubscriptions.get(channelId)!.delete(userId);
    }
  }

  private broadcastTyping(userId: string, channelId: string, isTyping: boolean) {
    const user = this.clients.get(userId)?.user;
    if (!user) return;

    this.broadcastToChannel(channelId, {
      type: 'typing',
      data: {
        userId,
        user: user,
        isTyping,
        channelId
      }
    }, userId);
  }

  private updateUserPresence(userId: string, status: 'online' | 'away' | 'offline') {
    this.userPresence.set(userId, { status, lastSeen: new Date() });
    this.broadcastUserPresence(userId, status);
  }

  private updateUserStatus(userId: string, statusData: { emoji?: string, text?: string }) {
    const user = this.clients.get(userId)?.user;
    if (!user) return;

    // Broadcast user status update to all connected users
    this.broadcastToAll({
      type: 'user_status_update',
      data: {
        userId,
        status: statusData
      }
    });
  }

  private broadcastUserPresence(userId: string, status: string) {
    this.broadcastToAll({
      type: 'presence_update',
      data: {
        userId,
        status,
        timestamp: new Date().toISOString()
      }
    });
  }

  private handleUserDisconnect(userId: string) {
    this.clients.delete(userId);
    this.userPresence.set(userId, { status: 'offline', lastSeen: new Date() });
    this.broadcastUserPresence(userId, 'offline');

    // Remove from all channel subscriptions
    for (const [channelId, subscribers] of this.channelSubscriptions.entries()) {
      subscribers.delete(userId);
    }
  }

  // Public methods for broadcasting from HTTP endpoints
  public broadcastNewMessage(message: Message | DirectMessage) {
    if ('channel_id' in message && message.channel_id) {
      // Channel message
      this.broadcastToChannel(message.channel_id, {
        type: 'new_message',
        data: message
      });
    } else if ('receiver_id' in message) {
      // Direct message - send to both sender and receiver
      const dm = message as DirectMessage;
      [dm.sender_id, dm.receiver_id].forEach(userId => {
        const client = this.clients.get(userId);
        if (client && client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({
            type: 'new_direct_message',
            data: message
          }));
        }
      });
    }
  }

  public broadcastMessageReaction(messageId: string, channelId: string, reaction: any) {
    this.broadcastToChannel(channelId, {
      type: 'message_reaction',
      data: {
        messageId,
        reaction
      }
    });
  }

  public broadcastChannelUpdate(channelId: string, updateData: any) {
    this.broadcastToChannel(channelId, {
      type: 'channel_update',
      data: updateData
    });
  }

  private broadcastToChannel(channelId: string, message: any, excludeUserId?: string) {
    const subscribers = this.channelSubscriptions.get(channelId);
    if (!subscribers) return;

    subscribers.forEach(userId => {
      if (userId === excludeUserId) return;
      
      const client = this.clients.get(userId);
      if (client && client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
  }

  private broadcastToAll(message: any, excludeUserId?: string) {
    this.clients.forEach((client, userId) => {
      if (userId === excludeUserId) return;
      
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
  }

  public getUserPresence(userId: string) {
    return this.userPresence.get(userId) || { status: 'offline', lastSeen: new Date() };
  }

  public getOnlineUsers(): string[] {
    const onlineUsers: string[] = [];
    this.userPresence.forEach((presence, userId) => {
      if (presence.status === 'online') {
        onlineUsers.push(userId);
      }
    });
    return onlineUsers;
  }
}

export default WebSocketManager;
