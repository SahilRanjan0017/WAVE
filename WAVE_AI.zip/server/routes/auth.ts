import { RequestHandler } from "express";
import { z } from "zod";
import { LoginRequest, SignupRequest, AuthResponse, ApiResponse, User } from "@shared/api";

// Mock database - In production, use a real database
const users: User[] = [
  {
    id: "1",
    email: "sahil@example.com",
    username: "sahil",
    full_name: "Sahil Ranjan",
    avatar_url: "",
    status: "online",
    created_at: new Date().toISOString()
  }
];

const sessions: Map<string, string> = new Map(); // token -> user_id

// Validation schemas
const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6)
});

const signupSchema = z.object({
  email: z.string().email(),
  username: z.string().min(3).max(20),
  full_name: z.string().min(1),
  password: z.string().min(6)
});

// Helper functions
const generateToken = (): string => {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
};

const findUserByEmail = (email: string): User | undefined => {
  return users.find(user => user.email === email);
};

const findUserById = (id: string): User | undefined => {
  return users.find(user => user.id === id);
};

// Route handlers
export const login: RequestHandler = (req, res) => {
  try {
    const validation = loginSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid input",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const { email, password } = validation.data as LoginRequest;
    
    // Simple auth check (in production, use proper password hashing)
    const user = findUserByEmail(email);
    if (!user || password !== "password") {
      return res.status(401).json({
        success: false,
        error: "Invalid credentials"
      } as ApiResponse);
    }

    const token = generateToken();
    sessions.set(token, user.id);

    res.json({
      success: true,
      data: { user, token }
    } as ApiResponse<AuthResponse>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const signup: RequestHandler = (req, res) => {
  try {
    const validation = signupSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid input",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const { email, username, full_name } = validation.data as SignupRequest;

    // Check if user already exists
    if (findUserByEmail(email)) {
      return res.status(400).json({
        success: false,
        error: "User already exists"
      } as ApiResponse);
    }

    // Create new user
    const newUser: User = {
      id: Date.now().toString(),
      email,
      username,
      full_name,
      avatar_url: "",
      status: "online",
      created_at: new Date().toISOString()
    };

    users.push(newUser);

    const token = generateToken();
    sessions.set(token, newUser.id);

    res.status(201).json({
      success: true,
      data: { user: newUser, token }
    } as ApiResponse<AuthResponse>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const logout: RequestHandler = (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (token) {
      sessions.delete(token);
    }

    res.json({
      success: true,
      message: "Logged out successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getProfile: RequestHandler = (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({
        success: false,
        error: "No token provided"
      } as ApiResponse);
    }

    const userId = sessions.get(token);
    if (!userId) {
      return res.status(401).json({
        success: false,
        error: "Invalid token"
      } as ApiResponse);
    }

    const user = findUserById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        error: "User not found"
      } as ApiResponse);
    }

    res.json({
      success: true,
      data: user
    } as ApiResponse<User>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

// Middleware to authenticate requests
export const authenticateToken: RequestHandler = (req, res, next) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) {
    return res.status(401).json({
      success: false,
      error: "No token provided"
    } as ApiResponse);
  }

  const userId = sessions.get(token);
  if (!userId) {
    return res.status(401).json({
      success: false,
      error: "Invalid token"
    } as ApiResponse);
  }

  const user = findUserById(userId);
  if (!user) {
    return res.status(401).json({
      success: false,
      error: "User not found"
    } as ApiResponse);
  }

  // Add user to request object
  (req as any).user = user;
  next();
};
