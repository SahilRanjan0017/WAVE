import { RequestHandler } from "express";
import { z } from "zod";
import { SearchRequest, SearchResult, ApiResponse, User } from "@shared/api";

// Mock data (in production, this would come from your database)
const mockUsers: User[] = [
  {
    id: "1",
    email: "sahil@example.com",
    username: "sahil",
    full_name: "Sahil Ranjan",
    avatar_url: "",
    status: "online",
    created_at: new Date().toISOString()
  },
  {
    id: "2",
    email: "alice@example.com",
    username: "alice",
    full_name: "Alice Johnson",
    avatar_url: "",
    status: "away",
    created_at: new Date().toISOString()
  },
  {
    id: "3",
    email: "bob@example.com",
    username: "bob",
    full_name: "Bob Smith",
    avatar_url: "",
    status: "offline",
    created_at: new Date().toISOString()
  }
];

const mockChannels = [
  { id: "general", name: "general", description: "General discussion" },
  { id: "random", name: "random", description: "Random topics and fun" },
  { id: "design-team", name: "design-team", description: "Design team discussions" },
  { id: "development", name: "development", description: "Development discussions" }
];

const mockMessages = [
  {
    id: "1",
    content: "Welcome to the workspace! Let's build something amazing together.",
    sender_id: "1",
    channel_id: "general",
    created_at: new Date(Date.now() - 3600000).toISOString()
  },
  {
    id: "2",
    content: "Has anyone seen the new design mockups? They look fantastic!",
    sender_id: "2",
    channel_id: "design-team",
    created_at: new Date(Date.now() - 7200000).toISOString()
  },
  {
    id: "3",
    content: "The development environment setup is complete. Ready to start coding!",
    sender_id: "3",
    channel_id: "development",
    created_at: new Date(Date.now() - 10800000).toISOString()
  }
];

// Validation schema
const searchSchema = z.object({
  query: z.string().min(1),
  type: z.enum(['messages', 'channels', 'users', 'all']).default('all'),
  limit: z.number().min(1).max(100).default(20)
});

export const search: RequestHandler = (req, res) => {
  try {
    const validation = searchSchema.safeParse(req.query);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid input",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const { query, type, limit } = validation.data as SearchRequest;
    const results: SearchResult[] = [];
    const queryLower = query.toLowerCase();

    // Search messages
    if (type === 'all' || type === 'messages') {
      const messageResults = mockMessages
        .filter(message => message.content.toLowerCase().includes(queryLower))
        .map(message => ({
          type: 'message' as const,
          id: message.id,
          title: `Message in #${mockChannels.find(c => c.id === message.channel_id)?.name || 'unknown'}`,
          content: message.content,
          created_at: message.created_at
        }));
      results.push(...messageResults);
    }

    // Search channels
    if (type === 'all' || type === 'channels') {
      const channelResults = mockChannels
        .filter(channel => 
          channel.name.toLowerCase().includes(queryLower) ||
          (channel.description && channel.description.toLowerCase().includes(queryLower))
        )
        .map(channel => ({
          type: 'channel' as const,
          id: channel.id,
          title: `#${channel.name}`,
          content: channel.description || '',
          created_at: new Date().toISOString()
        }));
      results.push(...channelResults);
    }

    // Search users
    if (type === 'all' || type === 'users') {
      const userResults = mockUsers
        .filter(user => 
          user.full_name.toLowerCase().includes(queryLower) ||
          user.username.toLowerCase().includes(queryLower) ||
          user.email.toLowerCase().includes(queryLower)
        )
        .map(user => ({
          type: 'user' as const,
          id: user.id,
          title: user.full_name,
          content: `@${user.username}`,
          avatar_url: user.avatar_url,
          created_at: user.created_at
        }));
      results.push(...userResults);
    }

    // Sort by relevance (simple: exact matches first, then partial matches)
    const sortedResults = results
      .sort((a, b) => {
        const aExact = a.title.toLowerCase() === queryLower || a.content.toLowerCase() === queryLower;
        const bExact = b.title.toLowerCase() === queryLower || b.content.toLowerCase() === queryLower;
        
        if (aExact && !bExact) return -1;
        if (!aExact && bExact) return 1;
        
        // Sort by creation date for same relevance
        return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      })
      .slice(0, limit);

    res.json({
      success: true,
      data: sortedResults
    } as ApiResponse<SearchResult[]>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getSearchSuggestions: RequestHandler = (req, res) => {
  try {
    const { query } = req.query;
    
    if (!query || typeof query !== 'string' || query.length < 2) {
      return res.json({
        success: true,
        data: []
      } as ApiResponse<string[]>);
    }

    const queryLower = query.toLowerCase();
    const suggestions: string[] = [];

    // Channel suggestions
    mockChannels.forEach(channel => {
      if (channel.name.toLowerCase().includes(queryLower)) {
        suggestions.push(`#${channel.name}`);
      }
    });

    // User suggestions
    mockUsers.forEach(user => {
      if (user.username.toLowerCase().includes(queryLower) || 
          user.full_name.toLowerCase().includes(queryLower)) {
        suggestions.push(`@${user.username}`);
      }
    });

    // Common search terms
    const commonTerms = ['messages', 'files', 'today', 'yesterday', 'this week'];
    commonTerms.forEach(term => {
      if (term.includes(queryLower)) {
        suggestions.push(term);
      }
    });

    res.json({
      success: true,
      data: suggestions.slice(0, 5) // Limit to 5 suggestions
    } as ApiResponse<string[]>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};
