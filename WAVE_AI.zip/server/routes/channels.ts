import { RequestHandler } from "express";
import { z } from "zod";
import { 
  Channel, 
  CreateChannelRequest, 
  JoinChannelRequest, 
  InviteToChannelRequest,
  ApiResponse, 
  User 
} from "@shared/api";

// Mock database
let channels: Channel[] = [
  {
    id: 'general',
    name: 'all-new-workspace',
    workspace_id: 'default',
    created_by: '1',
    created_at: new Date().toISOString(),
    is_private: false,
    description: 'General workspace discussion',
    topic: 'Welcome to the workspace!',
    member_count: 1,
    unread_count: 0,
    is_member: true,
    is_archived: false
  },
  {
    id: 'new-channel',
    name: 'new-channel',
    workspace_id: 'default',
    created_by: '1',
    created_at: new Date().toISOString(),
    is_private: false,
    description: 'A new channel for discussions',
    member_count: 1,
    unread_count: 0,
    is_member: true,
    is_archived: false
  },
  {
    id: 'social',
    name: 'social',
    workspace_id: 'default',
    created_by: '1',
    created_at: new Date().toISOString(),
    is_private: false,
    description: 'Social discussions and casual chat',
    member_count: 1,
    unread_count: 0,
    is_member: true,
    is_archived: false
  }
];

let channelMembers: Map<string, Set<string>> = new Map();

// Initialize default memberships
channelMembers.set('general', new Set(['1']));
channelMembers.set('new-channel', new Set(['1']));
channelMembers.set('social', new Set(['1']));

// Validation schemas
const createChannelSchema = z.object({
  name: z.string().min(1).max(21).regex(/^[a-z0-9\-_]+$/, "Channel name can only contain lowercase letters, numbers, hyphens, and underscores"),
  workspace_id: z.string(),
  description: z.string().max(250).optional(),
  topic: z.string().max(250).optional(),
  purpose: z.string().max(250).optional(),
  is_private: z.boolean().default(false)
});

const joinChannelSchema = z.object({
  channel_id: z.string()
});

const inviteToChannelSchema = z.object({
  channel_id: z.string(),
  user_ids: z.array(z.string())
});

export const getChannels: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    
    // Filter channels where user is a member or public channels
    const userChannels = channels.filter(channel => {
      const members = channelMembers.get(channel.id) || new Set();
      return members.has(user.id) || !channel.is_private;
    }).map(channel => {
      const members = channelMembers.get(channel.id) || new Set();
      return {
        ...channel,
        is_member: members.has(user.id),
        member_count: members.size
      };
    });

    res.json({
      success: true,
      data: userChannels
    } as ApiResponse<Channel[]>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const createChannel: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = createChannelSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid input",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const channelData = validation.data as CreateChannelRequest;

    // Check if channel name already exists
    const existingChannel = channels.find(c => c.name.toLowerCase() === channelData.name.toLowerCase());
    if (existingChannel) {
      return res.status(400).json({
        success: false,
        error: "A channel with this name already exists"
      } as ApiResponse);
    }

    const newChannel: Channel = {
      id: Date.now().toString(),
      name: channelData.name,
      workspace_id: channelData.workspace_id,
      created_by: user.id,
      created_at: new Date().toISOString(),
      is_private: channelData.is_private || false,
      description: channelData.description,
      topic: channelData.topic,
      purpose: channelData.purpose,
      member_count: 1,
      unread_count: 0,
      is_member: true,
      is_archived: false
    };

    channels.push(newChannel);
    
    // Add creator as first member
    channelMembers.set(newChannel.id, new Set([user.id]));

    // Broadcast channel creation
    const wsManager = (req as any).app?.wsManager;
    if (wsManager) {
      wsManager.broadcastChannelUpdate(newChannel.id, {
        type: 'channel_created',
        channel: newChannel
      });
    }

    res.status(201).json({
      success: true,
      data: newChannel
    } as ApiResponse<Channel>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const joinChannel: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = joinChannelSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid input",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const { channel_id } = validation.data as JoinChannelRequest;

    const channel = channels.find(c => c.id === channel_id);
    if (!channel) {
      return res.status(404).json({
        success: false,
        error: "Channel not found"
      } as ApiResponse);
    }

    if (channel.is_private) {
      return res.status(403).json({
        success: false,
        error: "Cannot join private channel without invitation"
      } as ApiResponse);
    }

    const members = channelMembers.get(channel_id) || new Set();
    
    if (members.has(user.id)) {
      return res.status(400).json({
        success: false,
        error: "You are already a member of this channel"
      } as ApiResponse);
    }

    members.add(user.id);
    channelMembers.set(channel_id, members);

    // Update channel member count
    const channelIndex = channels.findIndex(c => c.id === channel_id);
    if (channelIndex !== -1) {
      channels[channelIndex].member_count = members.size;
    }

    // Broadcast user joined channel
    const wsManager = (req as any).app?.wsManager;
    if (wsManager) {
      wsManager.broadcastChannelUpdate(channel_id, {
        type: 'user_joined',
        user: user,
        channel: channel
      });
    }

    res.json({
      success: true,
      message: "Successfully joined channel"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const leaveChannel: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { channelId } = req.params;

    const channel = channels.find(c => c.id === channelId);
    if (!channel) {
      return res.status(404).json({
        success: false,
        error: "Channel not found"
      } as ApiResponse);
    }

    const members = channelMembers.get(channelId) || new Set();
    
    if (!members.has(user.id)) {
      return res.status(400).json({
        success: false,
        error: "You are not a member of this channel"
      } as ApiResponse);
    }

    // Don't allow leaving general channel
    if (channelId === 'general') {
      return res.status(400).json({
        success: false,
        error: "Cannot leave the general channel"
      } as ApiResponse);
    }

    members.delete(user.id);
    channelMembers.set(channelId, members);

    // Update channel member count
    const channelIndex = channels.findIndex(c => c.id === channelId);
    if (channelIndex !== -1) {
      channels[channelIndex].member_count = members.size;
    }

    // Broadcast user left channel
    const wsManager = (req as any).app?.wsManager;
    if (wsManager) {
      wsManager.broadcastChannelUpdate(channelId, {
        type: 'user_left',
        user: user,
        channel: channel
      });
    }

    res.json({
      success: true,
      message: "Successfully left channel"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getChannelMembers: RequestHandler = (req, res) => {
  try {
    const { channelId } = req.params;
    
    const channel = channels.find(c => c.id === channelId);
    if (!channel) {
      return res.status(404).json({
        success: false,
        error: "Channel not found"
      } as ApiResponse);
    }

    const memberIds = Array.from(channelMembers.get(channelId) || new Set());
    
    // In a real app, fetch user details from database
    // For now, return mock data
    const members = memberIds.map(id => ({
      id,
      username: `user${id}`,
      full_name: `User ${id}`,
      email: `user${id}@example.com`,
      status: 'online' as const,
      created_at: new Date().toISOString()
    }));

    res.json({
      success: true,
      data: members
    } as ApiResponse<User[]>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const updateChannelTopic: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { channelId } = req.params;
    const { topic } = req.body;

    if (!topic || topic.length > 250) {
      return res.status(400).json({
        success: false,
        error: "Topic must be between 1 and 250 characters"
      } as ApiResponse);
    }

    const channelIndex = channels.findIndex(c => c.id === channelId);
    if (channelIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Channel not found"
      } as ApiResponse);
    }

    // Check if user is member
    const members = channelMembers.get(channelId) || new Set();
    if (!members.has(user.id)) {
      return res.status(403).json({
        success: false,
        error: "You must be a member to update the topic"
      } as ApiResponse);
    }

    channels[channelIndex].topic = topic;

    // Broadcast topic update
    const wsManager = (req as any).app?.wsManager;
    if (wsManager) {
      wsManager.broadcastChannelUpdate(channelId, {
        type: 'topic_updated',
        topic: topic,
        updated_by: user
      });
    }

    res.json({
      success: true,
      data: channels[channelIndex]
    } as ApiResponse<Channel>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};
