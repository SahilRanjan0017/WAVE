import { RequestHandler } from "express";
import { FileUpload, ApiResponse, User } from "@shared/api";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = 'uploads/';
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    // Allow common file types
    const allowedTypes = /jpeg|jpg|png|gif|pdf|doc|docx|txt|mp3|mp4|mov|avi/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);

    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only images, documents, and media files are allowed.'));
    }
  }
});

// Mock database for file records
let files: FileUpload[] = [];

export const uploadFile = [
  upload.single('file'),
  ((req, res) => {
    try {
      const user = (req as any).user as User;
      const file = req.file;

      if (!file) {
        return res.status(400).json({
          success: false,
          error: "No file uploaded"
        } as ApiResponse);
      }

      const fileRecord: FileUpload = {
        id: Date.now().toString(),
        name: file.originalname,
        size: file.size,
        type: file.mimetype,
        url: `/api/files/download/${file.filename}`,
        uploaded_by: user.id,
        created_at: new Date().toISOString()
      };

      // Generate thumbnail for images
      if (file.mimetype.startsWith('image/')) {
        fileRecord.thumbnail_url = `/api/files/thumbnail/${file.filename}`;
      }

      files.push(fileRecord);

      res.status(201).json({
        success: true,
        data: fileRecord
      } as ApiResponse<FileUpload>);
    } catch (error) {
      res.status(500).json({
        success: false,
        error: "File upload failed"
      } as ApiResponse);
    }
  }) as RequestHandler
];

export const downloadFile: RequestHandler = (req, res) => {
  try {
    const { filename } = req.params;
    const filePath = path.join('uploads', filename);

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({
        success: false,
        error: "File not found"
      } as ApiResponse);
    }

    res.download(filePath);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Download failed"
    } as ApiResponse);
  }
};

export const getFileInfo: RequestHandler = (req, res) => {
  try {
    const { fileId } = req.params;
    
    const file = files.find(f => f.id === fileId);
    if (!file) {
      return res.status(404).json({
        success: false,
        error: "File not found"
      } as ApiResponse);
    }

    res.json({
      success: true,
      data: file
    } as ApiResponse<FileUpload>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const deleteFile: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { fileId } = req.params;
    
    const fileIndex = files.findIndex(f => f.id === fileId);
    if (fileIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "File not found"
      } as ApiResponse);
    }

    const file = files[fileIndex];
    
    // Check if user owns the file
    if (file.uploaded_by !== user.id) {
      return res.status(403).json({
        success: false,
        error: "You can only delete your own files"
      } as ApiResponse);
    }

    // Delete file from filesystem
    const filename = file.url.split('/').pop();
    const filePath = path.join('uploads', filename!);
    
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }

    // Remove from database
    files.splice(fileIndex, 1);

    res.json({
      success: true,
      message: "File deleted successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getUserFiles: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;

    const userFiles = files
      .filter(f => f.uploaded_by === user.id)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedFiles = userFiles.slice(startIndex, endIndex);

    res.json({
      success: true,
      data: {
        data: paginatedFiles,
        page,
        limit,
        total: userFiles.length,
        has_more: endIndex < userFiles.length
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

// Serve static files
export const serveFile: RequestHandler = (req, res) => {
  try {
    const { filename } = req.params;
    const filePath = path.join('uploads', filename);

    if (!fs.existsSync(filePath)) {
      return res.status(404).send('File not found');
    }

    res.sendFile(path.resolve(filePath));
  } catch (error) {
    res.status(500).send('Server error');
  }
};
