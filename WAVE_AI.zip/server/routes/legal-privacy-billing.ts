import { RequestHandler } from "express";
import { z } from "zod";
import { ApiResponse, User } from "@shared/api";
import crypto from 'crypto';

// Legal, Privacy & Billing interfaces
interface DataSubjectRequest {
  id: string;
  workspace_id: string;
  user_id: string;
  request_type: 'access' | 'rectification' | 'erasure' | 'portability' | 'restriction' | 'objection';
  regulation: 'GDPR' | 'CCPA' | 'LGPD' | 'PIPEDA';
  status: 'pending' | 'in_progress' | 'completed' | 'rejected' | 'cancelled';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  description: string;
  requested_data_categories: string[];
  verification_method: 'email' | 'id_document' | 'two_factor' | 'manual_review';
  verification_status: 'pending' | 'verified' | 'failed';
  verification_documents?: {
    document_type: string;
    file_url: string;
    uploaded_at: string;
  }[];
  assigned_to?: string;
  estimated_completion: string;
  actual_completion?: string;
  response_data?: {
    file_url?: string;
    file_size_bytes?: number;
    format: 'json' | 'csv' | 'pdf' | 'xml';
    encrypted: boolean;
  };
  notes: {
    timestamp: string;
    author: string;
    content: string;
    visibility: 'internal' | 'external';
  }[];
  created_at: string;
  updated_at: string;
}

interface ConsentRecord {
  id: string;
  workspace_id: string;
  user_id: string;
  consent_type: 'marketing' | 'analytics' | 'cookies' | 'data_processing' | 'third_party_sharing';
  purpose: string;
  legal_basis: 'consent' | 'legitimate_interest' | 'contract' | 'legal_obligation' | 'vital_interests' | 'public_task';
  status: 'granted' | 'withdrawn' | 'pending' | 'expired';
  granted_at?: string;
  withdrawn_at?: string;
  expires_at?: string;
  withdrawal_method?: 'user_action' | 'auto_expiry' | 'admin_action';
  version: string;
  ip_address: string;
  user_agent: string;
  opt_in_method: 'checkbox' | 'button' | 'form_submission' | 'implied' | 'pre_ticked';
  granular_choices: {
    [key: string]: boolean;
  };
  third_parties?: {
    name: string;
    purpose: string;
    privacy_policy_url: string;
  }[];
  evidence: {
    screenshot_url?: string;
    form_data?: Record<string, any>;
    audit_trail: {
      timestamp: string;
      action: string;
      details: string;
    }[];
  };
}

interface PrivacyPolicy {
  id: string;
  workspace_id: string;
  version: string;
  effective_date: string;
  language: string;
  content: {
    introduction: string;
    data_collected: {
      category: string;
      description: string;
      legal_basis: string;
      retention_period: string;
    }[];
    processing_purposes: string[];
    data_sharing: {
      recipient: string;
      purpose: string;
      safeguards: string;
    }[];
    user_rights: string[];
    contact_information: {
      data_controller: string;
      dpo_email?: string;
      privacy_officer_email: string;
    };
    cookies_policy: string;
    changes_notification: string;
  };
  status: 'draft' | 'published' | 'archived';
  approval_required: boolean;
  approved_by?: string;
  approved_at?: string;
  published_at?: string;
  views_count: number;
  created_by: string;
  created_at: string;
  updated_at: string;
}

interface BillingPlan {
  id: string;
  workspace_id: string;
  name: string;
  description: string;
  tier: 'free' | 'starter' | 'professional' | 'enterprise' | 'custom';
  billing_cycle: 'monthly' | 'yearly' | 'one_time';
  price: {
    amount: number;
    currency: string;
    per_unit?: string; // 'user', 'gb', 'api_call'
  };
  features: {
    name: string;
    included: boolean;
    limit?: number;
    unit?: string;
  }[];
  limits: {
    max_users?: number;
    max_storage_gb?: number;
    max_api_calls?: number;
    max_integrations?: number;
    retention_days?: number;
  };
  trial_period_days?: number;
  setup_fee?: {
    amount: number;
    currency: string;
  };
  is_active: boolean;
  is_public: boolean;
  created_at: string;
  updated_at: string;
}

interface BillingSubscription {
  id: string;
  workspace_id: string;
  plan_id: string;
  status: 'active' | 'inactive' | 'cancelled' | 'past_due' | 'trialing' | 'unpaid';
  billing_email: string;
  payment_method: {
    type: 'card' | 'bank_transfer' | 'invoice' | 'paypal';
    last_four?: string;
    brand?: string;
    expires_at?: string;
  };
  current_period_start: string;
  current_period_end: string;
  trial_end?: string;
  quantity: number; // Number of seats/units
  unit_price: {
    amount: number;
    currency: string;
  };
  total_amount: {
    amount: number;
    currency: string;
  };
  tax_rate?: number;
  discount?: {
    code: string;
    type: 'percentage' | 'fixed';
    value: number;
    expires_at?: string;
  };
  auto_renew: boolean;
  cancel_at_period_end: boolean;
  cancelled_at?: string;
  cancellation_reason?: string;
  created_at: string;
  updated_at: string;
}

interface Invoice {
  id: string;
  workspace_id: string;
  subscription_id: string;
  invoice_number: string;
  status: 'draft' | 'open' | 'paid' | 'void' | 'uncollectible';
  amount_due: {
    amount: number;
    currency: string;
  };
  amount_paid: {
    amount: number;
    currency: string;
  };
  tax_amount?: {
    amount: number;
    currency: string;
    rate: number;
  };
  line_items: {
    description: string;
    quantity: number;
    unit_price: {
      amount: number;
      currency: string;
    };
    total: {
      amount: number;
      currency: string;
    };
    period?: {
      start: string;
      end: string;
    };
  }[];
  billing_address: {
    name: string;
    company?: string;
    line1: string;
    line2?: string;
    city: string;
    state?: string;
    postal_code: string;
    country: string;
  };
  due_date: string;
  paid_at?: string;
  payment_method?: string;
  pdf_url?: string;
  created_at: string;
  updated_at: string;
}

interface ComplianceFramework {
  id: string;
  workspace_id: string;
  framework_type: 'GDPR' | 'CCPA' | 'HIPAA' | 'SOX' | 'ISO27001' | 'SOC2';
  status: 'not_started' | 'in_progress' | 'compliant' | 'non_compliant' | 'review_required';
  certification_date?: string;
  expiry_date?: string;
  requirements: {
    id: string;
    title: string;
    description: string;
    status: 'pending' | 'in_progress' | 'completed' | 'not_applicable';
    evidence_urls: string[];
    assigned_to?: string;
    due_date?: string;
    completion_date?: string;
    notes?: string;
  }[];
  audit_history: {
    date: string;
    auditor: string;
    findings: string[];
    recommendations: string[];
    certification_level?: string;
  }[];
  risk_assessment: {
    overall_score: number;
    high_risk_items: number;
    medium_risk_items: number;
    low_risk_items: number;
    last_assessment: string;
  };
  created_at: string;
  updated_at: string;
}

// Mock databases
let dataSubjectRequests: DataSubjectRequest[] = [];
let consentRecords: ConsentRecord[] = [];
let privacyPolicies: PrivacyPolicy[] = [];
let billingPlans: BillingPlan[] = [
  {
    id: "plan-free",
    workspace_id: "default",
    name: "Free Plan",
    description: "Perfect for small teams getting started",
    tier: "free",
    billing_cycle: "monthly",
    price: { amount: 0, currency: "USD" },
    features: [
      { name: "Up to 10 users", included: true, limit: 10, unit: "users" },
      { name: "5GB storage", included: true, limit: 5, unit: "GB" },
      { name: "Basic integrations", included: true },
      { name: "Community support", included: true },
      { name: "Advanced analytics", included: false },
      { name: "SSO", included: false }
    ],
    limits: {
      max_users: 10,
      max_storage_gb: 5,
      max_integrations: 3,
      retention_days: 30
    },
    is_active: true,
    is_public: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "plan-pro",
    workspace_id: "default",
    name: "Professional",
    description: "Advanced features for growing teams",
    tier: "professional",
    billing_cycle: "monthly",
    price: { amount: 29, currency: "USD", per_unit: "user" },
    features: [
      { name: "Unlimited users", included: true },
      { name: "100GB storage", included: true, limit: 100, unit: "GB" },
      { name: "All integrations", included: true },
      { name: "Priority support", included: true },
      { name: "Advanced analytics", included: true },
      { name: "SSO", included: true },
      { name: "Custom branding", included: true }
    ],
    limits: {
      max_storage_gb: 100,
      retention_days: 365
    },
    trial_period_days: 14,
    is_active: true,
    is_public: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

let billingSubscriptions: BillingSubscription[] = [];
let invoices: Invoice[] = [];
let complianceFrameworks: ComplianceFramework[] = [];

// Validation schemas
const dataSubjectRequestSchema = z.object({
  request_type: z.enum(['access', 'rectification', 'erasure', 'portability', 'restriction', 'objection']),
  regulation: z.enum(['GDPR', 'CCPA', 'LGPD', 'PIPEDA']).default('GDPR'),
  description: z.string().min(10).max(1000),
  requested_data_categories: z.array(z.string()).default([]),
  verification_method: z.enum(['email', 'id_document', 'two_factor', 'manual_review']).default('email')
});

const consentRecordSchema = z.object({
  consent_type: z.enum(['marketing', 'analytics', 'cookies', 'data_processing', 'third_party_sharing']),
  purpose: z.string().min(1).max(500),
  legal_basis: z.enum(['consent', 'legitimate_interest', 'contract', 'legal_obligation', 'vital_interests', 'public_task']),
  status: z.enum(['granted', 'withdrawn']),
  expires_at: z.string().optional(),
  opt_in_method: z.enum(['checkbox', 'button', 'form_submission', 'implied', 'pre_ticked']),
  granular_choices: z.record(z.boolean()).default({}),
  third_parties: z.array(z.object({
    name: z.string(),
    purpose: z.string(),
    privacy_policy_url: z.string().url()
  })).optional()
});

const subscriptionSchema = z.object({
  plan_id: z.string(),
  billing_email: z.string().email(),
  payment_method: z.object({
    type: z.enum(['card', 'bank_transfer', 'invoice', 'paypal']),
    token: z.string().optional(), // Payment method token from payment processor
    last_four: z.string().optional(),
    brand: z.string().optional()
  }),
  quantity: z.number().min(1).default(1),
  billing_address: z.object({
    name: z.string(),
    company: z.string().optional(),
    line1: z.string(),
    line2: z.string().optional(),
    city: z.string(),
    state: z.string().optional(),
    postal_code: z.string(),
    country: z.string()
  }),
  discount_code: z.string().optional(),
  tax_rate: z.number().min(0).max(1).optional()
});

// API endpoints
export const createDataSubjectRequest: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = dataSubjectRequestSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid request data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    // Calculate estimated completion based on regulation requirements
    const estimatedDays = validation.data.regulation === 'GDPR' ? 30 : 45;
    const estimatedCompletion = new Date(Date.now() + estimatedDays * 24 * 60 * 60 * 1000);

    const request: DataSubjectRequest = {
      id: `dsr_${Date.now()}`,
      workspace_id: "default",
      user_id: user.id,
      ...validation.data,
      status: 'pending',
      priority: validation.data.request_type === 'erasure' ? 'high' : 'medium',
      verification_status: 'pending',
      estimated_completion: estimatedCompletion.toISOString(),
      notes: [{
        timestamp: new Date().toISOString(),
        author: 'system',
        content: `Request submitted via user portal`,
        visibility: 'internal'
      }],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    dataSubjectRequests.push(request);

    res.status(201).json({
      success: true,
      data: request,
      message: `Your ${validation.data.request_type} request has been submitted. You will receive updates via email.`
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create data subject request"
    } as ApiResponse);
  }
};

export const getDataSubjectRequests: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { status, regulation, my_requests_only = 'false' } = req.query;
    
    let filteredRequests = dataSubjectRequests.filter(request => request.workspace_id === "default");
    
    if (my_requests_only === 'true') {
      filteredRequests = filteredRequests.filter(request => request.user_id === user.id);
    }
    
    if (status) {
      filteredRequests = filteredRequests.filter(request => request.status === status);
    }
    
    if (regulation) {
      filteredRequests = filteredRequests.filter(request => request.regulation === regulation);
    }
    
    // Sort by created date descending
    filteredRequests.sort((a, b) => 
      new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
    
    // For non-admin users, only show their own requests
    if (user.id !== "1") { // Basic admin check
      filteredRequests = filteredRequests.filter(request => request.user_id === user.id);
    }
    
    res.json({
      success: true,
      data: {
        requests: filteredRequests,
        total: filteredRequests.length,
        by_status: {
          pending: filteredRequests.filter(r => r.status === 'pending').length,
          in_progress: filteredRequests.filter(r => r.status === 'in_progress').length,
          completed: filteredRequests.filter(r => r.status === 'completed').length
        }
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get data subject requests"
    } as ApiResponse);
  }
};

export const recordConsent: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = consentRecordSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid consent data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    // Find existing consent record to update or create new one
    const existingConsentIndex = consentRecords.findIndex(record => 
      record.user_id === user.id && 
      record.consent_type === validation.data.consent_type &&
      record.purpose === validation.data.purpose
    );

    const now = new Date().toISOString();
    const ipAddress = req.ip || 'unknown';
    const userAgent = req.get('user-agent') || 'unknown';

    const consentRecord: ConsentRecord = {
      id: existingConsentIndex !== -1 ? consentRecords[existingConsentIndex].id : `consent_${Date.now()}`,
      workspace_id: "default",
      user_id: user.id,
      ...validation.data,
      granted_at: validation.data.status === 'granted' ? now : undefined,
      withdrawn_at: validation.data.status === 'withdrawn' ? now : undefined,
      withdrawal_method: validation.data.status === 'withdrawn' ? 'user_action' : undefined,
      version: "1.0",
      ip_address: ipAddress,
      user_agent: userAgent,
      evidence: {
        form_data: req.body,
        audit_trail: [{
          timestamp: now,
          action: validation.data.status === 'granted' ? 'consent_granted' : 'consent_withdrawn',
          details: `User ${validation.data.status} consent for ${validation.data.consent_type}`
        }]
      }
    };

    if (existingConsentIndex !== -1) {
      // Update existing record
      consentRecord.evidence.audit_trail = [
        ...consentRecords[existingConsentIndex].evidence.audit_trail,
        ...consentRecord.evidence.audit_trail
      ];
      consentRecords[existingConsentIndex] = consentRecord;
    } else {
      // Create new record
      consentRecords.push(consentRecord);
    }

    res.json({
      success: true,
      data: consentRecord,
      message: `Consent ${validation.data.status} successfully recorded`
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to record consent"
    } as ApiResponse);
  }
};

export const getConsentRecords: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { consent_type, status } = req.query;
    
    let filteredRecords = consentRecords.filter(record => record.user_id === user.id);
    
    if (consent_type) {
      filteredRecords = filteredRecords.filter(record => record.consent_type === consent_type);
    }
    
    if (status) {
      filteredRecords = filteredRecords.filter(record => record.status === status);
    }
    
    // Sort by most recent first
    filteredRecords.sort((a, b) => {
      const aTime = a.granted_at || a.withdrawn_at || a.created_at || '0';
      const bTime = b.granted_at || b.withdrawn_at || b.created_at || '0';
      return new Date(bTime).getTime() - new Date(aTime).getTime();
    });
    
    res.json({
      success: true,
      data: filteredRecords
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get consent records"
    } as ApiResponse);
  }
};

export const getBillingPlans: RequestHandler = (req, res) => {
  try {
    const { tier, public_only = 'true' } = req.query;
    
    let filteredPlans = billingPlans.filter(plan => plan.workspace_id === "default" && plan.is_active);
    
    if (public_only === 'true') {
      filteredPlans = filteredPlans.filter(plan => plan.is_public);
    }
    
    if (tier) {
      filteredPlans = filteredPlans.filter(plan => plan.tier === tier);
    }
    
    // Sort by price ascending
    filteredPlans.sort((a, b) => a.price.amount - b.price.amount);
    
    res.json({
      success: true,
      data: filteredPlans
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get billing plans"
    } as ApiResponse);
  }
};

export const createSubscription: RequestHandler = async (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = subscriptionSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid subscription data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const plan = billingPlans.find(p => p.id === validation.data.plan_id);
    if (!plan) {
      return res.status(404).json({
        success: false,
        error: "Billing plan not found"
      } as ApiResponse);
    }

    // Check for existing active subscription
    const existingSubscription = billingSubscriptions.find(sub => 
      sub.workspace_id === "default" && 
      ['active', 'trialing'].includes(sub.status)
    );

    if (existingSubscription) {
      return res.status(400).json({
        success: false,
        error: "An active subscription already exists for this workspace"
      } as ApiResponse);
    }

    const now = new Date();
    const periodEnd = new Date(now);
    
    if (plan.billing_cycle === 'monthly') {
      periodEnd.setMonth(periodEnd.getMonth() + 1);
    } else {
      periodEnd.setFullYear(periodEnd.getFullYear() + 1);
    }

    // Calculate pricing
    const unitPrice = plan.price.amount;
    const quantity = validation.data.quantity;
    let totalAmount = unitPrice * quantity;
    
    // Apply tax if provided
    if (validation.data.tax_rate) {
      totalAmount *= (1 + validation.data.tax_rate);
    }

    const subscription: BillingSubscription = {
      id: `sub_${Date.now()}`,
      workspace_id: "default",
      plan_id: validation.data.plan_id,
      status: plan.trial_period_days ? 'trialing' : 'active',
      billing_email: validation.data.billing_email,
      payment_method: {
        type: validation.data.payment_method.type,
        last_four: validation.data.payment_method.last_four,
        brand: validation.data.payment_method.brand
      },
      current_period_start: now.toISOString(),
      current_period_end: periodEnd.toISOString(),
      trial_end: plan.trial_period_days ? 
        new Date(now.getTime() + plan.trial_period_days * 24 * 60 * 60 * 1000).toISOString() : 
        undefined,
      quantity,
      unit_price: { amount: unitPrice, currency: plan.price.currency },
      total_amount: { amount: Math.round(totalAmount * 100) / 100, currency: plan.price.currency },
      tax_rate: validation.data.tax_rate,
      auto_renew: true,
      cancel_at_period_end: false,
      created_at: now.toISOString(),
      updated_at: now.toISOString()
    };

    billingSubscriptions.push(subscription);

    // Create first invoice if not in trial
    if (!plan.trial_period_days) {
      await createInvoiceForSubscription(subscription, validation.data.billing_address);
    }

    res.status(201).json({
      success: true,
      data: subscription,
      message: plan.trial_period_days ? 
        `Trial started! You have ${plan.trial_period_days} days to explore all features.` :
        "Subscription created successfully!"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create subscription"
    } as ApiResponse);
  }
};

export const getSubscription: RequestHandler = (req, res) => {
  try {
    const subscription = billingSubscriptions.find(sub => sub.workspace_id === "default");
    
    if (!subscription) {
      return res.status(404).json({
        success: false,
        error: "No subscription found for this workspace"
      } as ApiResponse);
    }

    // Get associated plan details
    const plan = billingPlans.find(p => p.id === subscription.plan_id);
    
    res.json({
      success: true,
      data: {
        subscription,
        plan,
        usage: {
          // Mock usage data
          users: 5,
          storage_gb: 2.3,
          api_calls_this_month: 1250,
          integrations: 3
        }
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get subscription"
    } as ApiResponse);
  }
};

export const getInvoices: RequestHandler = (req, res) => {
  try {
    const { status, limit = 20, offset = 0 } = req.query;
    
    let filteredInvoices = invoices.filter(invoice => invoice.workspace_id === "default");
    
    if (status) {
      filteredInvoices = filteredInvoices.filter(invoice => invoice.status === status);
    }
    
    // Sort by created date descending
    filteredInvoices.sort((a, b) => 
      new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
    
    const paginatedInvoices = filteredInvoices.slice(
      Number(offset), 
      Number(offset) + Number(limit)
    );
    
    res.json({
      success: true,
      data: {
        invoices: paginatedInvoices,
        total: filteredInvoices.length,
        offset: Number(offset),
        limit: Number(limit)
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get invoices"
    } as ApiResponse);
  }
};

export const getComplianceFrameworks: RequestHandler = (req, res) => {
  try {
    const frameworks = complianceFrameworks.filter(framework => framework.workspace_id === "default");
    
    res.json({
      success: true,
      data: frameworks
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get compliance frameworks"
    } as ApiResponse);
  }
};

export const exportUserData: RequestHandler = async (req, res) => {
  try {
    const user = (req as any).user as User;
    const { format = 'json', include_files = 'false' } = req.query;
    
    // Simulate data export
    const exportData = {
      user_profile: {
        id: user.id,
        email: user.email || `user${user.id}@example.com`,
        name: user.name || `User ${user.id}`,
        created_at: new Date().toISOString(),
        last_login: new Date().toISOString()
      },
      messages: [
        // Mock user messages
        { id: "msg1", text: "Hello world", channel: "general", timestamp: new Date().toISOString() }
      ],
      files: include_files === 'true' ? [
        // Mock user files
        { id: "file1", name: "document.pdf", size: 1024, uploaded_at: new Date().toISOString() }
      ] : [],
      consent_records: consentRecords.filter(record => record.user_id === user.id),
      export_metadata: {
        generated_at: new Date().toISOString(),
        format,
        regulation_compliance: ['GDPR', 'CCPA'],
        retention_notice: "This data export is valid for 30 days"
      }
    };

    // In production, this would generate a file and provide download URL
    const exportId = `export_${Date.now()}`;
    const downloadUrl = `https://exports.example.com/${exportId}.${format}`;

    res.json({
      success: true,
      data: {
        export_id: exportId,
        download_url: downloadUrl,
        expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        file_size_estimate: "2.5 MB",
        format: format as string,
        includes_files: include_files === 'true'
      },
      message: "Your data export has been generated and will be available for download for 30 days."
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to export user data"
    } as ApiResponse);
  }
};

export const deleteUserData: RequestHandler = async (req, res) => {
  try {
    const user = (req as any).user as User;
    const { verification_code, data_categories = ['all'] } = req.body;
    
    // In production, verify the deletion code sent via email
    if (!verification_code || verification_code !== '123456') {
      return res.status(400).json({
        success: false,
        error: "Invalid verification code"
      } as ApiResponse);
    }

    // Simulate data deletion process
    const deletionSummary = {
      user_profile: data_categories.includes('all') || data_categories.includes('profile'),
      messages: data_categories.includes('all') || data_categories.includes('messages'),
      files: data_categories.includes('all') || data_categories.includes('files'),
      consent_records: data_categories.includes('all') || data_categories.includes('consent'),
      analytics_data: data_categories.includes('all') || data_categories.includes('analytics')
    };

    // Create deletion request record
    const deletionRequest: DataSubjectRequest = {
      id: `del_${Date.now()}`,
      workspace_id: "default",
      user_id: user.id,
      request_type: 'erasure',
      regulation: 'GDPR',
      status: 'in_progress',
      priority: 'high',
      description: 'User requested complete data deletion',
      requested_data_categories: data_categories as string[],
      verification_method: 'email',
      verification_status: 'verified',
      estimated_completion: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      notes: [{
        timestamp: new Date().toISOString(),
        author: 'system',
        content: 'Data deletion initiated by user',
        visibility: 'internal'
      }],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    dataSubjectRequests.push(deletionRequest);

    res.json({
      success: true,
      data: {
        deletion_request_id: deletionRequest.id,
        categories_to_delete: deletionSummary,
        estimated_completion: deletionRequest.estimated_completion,
        reference_number: deletionRequest.id
      },
      message: "Your data deletion request has been submitted. You will receive a confirmation email once the process is complete (typically within 7 days)."
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to process data deletion request"
    } as ApiResponse);
  }
};

// Helper function to create invoice
async function createInvoiceForSubscription(subscription: BillingSubscription, billingAddress: any): Promise<void> {
  const plan = billingPlans.find(p => p.id === subscription.plan_id);
  if (!plan) return;

  const invoice: Invoice = {
    id: `inv_${Date.now()}`,
    workspace_id: subscription.workspace_id,
    subscription_id: subscription.id,
    invoice_number: `INV-${Date.now()}`,
    status: 'open',
    amount_due: subscription.total_amount,
    amount_paid: { amount: 0, currency: subscription.total_amount.currency },
    line_items: [{
      description: `${plan.name} - ${plan.billing_cycle} subscription`,
      quantity: subscription.quantity,
      unit_price: subscription.unit_price,
      total: subscription.total_amount,
      period: {
        start: subscription.current_period_start,
        end: subscription.current_period_end
      }
    }],
    billing_address: billingAddress,
    due_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  if (subscription.tax_rate) {
    invoice.tax_amount = {
      amount: Math.round(subscription.total_amount.amount * subscription.tax_rate * 100) / 100,
      currency: subscription.total_amount.currency,
      rate: subscription.tax_rate
    };
  }

  invoices.push(invoice);
}
