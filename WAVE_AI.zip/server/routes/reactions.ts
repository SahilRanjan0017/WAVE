import { RequestHandler } from "express";
import { z } from "zod";
import { AddReactionRequest, RemoveReactionRequest, Reaction, ApiResponse, User } from "@shared/api";

// Mock database
let reactions: Reaction[] = [];

// Validation schemas
const addReactionSchema = z.object({
  message_id: z.string(),
  emoji: z.string(),
  emoji_name: z.string()
});

const removeReactionSchema = z.object({
  message_id: z.string(),
  emoji: z.string()
});

export const addReaction: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = addReactionSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid input",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const { message_id, emoji, emoji_name } = validation.data as AddReactionRequest;

    // Check if user already reacted with this emoji
    const existingReaction = reactions.find(r => 
      r.message_id === message_id && 
      r.user_id === user.id && 
      r.emoji === emoji
    );

    if (existingReaction) {
      return res.status(400).json({
        success: false,
        error: "You have already reacted with this emoji"
      } as ApiResponse);
    }

    const reaction: Reaction = {
      id: Date.now().toString(),
      message_id,
      user_id: user.id,
      emoji,
      emoji_name,
      created_at: new Date().toISOString(),
      user
    };

    reactions.push(reaction);

    // Broadcast reaction via WebSocket
    const wsManager = (req as any).app?.wsManager;
    if (wsManager) {
      // Assuming we can determine channel from message (in real app, query database)
      wsManager.broadcastMessageReaction(message_id, 'general', reaction);
    }

    res.status(201).json({
      success: true,
      data: reaction
    } as ApiResponse<Reaction>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const removeReaction: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = removeReactionSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid input",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const { message_id, emoji } = validation.data as RemoveReactionRequest;

    const reactionIndex = reactions.findIndex(r => 
      r.message_id === message_id && 
      r.user_id === user.id && 
      r.emoji === emoji
    );

    if (reactionIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Reaction not found"
      } as ApiResponse);
    }

    const removedReaction = reactions[reactionIndex];
    reactions.splice(reactionIndex, 1);

    // Broadcast reaction removal via WebSocket
    const wsManager = (req as any).app?.wsManager;
    if (wsManager) {
      wsManager.broadcastMessageReaction(message_id, 'general', { 
        ...removedReaction, 
        removed: true 
      });
    }

    res.json({
      success: true,
      message: "Reaction removed successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getMessageReactions: RequestHandler = (req, res) => {
  try {
    const { messageId } = req.params;
    
    const messageReactions = reactions.filter(r => r.message_id === messageId);
    
    // Group reactions by emoji
    const groupedReactions = messageReactions.reduce((acc, reaction) => {
      const key = reaction.emoji;
      if (!acc[key]) {
        acc[key] = {
          emoji: reaction.emoji,
          emoji_name: reaction.emoji_name,
          count: 0,
          users: [],
          user_reacted: false
        };
      }
      acc[key].count++;
      acc[key].users.push(reaction.user!);
      
      // Check if current user reacted
      const currentUser = (req as any).user as User;
      if (reaction.user_id === currentUser.id) {
        acc[key].user_reacted = true;
      }
      
      return acc;
    }, {} as any);

    res.json({
      success: true,
      data: Object.values(groupedReactions)
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};
