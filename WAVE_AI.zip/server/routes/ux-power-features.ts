import { RequestHandler } from "express";
import { z } from "zod";
import { ApiResponse, User, Message } from "@shared/api";
import crypto from 'crypto';

// UX and power-user interfaces
interface StarredMessage {
  id: string;
  user_id: string;
  workspace_id: string;
  message_id: string;
  channel_id: string;
  starred_at: string;
  note?: string;
  tags: string[];
  folder?: string;
}

interface SavedSearch {
  id: string;
  user_id: string;
  workspace_id: string;
  name: string;
  query: string;
  filters: {
    channels?: string[];
    users?: string[];
    date_range?: {
      start: string;
      end: string;
    };
    message_types?: string[];
    has_attachments?: boolean;
  };
  alert_enabled: boolean;
  created_at: string;
  last_used: string;
  use_count: number;
}

interface BulkAction {
  id: string;
  user_id: string;
  workspace_id: string;
  action_type: 'delete' | 'archive' | 'move' | 'tag' | 'export' | 'mark_read' | 'pin' | 'unpin';
  target_type: 'messages' | 'channels' | 'files' | 'users';
  target_ids: string[];
  parameters?: {
    destination_channel?: string;
    tags?: string[];
    export_format?: 'json' | 'csv' | 'pdf';
    reason?: string;
  };
  status: 'pending' | 'in_progress' | 'completed' | 'failed' | 'cancelled';
  progress: {
    total: number;
    completed: number;
    failed: number;
  };
  created_at: string;
  completed_at?: string;
  error_message?: string;
}

interface OfflineData {
  id: string;
  user_id: string;
  workspace_id: string;
  data_type: 'messages' | 'channels' | 'files' | 'users' | 'preferences';
  sync_timestamp: string;
  data: any;
  checksum: string;
  size_bytes: number;
  expires_at?: string;
}

interface QuickAction {
  id: string;
  user_id: string;
  workspace_id: string;
  name: string;
  description: string;
  icon: string;
  action_type: 'command' | 'workflow' | 'navigation' | 'macro';
  configuration: {
    command?: string;
    workflow_id?: string;
    url?: string;
    macro_steps?: {
      type: string;
      target: string;
      value?: any;
    }[];
  };
  keyboard_shortcut?: string;
  is_pinned: boolean;
  use_count: number;
  created_at: string;
  updated_at: string;
}

interface KeyboardShortcut {
  id: string;
  user_id: string;
  workspace_id: string;
  key_combination: string;
  action: string;
  description: string;
  scope: 'global' | 'channel' | 'dm' | 'modal';
  is_custom: boolean;
  is_active: boolean;
  created_at: string;
}

interface DataExport {
  id: string;
  user_id: string;
  workspace_id: string;
  export_type: 'messages' | 'files' | 'channels' | 'workspace' | 'personal_data';
  format: 'json' | 'csv' | 'pdf' | 'html' | 'zip';
  filters: {
    date_range?: {
      start: string;
      end: string;
    };
    channels?: string[];
    users?: string[];
    include_attachments?: boolean;
    include_metadata?: boolean;
  };
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'expired';
  file_url?: string;
  file_size_bytes?: number;
  progress_percentage: number;
  requested_at: string;
  completed_at?: string;
  expires_at?: string;
  download_count: number;
}

interface SmartFolder {
  id: string;
  user_id: string;
  workspace_id: string;
  name: string;
  description?: string;
  icon: string;
  color: string;
  auto_rules: {
    conditions: {
      message_content?: string[];
      from_users?: string[];
      in_channels?: string[];
      has_attachments?: boolean;
      mentions_me?: boolean;
      priority?: 'high' | 'medium' | 'low';
      date_range?: {
        start: string;
        end: string;
      };
    };
    actions: {
      add_tags?: string[];
      mark_important?: boolean;
      send_notification?: boolean;
    };
  }[];
  manual_items: string[];
  item_count: number;
  created_at: string;
  updated_at: string;
}

// Mock databases
let starredMessages: StarredMessage[] = [];
let savedSearches: SavedSearch[] = [];
let bulkActions: BulkAction[] = [];
let offlineData: OfflineData[] = [];
let quickActions: QuickAction[] = [
  {
    id: "quick-1",
    user_id: "1",
    workspace_id: "default",
    name: "Quick Search",
    description: "Open search with Ctrl+K",
    icon: "🔍",
    action_type: "command",
    configuration: {
      command: "search.open"
    },
    keyboard_shortcut: "ctrl+k",
    is_pinned: true,
    use_count: 45,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "quick-2",
    user_id: "1",
    workspace_id: "default",
    name: "New Message",
    description: "Start a new message",
    icon: "✏️",
    action_type: "command",
    configuration: {
      command: "message.new"
    },
    keyboard_shortcut: "ctrl+n",
    is_pinned: true,
    use_count: 23,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

let keyboardShortcuts: KeyboardShortcut[] = [
  {
    id: "shortcut-1",
    user_id: "1",
    workspace_id: "default",
    key_combination: "ctrl+k",
    action: "open_search",
    description: "Open quick search",
    scope: "global",
    is_custom: false,
    is_active: true,
    created_at: new Date().toISOString()
  },
  {
    id: "shortcut-2",
    user_id: "1",
    workspace_id: "default",
    key_combination: "ctrl+shift+k",
    action: "open_command_palette",
    description: "Open command palette",
    scope: "global",
    is_custom: false,
    is_active: true,
    created_at: new Date().toISOString()
  },
  {
    id: "shortcut-3",
    user_id: "1",
    workspace_id: "default",
    key_combination: "esc",
    action: "close_modal",
    description: "Close modal or dialog",
    scope: "modal",
    is_custom: false,
    is_active: true,
    created_at: new Date().toISOString()
  }
];

let dataExports: DataExport[] = [];
let smartFolders: SmartFolder[] = [];

// Validation schemas
const starMessageSchema = z.object({
  message_id: z.string(),
  channel_id: z.string(),
  note: z.string().max(500).optional(),
  tags: z.array(z.string()).default([]),
  folder: z.string().optional()
});

const savedSearchSchema = z.object({
  name: z.string().min(1).max(100),
  query: z.string().min(1),
  filters: z.object({
    channels: z.array(z.string()).optional(),
    users: z.array(z.string()).optional(),
    date_range: z.object({
      start: z.string(),
      end: z.string()
    }).optional(),
    message_types: z.array(z.string()).optional(),
    has_attachments: z.boolean().optional()
  }).default({}),
  alert_enabled: z.boolean().default(false)
});

const bulkActionSchema = z.object({
  action_type: z.enum(['delete', 'archive', 'move', 'tag', 'export', 'mark_read', 'pin', 'unpin']),
  target_type: z.enum(['messages', 'channels', 'files', 'users']),
  target_ids: z.array(z.string()).min(1),
  parameters: z.object({
    destination_channel: z.string().optional(),
    tags: z.array(z.string()).optional(),
    export_format: z.enum(['json', 'csv', 'pdf']).optional(),
    reason: z.string().optional()
  }).optional()
});

const quickActionSchema = z.object({
  name: z.string().min(1).max(50),
  description: z.string().max(200),
  icon: z.string().max(10),
  action_type: z.enum(['command', 'workflow', 'navigation', 'macro']),
  configuration: z.object({
    command: z.string().optional(),
    workflow_id: z.string().optional(),
    url: z.string().url().optional(),
    macro_steps: z.array(z.object({
      type: z.string(),
      target: z.string(),
      value: z.any().optional()
    })).optional()
  }),
  keyboard_shortcut: z.string().optional()
});

const dataExportSchema = z.object({
  export_type: z.enum(['messages', 'files', 'channels', 'workspace', 'personal_data']),
  format: z.enum(['json', 'csv', 'pdf', 'html', 'zip']),
  filters: z.object({
    date_range: z.object({
      start: z.string(),
      end: z.string()
    }).optional(),
    channels: z.array(z.string()).optional(),
    users: z.array(z.string()).optional(),
    include_attachments: z.boolean().default(false),
    include_metadata: z.boolean().default(true)
  }).default({})
});

const smartFolderSchema = z.object({
  name: z.string().min(1).max(50),
  description: z.string().max(200).optional(),
  icon: z.string().max(10),
  color: z.string().regex(/^#[0-9A-F]{6}$/i),
  auto_rules: z.array(z.object({
    conditions: z.object({
      message_content: z.array(z.string()).optional(),
      from_users: z.array(z.string()).optional(),
      in_channels: z.array(z.string()).optional(),
      has_attachments: z.boolean().optional(),
      mentions_me: z.boolean().optional(),
      priority: z.enum(['high', 'medium', 'low']).optional(),
      date_range: z.object({
        start: z.string(),
        end: z.string()
      }).optional()
    }),
    actions: z.object({
      add_tags: z.array(z.string()).optional(),
      mark_important: z.boolean().optional(),
      send_notification: z.boolean().optional()
    })
  })).default([])
});

// API endpoints
export const getStarredMessages: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { folder, tags, limit = 50, offset = 0 } = req.query;
    
    let filteredStars = starredMessages.filter(star => star.user_id === user.id);
    
    if (folder) {
      filteredStars = filteredStars.filter(star => star.folder === folder);
    }
    
    if (tags) {
      const tagList = (tags as string).split(',');
      filteredStars = filteredStars.filter(star => 
        tagList.some(tag => star.tags.includes(tag))
      );
    }
    
    // Sort by starred date descending
    filteredStars.sort((a, b) => 
      new Date(b.starred_at).getTime() - new Date(a.starred_at).getTime()
    );
    
    const paginatedStars = filteredStars.slice(
      Number(offset), 
      Number(offset) + Number(limit)
    );
    
    res.json({
      success: true,
      data: {
        starred_messages: paginatedStars,
        total: filteredStars.length,
        folders: [...new Set(starredMessages.filter(s => s.user_id === user.id && s.folder).map(s => s.folder))],
        all_tags: [...new Set(starredMessages.filter(s => s.user_id === user.id).flatMap(s => s.tags))],
        offset: Number(offset),
        limit: Number(limit)
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get starred messages"
    } as ApiResponse);
  }
};

export const starMessage: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = starMessageSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid star data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    // Check if already starred
    const existingStar = starredMessages.find(star => 
      star.user_id === user.id && 
      star.message_id === validation.data.message_id
    );

    if (existingStar) {
      return res.status(400).json({
        success: false,
        error: "Message is already starred"
      } as ApiResponse);
    }

    const starredMessage: StarredMessage = {
      id: `star_${Date.now()}`,
      user_id: user.id,
      workspace_id: "default",
      ...validation.data,
      starred_at: new Date().toISOString()
    };

    starredMessages.push(starredMessage);

    res.status(201).json({
      success: true,
      data: starredMessage
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to star message"
    } as ApiResponse);
  }
};

export const unstarMessage: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { messageId } = req.params;
    
    const starIndex = starredMessages.findIndex(star => 
      star.user_id === user.id && star.message_id === messageId
    );

    if (starIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Starred message not found"
      } as ApiResponse);
    }

    starredMessages.splice(starIndex, 1);

    res.json({
      success: true,
      message: "Message unstarred successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to unstar message"
    } as ApiResponse);
  }
};

export const getSavedSearches: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const userSearches = savedSearches.filter(search => search.user_id === user.id);
    
    // Sort by last used descending
    userSearches.sort((a, b) => 
      new Date(b.last_used).getTime() - new Date(a.last_used).getTime()
    );
    
    res.json({
      success: true,
      data: userSearches
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get saved searches"
    } as ApiResponse);
  }
};

export const createSavedSearch: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = savedSearchSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid search data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const savedSearch: SavedSearch = {
      id: `search_${Date.now()}`,
      user_id: user.id,
      workspace_id: "default",
      ...validation.data,
      created_at: new Date().toISOString(),
      last_used: new Date().toISOString(),
      use_count: 0
    };

    savedSearches.push(savedSearch);

    res.status(201).json({
      success: true,
      data: savedSearch
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create saved search"
    } as ApiResponse);
  }
};

export const createBulkAction: RequestHandler = async (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = bulkActionSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid bulk action data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const bulkAction: BulkAction = {
      id: `bulk_${Date.now()}`,
      user_id: user.id,
      workspace_id: "default",
      ...validation.data,
      status: 'pending',
      progress: {
        total: validation.data.target_ids.length,
        completed: 0,
        failed: 0
      },
      created_at: new Date().toISOString()
    };

    bulkActions.push(bulkAction);

    // Simulate bulk action processing
    setTimeout(async () => {
      const actionIndex = bulkActions.findIndex(action => action.id === bulkAction.id);
      if (actionIndex !== -1) {
        bulkActions[actionIndex].status = 'in_progress';
        
        // Simulate processing each item
        for (let i = 0; i < validation.data.target_ids.length; i++) {
          await new Promise(resolve => setTimeout(resolve, 100)); // Simulate processing time
          
          // 90% success rate simulation
          if (Math.random() > 0.1) {
            bulkActions[actionIndex].progress.completed++;
          } else {
            bulkActions[actionIndex].progress.failed++;
          }
        }
        
        bulkActions[actionIndex].status = 'completed';
        bulkActions[actionIndex].completed_at = new Date().toISOString();
      }
    }, 1000);

    res.status(201).json({
      success: true,
      data: bulkAction,
      message: "Bulk action started"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create bulk action"
    } as ApiResponse);
  }
};

export const getBulkActions: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { status, limit = 20, offset = 0 } = req.query;
    
    let filteredActions = bulkActions.filter(action => action.user_id === user.id);
    
    if (status) {
      filteredActions = filteredActions.filter(action => action.status === status);
    }
    
    // Sort by created date descending
    filteredActions.sort((a, b) => 
      new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
    
    const paginatedActions = filteredActions.slice(
      Number(offset), 
      Number(offset) + Number(limit)
    );
    
    res.json({
      success: true,
      data: {
        bulk_actions: paginatedActions,
        total: filteredActions.length,
        offset: Number(offset),
        limit: Number(limit)
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get bulk actions"
    } as ApiResponse);
  }
};

export const syncOfflineData: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { data_types = ['messages', 'channels', 'users'] } = req.body;
    
    const syncTimestamp = new Date().toISOString();
    const syncedData: OfflineData[] = [];

    // Mock offline data sync
    for (const dataType of data_types) {
      let mockData: any = {};
      
      switch (dataType) {
        case 'messages':
          mockData = {
            recent_messages: Array.from({ length: 50 }, (_, i) => ({
              id: `msg_${i}`,
              text: `Sample message ${i}`,
              channel_id: `channel_${i % 5}`,
              author: `user_${i % 10}`,
              timestamp: new Date(Date.now() - i * 60000).toISOString()
            }))
          };
          break;
        case 'channels':
          mockData = {
            channels: Array.from({ length: 10 }, (_, i) => ({
              id: `channel_${i}`,
              name: `Channel ${i}`,
              topic: `Topic for channel ${i}`,
              member_count: Math.floor(Math.random() * 100)
            }))
          };
          break;
        case 'users':
          mockData = {
            users: Array.from({ length: 20 }, (_, i) => ({
              id: `user_${i}`,
              name: `User ${i}`,
              avatar: `https://avatar.example.com/user_${i}.jpg`,
              status: ['online', 'away', 'busy', 'offline'][i % 4]
            }))
          };
          break;
      }

      const offlineDataEntry: OfflineData = {
        id: `offline_${dataType}_${Date.now()}`,
        user_id: user.id,
        workspace_id: "default",
        data_type: dataType as any,
        sync_timestamp: syncTimestamp,
        data: mockData,
        checksum: crypto.createHash('md5').update(JSON.stringify(mockData)).digest('hex'),
        size_bytes: JSON.stringify(mockData).length,
        expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
      };

      // Remove old offline data for this type
      offlineData = offlineData.filter(data => 
        !(data.user_id === user.id && data.data_type === dataType)
      );
      
      offlineData.push(offlineDataEntry);
      syncedData.push(offlineDataEntry);
    }

    res.json({
      success: true,
      data: {
        sync_timestamp: syncTimestamp,
        synced_data: syncedData,
        total_size_bytes: syncedData.reduce((sum, data) => sum + data.size_bytes, 0)
      },
      message: "Offline data synced successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to sync offline data"
    } as ApiResponse);
  }
};

export const getOfflineData: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { data_type, since } = req.query;
    
    let filteredData = offlineData.filter(data => data.user_id === user.id);
    
    if (data_type) {
      filteredData = filteredData.filter(data => data.data_type === data_type);
    }
    
    if (since) {
      filteredData = filteredData.filter(data => data.sync_timestamp >= since);
    }
    
    // Filter out expired data
    const now = new Date().toISOString();
    filteredData = filteredData.filter(data => 
      !data.expires_at || data.expires_at > now
    );
    
    res.json({
      success: true,
      data: filteredData
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get offline data"
    } as ApiResponse);
  }
};

export const getQuickActions: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { pinned_only = 'false' } = req.query;
    
    let filteredActions = quickActions.filter(action => action.user_id === user.id);
    
    if (pinned_only === 'true') {
      filteredActions = filteredActions.filter(action => action.is_pinned);
    }
    
    // Sort by use count descending
    filteredActions.sort((a, b) => b.use_count - a.use_count);
    
    res.json({
      success: true,
      data: filteredActions
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get quick actions"
    } as ApiResponse);
  }
};

export const createQuickAction: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = quickActionSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid quick action data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const quickAction: QuickAction = {
      id: `quick_${Date.now()}`,
      user_id: user.id,
      workspace_id: "default",
      ...validation.data,
      is_pinned: false,
      use_count: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    quickActions.push(quickAction);

    res.status(201).json({
      success: true,
      data: quickAction
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create quick action"
    } as ApiResponse);
  }
};

export const getKeyboardShortcuts: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { scope, active_only = 'true' } = req.query;
    
    let filteredShortcuts = keyboardShortcuts.filter(shortcut => shortcut.user_id === user.id);
    
    if (scope) {
      filteredShortcuts = filteredShortcuts.filter(shortcut => shortcut.scope === scope);
    }
    
    if (active_only === 'true') {
      filteredShortcuts = filteredShortcuts.filter(shortcut => shortcut.is_active);
    }
    
    res.json({
      success: true,
      data: filteredShortcuts
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get keyboard shortcuts"
    } as ApiResponse);
  }
};

export const createDataExport: RequestHandler = async (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = dataExportSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid export data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const dataExport: DataExport = {
      id: `export_${Date.now()}`,
      user_id: user.id,
      workspace_id: "default",
      ...validation.data,
      status: 'pending',
      progress_percentage: 0,
      requested_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      download_count: 0
    };

    dataExports.push(dataExport);

    // Simulate export processing
    setTimeout(async () => {
      const exportIndex = dataExports.findIndex(exp => exp.id === dataExport.id);
      if (exportIndex !== -1) {
        dataExports[exportIndex].status = 'processing';
        
        // Simulate progress
        for (let progress = 10; progress <= 100; progress += 10) {
          await new Promise(resolve => setTimeout(resolve, 200));
          dataExports[exportIndex].progress_percentage = progress;
        }
        
        dataExports[exportIndex].status = 'completed';
        dataExports[exportIndex].completed_at = new Date().toISOString();
        dataExports[exportIndex].file_url = `https://exports.example.com/${dataExport.id}.${validation.data.format}`;
        dataExports[exportIndex].file_size_bytes = Math.floor(Math.random() * 10000000); // Random size
      }
    }, 1000);

    res.status(201).json({
      success: true,
      data: dataExport,
      message: "Data export started"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create data export"
    } as ApiResponse);
  }
};

export const getDataExports: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { status, export_type } = req.query;
    
    let filteredExports = dataExports.filter(exp => exp.user_id === user.id);
    
    if (status) {
      filteredExports = filteredExports.filter(exp => exp.status === status);
    }
    
    if (export_type) {
      filteredExports = filteredExports.filter(exp => exp.export_type === export_type);
    }
    
    // Sort by requested date descending
    filteredExports.sort((a, b) => 
      new Date(b.requested_at).getTime() - new Date(a.requested_at).getTime()
    );
    
    res.json({
      success: true,
      data: filteredExports
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get data exports"
    } as ApiResponse);
  }
};

export const getSmartFolders: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const userFolders = smartFolders.filter(folder => folder.user_id === user.id);
    
    // Sort by updated date descending
    userFolders.sort((a, b) => 
      new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
    );
    
    res.json({
      success: true,
      data: userFolders
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get smart folders"
    } as ApiResponse);
  }
};

export const createSmartFolder: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = smartFolderSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid smart folder data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const smartFolder: SmartFolder = {
      id: `folder_${Date.now()}`,
      user_id: user.id,
      workspace_id: "default",
      ...validation.data,
      manual_items: [],
      item_count: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    smartFolders.push(smartFolder);

    res.status(201).json({
      success: true,
      data: smartFolder
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create smart folder"
    } as ApiResponse);
  }
};

export const getUXAnalytics: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { period = '30d' } = req.query;
    
    // Calculate UX analytics
    const userStars = starredMessages.filter(star => star.user_id === user.id);
    const userSearches = savedSearches.filter(search => search.user_id === user.id);
    const userActions = quickActions.filter(action => action.user_id === user.id);
    const userExports = dataExports.filter(exp => exp.user_id === user.id);
    
    const analytics = {
      period,
      starred_messages: {
        total: userStars.length,
        folders: [...new Set(userStars.filter(s => s.folder).map(s => s.folder))].length,
        tags: [...new Set(userStars.flatMap(s => s.tags))].length
      },
      saved_searches: {
        total: userSearches.length,
        with_alerts: userSearches.filter(s => s.alert_enabled).length,
        avg_use_count: userSearches.length > 0 
          ? Math.round(userSearches.reduce((sum, s) => sum + s.use_count, 0) / userSearches.length)
          : 0
      },
      quick_actions: {
        total: userActions.length,
        pinned: userActions.filter(a => a.is_pinned).length,
        total_uses: userActions.reduce((sum, a) => sum + a.use_count, 0)
      },
      bulk_actions: {
        total: bulkActions.filter(ba => ba.user_id === user.id).length,
        completed: bulkActions.filter(ba => ba.user_id === user.id && ba.status === 'completed').length
      },
      data_exports: {
        total: userExports.length,
        completed: userExports.filter(e => e.status === 'completed').length,
        total_downloads: userExports.reduce((sum, e) => sum + e.download_count, 0)
      },
      keyboard_shortcuts: {
        total: keyboardShortcuts.filter(ks => ks.user_id === user.id).length,
        custom: keyboardShortcuts.filter(ks => ks.user_id === user.id && ks.is_custom).length,
        active: keyboardShortcuts.filter(ks => ks.user_id === user.id && ks.is_active).length
      }
    };

    res.json({
      success: true,
      data: analytics
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get UX analytics"
    } as ApiResponse);
  }
};
