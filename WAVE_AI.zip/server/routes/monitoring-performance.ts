import { RequestHandler } from "express";
import { z } from "zod";
import { ApiResponse, User } from "@shared/api";

// Monitoring and performance interfaces
interface SystemMetrics {
  timestamp: string;
  server_id: string;
  metrics: {
    cpu_usage: number;
    memory_usage: number;
    disk_usage: number;
    network_in: number;
    network_out: number;
    active_connections: number;
    request_rate: number;
    response_time_avg: number;
    error_rate: number;
  };
  health_status: 'healthy' | 'warning' | 'critical';
}

interface RateLimitConfig {
  id: string;
  workspace_id: string;
  endpoint_pattern: string;
  limit_type: 'requests_per_minute' | 'requests_per_hour' | 'requests_per_day' | 'concurrent_requests';
  limit_value: number;
  window_size_seconds: number;
  burst_allowance: number;
  user_specific: boolean;
  exempted_users: string[];
  action_on_limit: 'throttle' | 'block' | 'warn';
  reset_policy: 'sliding_window' | 'fixed_window';
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface PerformanceAlert {
  id: string;
  workspace_id: string;
  alert_type: 'cpu_high' | 'memory_high' | 'disk_full' | 'response_slow' | 'error_spike' | 'downtime';
  severity: 'info' | 'warning' | 'critical' | 'emergency';
  title: string;
  description: string;
  threshold_value: number;
  current_value: number;
  server_id?: string;
  endpoint?: string;
  triggered_at: string;
  resolved_at?: string;
  status: 'active' | 'acknowledged' | 'resolved' | 'suppressed';
  acknowledged_by?: string;
  resolution_notes?: string;
}

interface BackupConfig {
  id: string;
  workspace_id: string;
  name: string;
  backup_type: 'full' | 'incremental' | 'differential';
  schedule: {
    frequency: 'hourly' | 'daily' | 'weekly' | 'monthly';
    hour?: number;
    day_of_week?: number;
    day_of_month?: number;
  };
  retention_policy: {
    keep_daily: number;
    keep_weekly: number;
    keep_monthly: number;
    keep_yearly: number;
  };
  storage_location: {
    type: 'local' | 's3' | 'gcs' | 'azure';
    bucket?: string;
    region?: string;
    encryption_enabled: boolean;
  };
  includes: {
    databases: string[];
    file_storage: boolean;
    user_data: boolean;
    system_config: boolean;
  };
  compression_enabled: boolean;
  is_active: boolean;
  last_backup_at?: string;
  next_backup_at?: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

interface BackupExecution {
  id: string;
  config_id: string;
  workspace_id: string;
  backup_type: 'full' | 'incremental' | 'differential';
  status: 'running' | 'completed' | 'failed' | 'cancelled';
  started_at: string;
  completed_at?: string;
  duration_seconds?: number;
  size_bytes?: number;
  file_path?: string;
  checksum?: string;
  error_message?: string;
  progress_percentage: number;
  metrics: {
    files_processed: number;
    bytes_processed: number;
    compression_ratio?: number;
    transfer_rate_mbps?: number;
  };
}

interface LoadBalancerConfig {
  id: string;
  workspace_id: string;
  name: string;
  algorithm: 'round_robin' | 'least_connections' | 'ip_hash' | 'weighted_round_robin';
  health_check: {
    enabled: boolean;
    path: string;
    interval_seconds: number;
    timeout_seconds: number;
    healthy_threshold: number;
    unhealthy_threshold: number;
  };
  servers: {
    id: string;
    host: string;
    port: number;
    weight?: number;
    is_active: boolean;
    health_status: 'healthy' | 'unhealthy' | 'unknown';
    last_health_check?: string;
  }[];
  ssl_config?: {
    certificate_path: string;
    private_key_path: string;
    protocols: string[];
    ciphers: string[];
  };
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface DisasterRecoveryPlan {
  id: string;
  workspace_id: string;
  name: string;
  description: string;
  recovery_type: 'hot_standby' | 'warm_standby' | 'cold_standby' | 'backup_restore';
  rpo_hours: number; // Recovery Point Objective
  rto_hours: number; // Recovery Time Objective
  failover_triggers: {
    manual: boolean;
    automatic: boolean;
    conditions: {
      server_down_minutes?: number;
      error_rate_threshold?: number;
      response_time_threshold?: number;
    };
  };
  recovery_steps: {
    order: number;
    step_type: 'backup_restore' | 'dns_switch' | 'service_start' | 'data_sync' | 'validation';
    description: string;
    automation_script?: string;
    estimated_duration_minutes: number;
    dependencies: number[];
  }[];
  test_schedule: {
    frequency: 'monthly' | 'quarterly' | 'bi_annually' | 'annually';
    last_test_date?: string;
    next_test_date?: string;
  };
  contact_list: {
    role: string;
    name: string;
    email: string;
    phone?: string;
    is_primary: boolean;
  }[];
  is_active: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
}

// Mock databases
let systemMetrics: SystemMetrics[] = [];
let rateLimitConfigs: RateLimitConfig[] = [
  {
    id: "rate-limit-api",
    workspace_id: "default",
    endpoint_pattern: "/api/*",
    limit_type: "requests_per_minute",
    limit_value: 100,
    window_size_seconds: 60,
    burst_allowance: 20,
    user_specific: true,
    exempted_users: ["admin"],
    action_on_limit: "throttle",
    reset_policy: "sliding_window",
    is_active: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

let performanceAlerts: PerformanceAlert[] = [];
let backupConfigs: BackupConfig[] = [];
let backupExecutions: BackupExecution[] = [];
let loadBalancerConfigs: LoadBalancerConfig[] = [];
let disasterRecoveryPlans: DisasterRecoveryPlan[] = [];

// Rate limiting tracking
const rateLimitCounters = new Map<string, { count: number; resetTime: number }>();

// Mock data generation
function generateMetrics(): SystemMetrics {
  return {
    timestamp: new Date().toISOString(),
    server_id: "server-01",
    metrics: {
      cpu_usage: Math.random() * 100,
      memory_usage: Math.random() * 100,
      disk_usage: Math.random() * 100,
      network_in: Math.random() * 1000,
      network_out: Math.random() * 1000,
      active_connections: Math.floor(Math.random() * 1000),
      request_rate: Math.random() * 100,
      response_time_avg: Math.random() * 500,
      error_rate: Math.random() * 5
    },
    health_status: Math.random() > 0.9 ? 'warning' : 'healthy'
  };
}

// Validation schemas
const rateLimitSchema = z.object({
  endpoint_pattern: z.string().min(1),
  limit_type: z.enum(['requests_per_minute', 'requests_per_hour', 'requests_per_day', 'concurrent_requests']),
  limit_value: z.number().min(1),
  window_size_seconds: z.number().min(1),
  burst_allowance: z.number().min(0).default(0),
  user_specific: z.boolean().default(true),
  exempted_users: z.array(z.string()).default([]),
  action_on_limit: z.enum(['throttle', 'block', 'warn']).default('throttle'),
  reset_policy: z.enum(['sliding_window', 'fixed_window']).default('sliding_window')
});

const backupConfigSchema = z.object({
  name: z.string().min(1).max(100),
  backup_type: z.enum(['full', 'incremental', 'differential']),
  schedule: z.object({
    frequency: z.enum(['hourly', 'daily', 'weekly', 'monthly']),
    hour: z.number().min(0).max(23).optional(),
    day_of_week: z.number().min(0).max(6).optional(),
    day_of_month: z.number().min(1).max(31).optional()
  }),
  retention_policy: z.object({
    keep_daily: z.number().min(1).max(365),
    keep_weekly: z.number().min(1).max(52),
    keep_monthly: z.number().min(1).max(12),
    keep_yearly: z.number().min(1).max(10)
  }),
  storage_location: z.object({
    type: z.enum(['local', 's3', 'gcs', 'azure']),
    bucket: z.string().optional(),
    region: z.string().optional(),
    encryption_enabled: z.boolean().default(true)
  }),
  includes: z.object({
    databases: z.array(z.string()),
    file_storage: z.boolean().default(true),
    user_data: z.boolean().default(true),
    system_config: z.boolean().default(true)
  }),
  compression_enabled: z.boolean().default(true)
});

const disasterRecoverySchema = z.object({
  name: z.string().min(1).max(100),
  description: z.string().max(1000),
  recovery_type: z.enum(['hot_standby', 'warm_standby', 'cold_standby', 'backup_restore']),
  rpo_hours: z.number().min(0).max(168), // Max 1 week
  rto_hours: z.number().min(0).max(72),  // Max 3 days
  failover_triggers: z.object({
    manual: z.boolean().default(true),
    automatic: z.boolean().default(false),
    conditions: z.object({
      server_down_minutes: z.number().optional(),
      error_rate_threshold: z.number().optional(),
      response_time_threshold: z.number().optional()
    }).optional()
  }),
  recovery_steps: z.array(z.object({
    order: z.number(),
    step_type: z.enum(['backup_restore', 'dns_switch', 'service_start', 'data_sync', 'validation']),
    description: z.string(),
    automation_script: z.string().optional(),
    estimated_duration_minutes: z.number(),
    dependencies: z.array(z.number()).default([])
  })),
  contact_list: z.array(z.object({
    role: z.string(),
    name: z.string(),
    email: z.string().email(),
    phone: z.string().optional(),
    is_primary: z.boolean().default(false)
  }))
});

// Rate limiting middleware
export const rateLimitMiddleware: RequestHandler = (req, res, next) => {
  try {
    const userId = (req as any).user?.id || 'anonymous';
    const endpoint = req.path;
    
    // Find matching rate limit config
    const config = rateLimitConfigs.find(config => 
      config.is_active && 
      endpoint.match(new RegExp(config.endpoint_pattern.replace('*', '.*')))
    );
    
    if (!config) {
      return next();
    }
    
    // Check if user is exempted
    if (config.exempted_users.includes(userId)) {
      return next();
    }
    
    const key = config.user_specific ? `${config.id}:${userId}` : config.id;
    const now = Date.now();
    const windowStart = now - (config.window_size_seconds * 1000);
    
    let counter = rateLimitCounters.get(key);
    
    if (!counter || counter.resetTime <= now) {
      counter = { count: 0, resetTime: now + (config.window_size_seconds * 1000) };
    }
    
    counter.count++;
    rateLimitCounters.set(key, counter);
    
    // Check rate limit
    const limit = config.limit_value + config.burst_allowance;
    if (counter.count > limit) {
      switch (config.action_on_limit) {
        case 'block':
          return res.status(429).json({
            success: false,
            error: "Rate limit exceeded",
            retry_after: Math.ceil((counter.resetTime - now) / 1000)
          });
        case 'warn':
          // Log warning but continue
          console.warn(`Rate limit warning for ${key}: ${counter.count}/${limit}`);
          break;
        case 'throttle':
        default:
          // Add delay based on excess requests
          const delay = Math.min((counter.count - limit) * 100, 5000);
          setTimeout(() => next(), delay);
          return;
      }
    }
    
    next();
  } catch (error) {
    console.error('Rate limiting error:', error);
    next(); // Continue on error
  }
};

// API endpoints
export const getSystemMetrics: RequestHandler = (req, res) => {
  try {
    const { hours = 24, server_id } = req.query;
    
    // Generate mock real-time metrics
    const currentMetrics = generateMetrics();
    systemMetrics.push(currentMetrics);
    
    // Keep only recent metrics
    const cutoff = new Date(Date.now() - Number(hours) * 60 * 60 * 1000).toISOString();
    systemMetrics = systemMetrics.filter(m => m.timestamp >= cutoff);
    
    let filteredMetrics = systemMetrics;
    if (server_id) {
      filteredMetrics = filteredMetrics.filter(m => m.server_id === server_id);
    }
    
    // Calculate aggregated metrics
    const aggregated = {
      avg_cpu: filteredMetrics.reduce((sum, m) => sum + m.metrics.cpu_usage, 0) / filteredMetrics.length,
      avg_memory: filteredMetrics.reduce((sum, m) => sum + m.metrics.memory_usage, 0) / filteredMetrics.length,
      avg_response_time: filteredMetrics.reduce((sum, m) => sum + m.metrics.response_time_avg, 0) / filteredMetrics.length,
      total_requests: filteredMetrics.reduce((sum, m) => sum + m.metrics.request_rate, 0),
      error_rate: filteredMetrics.reduce((sum, m) => sum + m.metrics.error_rate, 0) / filteredMetrics.length
    };
    
    res.json({
      success: true,
      data: {
        current: currentMetrics,
        history: filteredMetrics,
        aggregated,
        server_count: [...new Set(filteredMetrics.map(m => m.server_id))].length
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get system metrics"
    } as ApiResponse);
  }
};

export const getRateLimitConfigs: RequestHandler = (req, res) => {
  try {
    const configs = rateLimitConfigs.filter(config => config.workspace_id === "default");
    
    res.json({
      success: true,
      data: configs
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get rate limit configs"
    } as ApiResponse);
  }
};

export const createRateLimitConfig: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = rateLimitSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid rate limit config",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const config: RateLimitConfig = {
      id: `rl_${Date.now()}`,
      workspace_id: "default",
      ...validation.data,
      is_active: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    rateLimitConfigs.push(config);

    res.status(201).json({
      success: true,
      data: config
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create rate limit config"
    } as ApiResponse);
  }
};

export const getPerformanceAlerts: RequestHandler = (req, res) => {
  try {
    const { status, severity, limit = 50, offset = 0 } = req.query;
    
    let filteredAlerts = performanceAlerts.filter(alert => alert.workspace_id === "default");
    
    if (status) {
      filteredAlerts = filteredAlerts.filter(alert => alert.status === status);
    }
    
    if (severity) {
      filteredAlerts = filteredAlerts.filter(alert => alert.severity === severity);
    }
    
    // Sort by triggered date descending
    filteredAlerts.sort((a, b) => 
      new Date(b.triggered_at).getTime() - new Date(a.triggered_at).getTime()
    );
    
    const paginatedAlerts = filteredAlerts.slice(
      Number(offset), 
      Number(offset) + Number(limit)
    );
    
    res.json({
      success: true,
      data: {
        alerts: paginatedAlerts,
        total: filteredAlerts.length,
        by_status: {
          active: performanceAlerts.filter(a => a.status === 'active').length,
          acknowledged: performanceAlerts.filter(a => a.status === 'acknowledged').length,
          resolved: performanceAlerts.filter(a => a.status === 'resolved').length
        },
        offset: Number(offset),
        limit: Number(limit)
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get performance alerts"
    } as ApiResponse);
  }
};

export const getBackupConfigs: RequestHandler = (req, res) => {
  try {
    const configs = backupConfigs.filter(config => config.workspace_id === "default");
    
    res.json({
      success: true,
      data: configs
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get backup configs"
    } as ApiResponse);
  }
};

export const createBackupConfig: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = backupConfigSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid backup config",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const config: BackupConfig = {
      id: `backup_${Date.now()}`,
      workspace_id: "default",
      ...validation.data,
      is_active: true,
      next_backup_at: calculateNextBackup(validation.data.schedule),
      created_by: user.id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    backupConfigs.push(config);

    res.status(201).json({
      success: true,
      data: config
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create backup config"
    } as ApiResponse);
  }
};

export const startBackup: RequestHandler = async (req, res) => {
  try {
    const { configId } = req.params;
    const { backup_type = 'full' } = req.body;
    
    const config = backupConfigs.find(c => c.id === configId);
    if (!config) {
      return res.status(404).json({
        success: false,
        error: "Backup config not found"
      } as ApiResponse);
    }

    const execution: BackupExecution = {
      id: `exec_${Date.now()}`,
      config_id: configId,
      workspace_id: config.workspace_id,
      backup_type: backup_type as any,
      status: 'running',
      started_at: new Date().toISOString(),
      progress_percentage: 0,
      metrics: {
        files_processed: 0,
        bytes_processed: 0
      }
    };

    backupExecutions.push(execution);

    // Simulate backup progress
    simulateBackupProgress(execution.id);

    res.status(201).json({
      success: true,
      data: execution,
      message: "Backup started successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to start backup"
    } as ApiResponse);
  }
};

export const getBackupExecutions: RequestHandler = (req, res) => {
  try {
    const { config_id, status, limit = 20, offset = 0 } = req.query;
    
    let filteredExecutions = backupExecutions.filter(exec => exec.workspace_id === "default");
    
    if (config_id) {
      filteredExecutions = filteredExecutions.filter(exec => exec.config_id === config_id);
    }
    
    if (status) {
      filteredExecutions = filteredExecutions.filter(exec => exec.status === status);
    }
    
    // Sort by started date descending
    filteredExecutions.sort((a, b) => 
      new Date(b.started_at).getTime() - new Date(a.started_at).getTime()
    );
    
    const paginatedExecutions = filteredExecutions.slice(
      Number(offset), 
      Number(offset) + Number(limit)
    );
    
    res.json({
      success: true,
      data: {
        executions: paginatedExecutions,
        total: filteredExecutions.length,
        offset: Number(offset),
        limit: Number(limit)
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get backup executions"
    } as ApiResponse);
  }
};

export const getDisasterRecoveryPlans: RequestHandler = (req, res) => {
  try {
    const plans = disasterRecoveryPlans.filter(plan => plan.workspace_id === "default");
    
    res.json({
      success: true,
      data: plans
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get disaster recovery plans"
    } as ApiResponse);
  }
};

export const createDisasterRecoveryPlan: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = disasterRecoverySchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid disaster recovery plan",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const plan: DisasterRecoveryPlan = {
      id: `dr_${Date.now()}`,
      workspace_id: "default",
      ...validation.data,
      test_schedule: {
        ...validation.data.test_schedule,
        next_test_date: calculateNextTest(validation.data.test_schedule?.frequency || 'quarterly')
      },
      is_active: true,
      created_by: user.id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    disasterRecoveryPlans.push(plan);

    res.status(201).json({
      success: true,
      data: plan
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create disaster recovery plan"
    } as ApiResponse);
  }
};

// Helper functions
function calculateNextBackup(schedule: any): string {
  const now = new Date();
  const next = new Date(now);
  
  switch (schedule.frequency) {
    case 'hourly':
      next.setHours(next.getHours() + 1);
      break;
    case 'daily':
      next.setDate(next.getDate() + 1);
      if (schedule.hour !== undefined) {
        next.setHours(schedule.hour, 0, 0, 0);
      }
      break;
    case 'weekly':
      next.setDate(next.getDate() + 7);
      break;
    case 'monthly':
      next.setMonth(next.getMonth() + 1);
      break;
  }
  
  return next.toISOString();
}

function calculateNextTest(frequency: string): string {
  const now = new Date();
  const next = new Date(now);
  
  switch (frequency) {
    case 'monthly':
      next.setMonth(next.getMonth() + 1);
      break;
    case 'quarterly':
      next.setMonth(next.getMonth() + 3);
      break;
    case 'bi_annually':
      next.setMonth(next.getMonth() + 6);
      break;
    case 'annually':
      next.setFullYear(next.getFullYear() + 1);
      break;
  }
  
  return next.toISOString();
}

async function simulateBackupProgress(executionId: string) {
  for (let progress = 10; progress <= 100; progress += 10) {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const executionIndex = backupExecutions.findIndex(e => e.id === executionId);
    if (executionIndex !== -1) {
      backupExecutions[executionIndex].progress_percentage = progress;
      backupExecutions[executionIndex].metrics.files_processed = Math.floor(progress * 10);
      backupExecutions[executionIndex].metrics.bytes_processed = Math.floor(progress * 1000000);
      
      if (progress === 100) {
        backupExecutions[executionIndex].status = 'completed';
        backupExecutions[executionIndex].completed_at = new Date().toISOString();
        backupExecutions[executionIndex].duration_seconds = 50;
        backupExecutions[executionIndex].size_bytes = 100000000;
        backupExecutions[executionIndex].file_path = `/backups/${executionId}.tar.gz`;
        backupExecutions[executionIndex].checksum = 'sha256:abc123...';
      }
    }
  }
}
