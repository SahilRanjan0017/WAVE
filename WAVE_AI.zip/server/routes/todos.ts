import { RequestHandler } from "express";
import { z } from "zod";
import { Todo, CreateTodoRequest, UpdateTodoRequest, ApiResponse, User } from "@shared/api";

// Mock database
let todos: Todo[] = [
  {
    id: "1",
    user_id: "1",
    content: "Review the new design mockups",
    completed: false,
    created_at: new Date(Date.now() - 86400000).toISOString(),
    updated_at: new Date(Date.now() - 86400000).toISOString()
  },
  {
    id: "2",
    user_id: "1",
    content: "Set up the development environment",
    completed: true,
    created_at: new Date(Date.now() - 172800000).toISOString(),
    updated_at: new Date(Date.now() - 3600000).toISOString()
  }
];

// Validation schemas
const createTodoSchema = z.object({
  content: z.string().min(1).max(500)
});

const updateTodoSchema = z.object({
  content: z.string().min(1).max(500).optional(),
  completed: z.boolean().optional()
});

export const getTodos: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    
    const userTodos = todos
      .filter(todo => todo.user_id === user.id)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    res.json({
      success: true,
      data: userTodos
    } as ApiResponse<Todo[]>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const createTodo: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = createTodoSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid input",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const { content } = validation.data as CreateTodoRequest;

    const newTodo: Todo = {
      id: Date.now().toString(),
      user_id: user.id,
      content,
      completed: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    todos.push(newTodo);

    res.status(201).json({
      success: true,
      data: newTodo
    } as ApiResponse<Todo>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const updateTodo: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { todoId } = req.params;
    const validation = updateTodoSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid input",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const updates = validation.data as UpdateTodoRequest;

    const todoIndex = todos.findIndex(todo => todo.id === todoId && todo.user_id === user.id);
    if (todoIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Todo not found"
      } as ApiResponse);
    }

    // Update the todo
    if (updates.content !== undefined) {
      todos[todoIndex].content = updates.content;
    }
    if (updates.completed !== undefined) {
      todos[todoIndex].completed = updates.completed;
    }
    todos[todoIndex].updated_at = new Date().toISOString();

    res.json({
      success: true,
      data: todos[todoIndex]
    } as ApiResponse<Todo>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const deleteTodo: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { todoId } = req.params;

    const todoIndex = todos.findIndex(todo => todo.id === todoId && todo.user_id === user.id);
    if (todoIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Todo not found"
      } as ApiResponse);
    }

    todos.splice(todoIndex, 1);

    res.json({
      success: true,
      message: "Todo deleted successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};
