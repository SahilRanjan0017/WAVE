import { RequestHandler } from "express";
import { z } from "zod";
import { ApiResponse, User } from "@shared/api";
import crypto from 'crypto';

// Advanced notification interfaces
interface NotificationRule {
  id: string;
  user_id: string;
  workspace_id: string;
  name: string;
  description?: string;
  is_active: boolean;
  priority: number; // 1-10, higher = more important
  conditions: {
    triggers: ('mention' | 'dm' | 'keyword' | 'channel' | 'file_share' | 'meeting' | 'workflow')[];
    keywords?: string[];
    channels?: string[];
    users?: string[];
    time_range?: {
      start_hour: number;
      end_hour: number;
      days: number[]; // 0-6, Sunday = 0
      timezone: string;
    };
    content_filters?: {
      contains?: string[];
      excludes?: string[];
      min_length?: number;
      has_attachments?: boolean;
    };
  };
  actions: {
    notification_types: ('push' | 'email' | 'sms' | 'waveai' | 'webhook')[];
    delivery_method: 'immediate' | 'batched' | 'digest';
    batch_interval_minutes?: number;
    custom_sound?: string;
    vibration_pattern?: number[];
    email_template?: string;
    webhook_url?: string;
    escalation?: {
      delay_minutes: number;
      fallback_methods: ('email' | 'sms' | 'waveai')[];
    };
  };
  created_at: string;
  updated_at: string;
  last_triggered?: string;
  trigger_count: number;
}

interface EnhancedNotification {
  id: string;
  user_id: string;
  workspace_id: string;
  type: 'mention' | 'dm' | 'reaction' | 'file_share' | 'meeting' | 'workflow' | 'system' | 'custom';
  priority: 'critical' | 'high' | 'medium' | 'low';
  title: string;
  message: string;
  rich_content?: {
    image_url?: string;
    action_buttons?: {
      label: string;
      action: string;
      style: 'primary' | 'secondary' | 'danger';
    }[];
    progress?: {
      current: number;
      total: number;
      label: string;
    };
    metadata?: Record<string, any>;
  };
  source: {
    type: 'message' | 'file' | 'meeting' | 'workflow' | 'user' | 'system';
    id: string;
    url?: string;
  };
  read: boolean;
  read_at?: string;
  delivered_via: ('push' | 'email' | 'sms' | 'waveai' | 'webhook')[];
  delivery_status: {
    method: string;
    status: 'pending' | 'delivered' | 'failed' | 'bounced';
    delivered_at?: string;
    error_message?: string;
  }[];
  scheduled_for?: string;
  expires_at?: string;
  category?: string;
  tags: string[];
  created_at: string;
  rule_id?: string;
}

interface NotificationDigest {
  id: string;
  user_id: string;
  workspace_id: string;
  type: 'daily' | 'weekly' | 'monthly' | 'custom';
  period: {
    start: string;
    end: string;
  };
  summary: {
    total_notifications: number;
    unread_count: number;
    by_priority: {
      critical: number;
      high: number;
      medium: number;
      low: number;
    };
    by_type: Record<string, number>;
    top_channels: {
      channel_id: string;
      channel_name: string;
      count: number;
    }[];
    top_mentions: {
      user_id: string;
      user_name: string;
      count: number;
    }[];
  };
  highlights: {
    most_active_day: string;
    busiest_hour: number;
    trending_topics: string[];
    important_missed: EnhancedNotification[];
  };
  generated_at: string;
  delivered_via: string[];
  opened_at?: string;
}

interface NotificationTemplate {
  id: string;
  workspace_id: string;
  name: string;
  description: string;
  category: 'system' | 'marketing' | 'workflow' | 'meeting' | 'custom';
  subject_template: string;
  body_template: string;
  variables: {
    name: string;
    type: 'string' | 'number' | 'date' | 'boolean' | 'url';
    required: boolean;
    default_value?: any;
    description?: string;
  }[];
  styling: {
    theme: 'default' | 'minimal' | 'branded';
    colors: {
      primary: string;
      secondary: string;
      background: string;
      text: string;
    };
    logo_url?: string;
    custom_css?: string;
  };
  channels: ('email' | 'push' | 'sms' | 'waveai')[];
  is_active: boolean;
  usage_count: number;
  created_by: string;
  created_at: string;
  updated_at: string;
}

interface PushSubscription {
  id: string;
  user_id: string;
  workspace_id: string;
  endpoint: string;
  keys: {
    p256dh: string;
    auth: string;
  };
  device_info: {
    user_agent: string;
    platform: string;
    device_type: 'desktop' | 'mobile' | 'tablet';
  };
  is_active: boolean;
  created_at: string;
  last_used: string;
}

// Mock databases
let notificationRules: NotificationRule[] = [
  {
    id: "rule-mentions",
    user_id: "1",
    workspace_id: "default",
    name: "High Priority Mentions",
    description: "Get notified immediately when mentioned",
    is_active: true,
    priority: 9,
    conditions: {
      triggers: ['mention'],
      keywords: ['urgent', 'asap', 'important'],
      time_range: {
        start_hour: 9,
        end_hour: 18,
        days: [1, 2, 3, 4, 5],
        timezone: 'UTC'
      }
    },
    actions: {
      notification_types: ['push', 'email'],
      delivery_method: 'immediate',
      custom_sound: 'urgent.mp3',
      escalation: {
        delay_minutes: 10,
        fallback_methods: ['sms']
      }
    },
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    trigger_count: 15
  },
  {
    id: "rule-digest",
    user_id: "1",
    workspace_id: "default",
    name: "Daily Digest",
    description: "Daily summary of activity",
    is_active: true,
    priority: 3,
    conditions: {
      triggers: ['dm', 'channel', 'file_share'],
      channels: ['general', 'announcements']
    },
    actions: {
      notification_types: ['email'],
      delivery_method: 'digest',
      batch_interval_minutes: 1440, // 24 hours
      email_template: 'daily-digest'
    },
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    trigger_count: 7
  }
];

let enhancedNotifications: EnhancedNotification[] = [];
let notificationDigests: NotificationDigest[] = [];
let notificationTemplates: NotificationTemplate[] = [
  {
    id: "template-daily-digest",
    workspace_id: "default",
    name: "Daily Digest",
    description: "Daily summary email template",
    category: "system",
    subject_template: "Your daily digest for {{workspace_name}} - {{date}}",
    body_template: `
    <h2>Daily Summary for {{workspace_name}}</h2>
    <p>Here's what happened today:</p>
    
    <h3>Activity Summary</h3>
    <ul>
      <li>{{total_messages}} messages</li>
      <li>{{total_mentions}} mentions</li>
      <li>{{total_files}} files shared</li>
    </ul>
    
    <h3>Top Channels</h3>
    {{#each top_channels}}
    <p>• {{name}}: {{count}} messages</p>
    {{/each}}
    
    <p><a href="{{workspace_url}}">Open {{workspace_name}}</a></p>
    `,
    variables: [
      { name: "workspace_name", type: "string", required: true, description: "Name of the workspace" },
      { name: "date", type: "date", required: true, description: "Date of the digest" },
      { name: "total_messages", type: "number", required: true, description: "Total messages count" },
      { name: "workspace_url", type: "url", required: true, description: "URL to workspace" }
    ],
    styling: {
      theme: "default",
      colors: {
        primary: "#3b82f6",
        secondary: "#64748b",
        background: "#ffffff",
        text: "#1f2937"
      }
    },
    channels: ["email"],
    is_active: true,
    usage_count: 50,
    created_by: "system",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

let pushSubscriptions: PushSubscription[] = [];

// Validation schemas
const notificationRuleSchema = z.object({
  name: z.string().min(1).max(100),
  description: z.string().max(500).optional(),
  priority: z.number().min(1).max(10).default(5),
  conditions: z.object({
    triggers: z.array(z.enum(['mention', 'dm', 'keyword', 'channel', 'file_share', 'meeting', 'workflow'])),
    keywords: z.array(z.string()).optional(),
    channels: z.array(z.string()).optional(),
    users: z.array(z.string()).optional(),
    time_range: z.object({
      start_hour: z.number().min(0).max(23),
      end_hour: z.number().min(0).max(23),
      days: z.array(z.number().min(0).max(6)),
      timezone: z.string()
    }).optional(),
    content_filters: z.object({
      contains: z.array(z.string()).optional(),
      excludes: z.array(z.string()).optional(),
      min_length: z.number().optional(),
      has_attachments: z.boolean().optional()
    }).optional()
  }),
  actions: z.object({
    notification_types: z.array(z.enum(['push', 'email', 'sms', 'waveai', 'webhook'])),
    delivery_method: z.enum(['immediate', 'batched', 'digest']).default('immediate'),
    batch_interval_minutes: z.number().optional(),
    custom_sound: z.string().optional(),
    vibration_pattern: z.array(z.number()).optional(),
    email_template: z.string().optional(),
    webhook_url: z.string().url().optional(),
    escalation: z.object({
      delay_minutes: z.number(),
      fallback_methods: z.array(z.enum(['email', 'sms', 'waveai']))
    }).optional()
  })
});

const createNotificationSchema = z.object({
  type: z.enum(['mention', 'dm', 'reaction', 'file_share', 'meeting', 'workflow', 'system', 'custom']),
  priority: z.enum(['critical', 'high', 'medium', 'low']).default('medium'),
  title: z.string().min(1).max(200),
  message: z.string().min(1).max(1000),
  rich_content: z.object({
    image_url: z.string().url().optional(),
    action_buttons: z.array(z.object({
      label: z.string(),
      action: z.string(),
      style: z.enum(['primary', 'secondary', 'danger']).default('primary')
    })).optional(),
    progress: z.object({
      current: z.number(),
      total: z.number(),
      label: z.string()
    }).optional(),
    metadata: z.record(z.any()).optional()
  }).optional(),
  source: z.object({
    type: z.enum(['message', 'file', 'meeting', 'workflow', 'user', 'system']),
    id: z.string(),
    url: z.string().url().optional()
  }),
  recipient_ids: z.array(z.string()),
  scheduled_for: z.string().optional(),
  expires_at: z.string().optional(),
  category: z.string().optional(),
  tags: z.array(z.string()).default([])
});

const pushSubscriptionSchema = z.object({
  endpoint: z.string().url(),
  keys: z.object({
    p256dh: z.string(),
    auth: z.string()
  }),
  device_info: z.object({
    user_agent: z.string(),
    platform: z.string(),
    device_type: z.enum(['desktop', 'mobile', 'tablet'])
  })
});

// Helper functions
function matchesRule(notification: EnhancedNotification, rule: NotificationRule): boolean {
  // Check if notification matches rule conditions
  if (!rule.is_active) return false;
  
  // Check triggers
  if (!rule.conditions.triggers.includes(notification.type as any)) return false;
  
  // Check keywords
  if (rule.conditions.keywords?.length) {
    const hasKeyword = rule.conditions.keywords.some(keyword => 
      notification.title.toLowerCase().includes(keyword.toLowerCase()) ||
      notification.message.toLowerCase().includes(keyword.toLowerCase())
    );
    if (!hasKeyword) return false;
  }
  
  // Check time range
  if (rule.conditions.time_range) {
    const now = new Date();
    const hour = now.getHours();
    const day = now.getDay();
    
    if (hour < rule.conditions.time_range.start_hour || 
        hour > rule.conditions.time_range.end_hour ||
        !rule.conditions.time_range.days.includes(day)) {
      return false;
    }
  }
  
  return true;
}

async function processNotification(notification: EnhancedNotification): Promise<void> {
  // Find matching rules for the user
  const userRules = notificationRules.filter(rule => 
    rule.user_id === notification.user_id && 
    matchesRule(notification, rule)
  );
  
  // Sort by priority (highest first)
  userRules.sort((a, b) => b.priority - a.priority);
  
  if (userRules.length === 0) {
    // Use default notification behavior
    await deliverNotification(notification, ['push']);
    return;
  }
  
  // Use the highest priority rule
  const rule = userRules[0];
  notification.rule_id = rule.id;
  
  // Update rule stats
  const ruleIndex = notificationRules.findIndex(r => r.id === rule.id);
  if (ruleIndex !== -1) {
    notificationRules[ruleIndex].trigger_count++;
    notificationRules[ruleIndex].last_triggered = new Date().toISOString();
  }
  
  // Handle delivery based on rule
  if (rule.actions.delivery_method === 'immediate') {
    await deliverNotification(notification, rule.actions.notification_types);
  } else if (rule.actions.delivery_method === 'batched') {
    // Schedule for batch delivery
    notification.scheduled_for = new Date(
      Date.now() + (rule.actions.batch_interval_minutes || 60) * 60 * 1000
    ).toISOString();
  }
  // Digest notifications are handled separately
}

async function deliverNotification(notification: EnhancedNotification, methods: string[]): Promise<void> {
  const deliveryPromises = methods.map(async method => {
    try {
      switch (method) {
        case 'push':
          await deliverPushNotification(notification);
          break;
        case 'email':
          await deliverEmailNotification(notification);
          break;
        case 'sms':
          await deliverSMSNotification(notification);
          break;
        case 'waveai':
          await deliverWaveAINotification(notification);
          break;
        case 'webhook':
          await deliverWebhookNotification(notification);
          break;
      }
      
      notification.delivery_status.push({
        method,
        status: 'delivered',
        delivered_at: new Date().toISOString()
      });
    } catch (error) {
      notification.delivery_status.push({
        method,
        status: 'failed',
        error_message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  await Promise.all(deliveryPromises);
  notification.delivered_via = methods;
}

async function deliverPushNotification(notification: EnhancedNotification): Promise<void> {
  const userSubscriptions = pushSubscriptions.filter(s => 
    s.user_id === notification.user_id && s.is_active
  );
  
  for (const subscription of userSubscriptions) {
    // In a real implementation, use a library like web-push
    console.log(`Sending push notification to ${subscription.endpoint}`, {
      title: notification.title,
      body: notification.message,
      icon: '/icon-192x192.png',
      badge: '/badge-72x72.png',
      data: {
        notification_id: notification.id,
        source: notification.source
      }
    });
  }
}

async function deliverEmailNotification(notification: EnhancedNotification): Promise<void> {
  // In a real implementation, use an email service like SendGrid, Mailgun, etc.
  console.log(`Sending email notification to user ${notification.user_id}`, {
    subject: notification.title,
    body: notification.message,
    html: `<h2>${notification.title}</h2><p>${notification.message}</p>`
  });
}

async function deliverSMSNotification(notification: EnhancedNotification): Promise<void> {
  // In a real implementation, use an SMS service like Twilio
  console.log(`Sending SMS notification to user ${notification.user_id}`, {
    message: `${notification.title}: ${notification.message}`
  });
}

async function deliverWaveAINotification(notification: EnhancedNotification): Promise<void> {
  // In a real implementation, use WAVE AI internal messaging
  console.log(`Sending WAVE AI notification to user ${notification.user_id}`, {
    text: notification.message,
    attachments: [{
      title: notification.title,
      color: notification.priority === 'critical' ? 'danger' : 'good'
    }]
  });
}

async function deliverWebhookNotification(notification: EnhancedNotification): Promise<void> {
  // In a real implementation, make HTTP request to webhook URL
  console.log(`Sending webhook notification`, {
    notification,
    timestamp: new Date().toISOString()
  });
}

function generateDigest(userId: string, period: { start: string; end: string }): NotificationDigest {
  const userNotifications = enhancedNotifications.filter(n => 
    n.user_id === userId &&
    n.created_at >= period.start &&
    n.created_at <= period.end
  );
  
  const summary = {
    total_notifications: userNotifications.length,
    unread_count: userNotifications.filter(n => !n.read).length,
    by_priority: {
      critical: userNotifications.filter(n => n.priority === 'critical').length,
      high: userNotifications.filter(n => n.priority === 'high').length,
      medium: userNotifications.filter(n => n.priority === 'medium').length,
      low: userNotifications.filter(n => n.priority === 'low').length
    },
    by_type: userNotifications.reduce((acc, n) => {
      acc[n.type] = (acc[n.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>),
    top_channels: [], // Would be calculated from actual data
    top_mentions: []   // Would be calculated from actual data
  };
  
  return {
    id: `digest_${Date.now()}`,
    user_id: userId,
    workspace_id: "default",
    type: 'daily',
    period,
    summary,
    highlights: {
      most_active_day: period.start.split('T')[0],
      busiest_hour: 10,
      trending_topics: ['project-alpha', 'quarterly-review', 'team-sync'],
      important_missed: userNotifications
        .filter(n => !n.read && n.priority === 'critical')
        .slice(0, 5)
    },
    generated_at: new Date().toISOString(),
    delivered_via: ['email']
  };
}

// API endpoints
export const getNotificationRules: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const userRules = notificationRules.filter(rule => rule.user_id === user.id);
    
    res.json({
      success: true,
      data: userRules
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get notification rules"
    } as ApiResponse);
  }
};

export const createNotificationRule: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = notificationRuleSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid rule data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const rule: NotificationRule = {
      id: `rule_${Date.now()}`,
      user_id: user.id,
      workspace_id: "default",
      ...validation.data,
      is_active: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      trigger_count: 0
    };

    notificationRules.push(rule);

    res.status(201).json({
      success: true,
      data: rule
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create notification rule"
    } as ApiResponse);
  }
};

export const updateNotificationRule: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { ruleId } = req.params;
    
    const ruleIndex = notificationRules.findIndex(r => 
      r.id === ruleId && r.user_id === user.id
    );

    if (ruleIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Notification rule not found"
      } as ApiResponse);
    }

    notificationRules[ruleIndex] = {
      ...notificationRules[ruleIndex],
      ...req.body,
      updated_at: new Date().toISOString()
    };

    res.json({
      success: true,
      data: notificationRules[ruleIndex]
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to update notification rule"
    } as ApiResponse);
  }
};

export const getEnhancedNotifications: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { 
      priority, 
      type, 
      unread_only = 'false', 
      limit = 50, 
      offset = 0,
      category,
      date_from,
      date_to
    } = req.query;
    
    let filteredNotifications = enhancedNotifications.filter(n => n.user_id === user.id);
    
    if (priority) {
      filteredNotifications = filteredNotifications.filter(n => n.priority === priority);
    }
    
    if (type) {
      filteredNotifications = filteredNotifications.filter(n => n.type === type);
    }
    
    if (unread_only === 'true') {
      filteredNotifications = filteredNotifications.filter(n => !n.read);
    }
    
    if (category) {
      filteredNotifications = filteredNotifications.filter(n => n.category === category);
    }
    
    if (date_from) {
      filteredNotifications = filteredNotifications.filter(n => n.created_at >= date_from);
    }
    
    if (date_to) {
      filteredNotifications = filteredNotifications.filter(n => n.created_at <= date_to);
    }
    
    // Sort by creation date descending
    filteredNotifications.sort((a, b) => 
      new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
    
    const paginatedNotifications = filteredNotifications.slice(
      Number(offset), 
      Number(offset) + Number(limit)
    );
    
    res.json({
      success: true,
      data: {
        notifications: paginatedNotifications,
        total: filteredNotifications.length,
        unread_count: enhancedNotifications.filter(n => n.user_id === user.id && !n.read).length,
        offset: Number(offset),
        limit: Number(limit)
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get notifications"
    } as ApiResponse);
  }
};

export const createEnhancedNotification: RequestHandler = async (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = createNotificationSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid notification data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const { recipient_ids, ...notificationData } = validation.data;
    const createdNotifications: EnhancedNotification[] = [];

    for (const recipientId of recipient_ids) {
      const notification: EnhancedNotification = {
        id: `notif_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
        user_id: recipientId,
        workspace_id: "default",
        ...notificationData,
        read: false,
        delivered_via: [],
        delivery_status: [],
        created_at: new Date().toISOString()
      };

      enhancedNotifications.push(notification);
      createdNotifications.push(notification);

      // Process notification through rules engine
      if (!notification.scheduled_for) {
        await processNotification(notification);
      }
    }

    res.status(201).json({
      success: true,
      data: createdNotifications,
      message: `Created ${createdNotifications.length} notifications`
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create notification"
    } as ApiResponse);
  }
};

export const markNotificationRead: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { notificationId } = req.params;
    
    const notificationIndex = enhancedNotifications.findIndex(n => 
      n.id === notificationId && n.user_id === user.id
    );

    if (notificationIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Notification not found"
      } as ApiResponse);
    }

    enhancedNotifications[notificationIndex].read = true;
    enhancedNotifications[notificationIndex].read_at = new Date().toISOString();

    res.json({
      success: true,
      data: enhancedNotifications[notificationIndex]
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to mark notification as read"
    } as ApiResponse);
  }
};

export const subscribeToPush: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = pushSubscriptionSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid subscription data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    // Check if subscription already exists
    const existingSubscription = pushSubscriptions.find(s => 
      s.user_id === user.id && s.endpoint === validation.data.endpoint
    );

    if (existingSubscription) {
      // Update existing subscription
      const index = pushSubscriptions.findIndex(s => s.id === existingSubscription.id);
      pushSubscriptions[index] = {
        ...existingSubscription,
        ...validation.data,
        is_active: true,
        last_used: new Date().toISOString()
      };
      
      return res.json({
        success: true,
        data: pushSubscriptions[index]
      } as ApiResponse);
    }

    const subscription: PushSubscription = {
      id: `sub_${Date.now()}`,
      user_id: user.id,
      workspace_id: "default",
      ...validation.data,
      is_active: true,
      created_at: new Date().toISOString(),
      last_used: new Date().toISOString()
    };

    pushSubscriptions.push(subscription);

    res.status(201).json({
      success: true,
      data: subscription
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to subscribe to push notifications"
    } as ApiResponse);
  }
};

export const generateNotificationDigest: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { period_start, period_end, type = 'daily' } = req.body;
    
    const period = {
      start: period_start || new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      end: period_end || new Date().toISOString()
    };

    const digest = generateDigest(user.id, period);
    notificationDigests.push(digest);

    res.status(201).json({
      success: true,
      data: digest
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to generate notification digest"
    } as ApiResponse);
  }
};

export const getNotificationDigests: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const userDigests = notificationDigests.filter(d => d.user_id === user.id);
    
    // Sort by generated date descending
    userDigests.sort((a, b) => 
      new Date(b.generated_at).getTime() - new Date(a.generated_at).getTime()
    );
    
    res.json({
      success: true,
      data: userDigests
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get notification digests"
    } as ApiResponse);
  }
};

export const getNotificationAnalytics: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { period = '30d' } = req.query;
    
    const userNotifications = enhancedNotifications.filter(n => n.user_id === user.id);
    const userRules = notificationRules.filter(r => r.user_id === user.id);
    
    // Calculate analytics
    const totalNotifications = userNotifications.length;
    const unreadCount = userNotifications.filter(n => !n.read).length;
    const readRate = totalNotifications > 0 ? ((totalNotifications - unreadCount) / totalNotifications) * 100 : 0;
    
    const byPriority = {
      critical: userNotifications.filter(n => n.priority === 'critical').length,
      high: userNotifications.filter(n => n.priority === 'high').length,
      medium: userNotifications.filter(n => n.priority === 'medium').length,
      low: userNotifications.filter(n => n.priority === 'low').length
    };
    
    const byType = userNotifications.reduce((acc, n) => {
      acc[n.type] = (acc[n.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    const deliveryStats = {
      push: userNotifications.filter(n => n.delivered_via.includes('push')).length,
      email: userNotifications.filter(n => n.delivered_via.includes('email')).length,
      sms: userNotifications.filter(n => n.delivered_via.includes('sms')).length,
      waveai: userNotifications.filter(n => n.delivered_via.includes('waveai')).length
    };
    
    // Generate time series data (mock)
    const timeSeriesData = Array.from({ length: 30 }, (_, i) => ({
      date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      notifications: Math.floor(Math.random() * 20),
      read: Math.floor(Math.random() * 15),
      critical: Math.floor(Math.random() * 3)
    }));

    const analytics = {
      period,
      total_notifications: totalNotifications,
      unread_count: unreadCount,
      read_rate: Math.round(readRate),
      by_priority: byPriority,
      by_type: byType,
      delivery_stats: deliveryStats,
      active_rules: userRules.filter(r => r.is_active).length,
      most_triggered_rule: userRules.sort((a, b) => b.trigger_count - a.trigger_count)[0],
      time_series: timeSeriesData,
      avg_notifications_per_day: Math.round(totalNotifications / 30),
      peak_notification_hour: 14 // 2 PM
    };

    res.json({
      success: true,
      data: analytics
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get notification analytics"
    } as ApiResponse);
  }
};
