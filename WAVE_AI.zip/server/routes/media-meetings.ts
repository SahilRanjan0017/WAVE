import { RequestHandler } from "express";
import { z } from "zod";
import { ApiResponse, User } from "@shared/api";
import crypto from 'crypto';

// Enhanced meeting and media interfaces
interface MeetingRoom {
  id: string;
  workspace_id: string;
  name: string;
  description?: string;
  type: 'persistent' | 'scheduled' | 'instant';
  status: 'active' | 'inactive' | 'in_meeting';
  capacity: number;
  is_public: boolean;
  settings: {
    recording_enabled: boolean;
    transcription_enabled: boolean;
    auto_join_audio: boolean;
    screen_sharing_enabled: boolean;
    chat_enabled: boolean;
    waiting_room: boolean;
    require_auth: boolean;
    allow_breakout_rooms: boolean;
  };
  participants: {
    user_id: string;
    role: 'host' | 'co-host' | 'participant' | 'observer';
    joined_at: string;
    status: 'connected' | 'disconnected' | 'muted' | 'speaking';
    permissions: string[];
  }[];
  created_by: string;
  created_at: string;
  updated_at: string;
  last_meeting_at?: string;
  total_meetings: number;
  total_duration_minutes: number;
}

interface MeetingSession {
  id: string;
  room_id: string;
  title: string;
  started_at: string;
  ended_at?: string;
  duration_minutes?: number;
  host_id: string;
  participants: {
    user_id: string;
    joined_at: string;
    left_at?: string;
    duration_minutes: number;
    role: string;
  }[];
  recording?: {
    id: string;
    file_url: string;
    thumbnail_url?: string;
    size_bytes: number;
    duration_seconds: number;
    format: 'mp4' | 'webm';
    quality: '720p' | '1080p' | '4k';
    status: 'processing' | 'ready' | 'failed';
  };
  transcription?: {
    id: string;
    text: string;
    speakers: {
      speaker_id: string;
      name: string;
      segments: {
        start_time: number;
        end_time: number;
        text: string;
        confidence: number;
      }[];
    }[];
    language: string;
    accuracy: number;
    status: 'processing' | 'ready' | 'failed';
  };
  summary?: {
    key_points: string[];
    action_items: string[];
    decisions: string[];
    next_meeting_date?: string;
    generated_at: string;
  };
  chat_messages: {
    id: string;
    user_id: string;
    message: string;
    timestamp: string;
    type: 'text' | 'file' | 'poll';
  }[];
  screen_recordings: {
    id: string;
    user_id: string;
    file_url: string;
    duration_seconds: number;
    timestamp: string;
  }[];
}

interface VoiceClip {
  id: string;
  workspace_id: string;
  created_by: string;
  title: string;
  description?: string;
  file_url: string;
  duration_seconds: number;
  file_size_bytes: number;
  waveform_data: number[];
  transcription?: {
    text: string;
    confidence: number;
    language: string;
  };
  tags: string[];
  is_public: boolean;
  created_at: string;
  play_count: number;
  liked_by: string[];
}

interface MeetingTemplate {
  id: string;
  workspace_id: string;
  name: string;
  description: string;
  agenda_template: {
    items: {
      title: string;
      duration_minutes: number;
      type: 'discussion' | 'presentation' | 'decision' | 'break';
      presenter?: string;
    }[];
    total_duration_minutes: number;
  };
  settings: Partial<MeetingRoom['settings']>;
  participants: {
    user_id: string;
    role: 'host' | 'participant';
    required: boolean;
  }[];
  created_by: string;
  created_at: string;
  usage_count: number;
}

// Mock databases
let meetingRooms: MeetingRoom[] = [
  {
    id: "room-general",
    workspace_id: "default",
    name: "General Discussion",
    description: "Open discussion room for team collaboration",
    type: "persistent",
    status: "inactive",
    capacity: 50,
    is_public: true,
    settings: {
      recording_enabled: true,
      transcription_enabled: true,
      auto_join_audio: false,
      screen_sharing_enabled: true,
      chat_enabled: true,
      waiting_room: false,
      require_auth: true,
      allow_breakout_rooms: true
    },
    participants: [],
    created_by: "1",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    total_meetings: 0,
    total_duration_minutes: 0
  },
  {
    id: "room-standup",
    workspace_id: "default",
    name: "Daily Standup",
    description: "Quick daily sync for the team",
    type: "scheduled",
    status: "inactive",
    capacity: 20,
    is_public: false,
    settings: {
      recording_enabled: true,
      transcription_enabled: true,
      auto_join_audio: true,
      screen_sharing_enabled: false,
      chat_enabled: true,
      waiting_room: false,
      require_auth: true,
      allow_breakout_rooms: false
    },
    participants: [],
    created_by: "1",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    total_meetings: 15,
    total_duration_minutes: 375
  }
];

let meetingSessions: MeetingSession[] = [];
let voiceClips: VoiceClip[] = [];
let meetingTemplates: MeetingTemplate[] = [
  {
    id: "template-standup",
    workspace_id: "default",
    name: "Daily Standup",
    description: "Standard daily standup meeting format",
    agenda_template: {
      items: [
        { title: "What did you work on yesterday?", duration_minutes: 10, type: "discussion" },
        { title: "What will you work on today?", duration_minutes: 10, type: "discussion" },
        { title: "Any blockers or help needed?", duration_minutes: 5, type: "discussion" }
      ],
      total_duration_minutes: 25
    },
    settings: {
      recording_enabled: true,
      transcription_enabled: true,
      auto_join_audio: true,
      screen_sharing_enabled: false
    },
    participants: [],
    created_by: "1",
    created_at: new Date().toISOString(),
    usage_count: 50
  }
];

// Validation schemas
const createRoomSchema = z.object({
  name: z.string().min(1).max(100),
  description: z.string().max(500).optional(),
  type: z.enum(['persistent', 'scheduled', 'instant']).default('persistent'),
  capacity: z.number().min(2).max(1000).default(50),
  is_public: z.boolean().default(false),
  settings: z.object({
    recording_enabled: z.boolean().default(true),
    transcription_enabled: z.boolean().default(true),
    auto_join_audio: z.boolean().default(false),
    screen_sharing_enabled: z.boolean().default(true),
    chat_enabled: z.boolean().default(true),
    waiting_room: z.boolean().default(false),
    require_auth: z.boolean().default(true),
    allow_breakout_rooms: z.boolean().default(true)
  }).default({})
});

const startMeetingSchema = z.object({
  title: z.string().min(1).max(200),
  agenda: z.array(z.object({
    title: z.string(),
    duration_minutes: z.number(),
    type: z.enum(['discussion', 'presentation', 'decision', 'break'])
  })).optional()
});

const voiceClipSchema = z.object({
  title: z.string().min(1).max(100),
  description: z.string().max(500).optional(),
  duration_seconds: z.number().min(1).max(300), // Max 5 minutes
  file_size_bytes: z.number(),
  transcription_text: z.string().optional(),
  tags: z.array(z.string()).default([]),
  is_public: z.boolean().default(false)
});

const meetingTemplateSchema = z.object({
  name: z.string().min(1).max(100),
  description: z.string().max(500),
  agenda_template: z.object({
    items: z.array(z.object({
      title: z.string(),
      duration_minutes: z.number().min(1),
      type: z.enum(['discussion', 'presentation', 'decision', 'break']),
      presenter: z.string().optional()
    }))
  }),
  settings: z.object({
    recording_enabled: z.boolean().optional(),
    transcription_enabled: z.boolean().optional(),
    auto_join_audio: z.boolean().optional(),
    screen_sharing_enabled: z.boolean().optional(),
    chat_enabled: z.boolean().optional(),
    waiting_room: z.boolean().optional(),
    require_auth: z.boolean().optional(),
    allow_breakout_rooms: z.boolean().optional()
  }).optional(),
  participants: z.array(z.object({
    user_id: z.string(),
    role: z.enum(['host', 'participant']),
    required: z.boolean()
  })).default([])
});

// Helper functions
function generateMeetingId(): string {
  return `meeting_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
}

function generateSessionId(): string {
  return `session_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
}

function simulateTranscription(duration: number): any {
  return {
    id: `transcript_${Date.now()}`,
    text: "This is a simulated transcription of the meeting. In a real implementation, this would be generated by an AI transcription service like OpenAI Whisper, Google Speech-to-Text, or Azure Speech Services.",
    speakers: [
      {
        speaker_id: "speaker_1",
        name: "John Doe",
        segments: [
          {
            start_time: 0,
            end_time: 30,
            text: "Welcome everyone to today's meeting. Let's start with our agenda.",
            confidence: 0.95
          }
        ]
      },
      {
        speaker_id: "speaker_2", 
        name: "Jane Smith",
        segments: [
          {
            start_time: 30,
            end_time: 60,
            text: "Thanks John. I'd like to discuss the project updates first.",
            confidence: 0.92
          }
        ]
      }
    ],
    language: "en-US",
    accuracy: 0.94,
    status: "ready" as const
  };
}

function generateMeetingSummary(transcription: any): any {
  return {
    key_points: [
      "Project is on track for Q4 delivery",
      "Need to resolve integration issues with payment system",
      "Team capacity planning for next sprint"
    ],
    action_items: [
      "John to follow up with payment provider by Friday",
      "Jane to update sprint planning board",
      "Schedule technical review session next week"
    ],
    decisions: [
      "Approved budget increase for additional testing",
      "Decided to extend current sprint by 2 days"
    ],
    generated_at: new Date().toISOString()
  };
}

// API endpoints
export const getMeetingRooms: RequestHandler = (req, res) => {
  try {
    const { type, status, public_only } = req.query;
    
    let filteredRooms = meetingRooms.filter(room => 
      room.workspace_id === "default" // In production, get from context
    );
    
    if (type) {
      filteredRooms = filteredRooms.filter(room => room.type === type);
    }
    
    if (status) {
      filteredRooms = filteredRooms.filter(room => room.status === status);
    }
    
    if (public_only === 'true') {
      filteredRooms = filteredRooms.filter(room => room.is_public);
    }
    
    res.json({
      success: true,
      data: filteredRooms
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get meeting rooms"
    } as ApiResponse);
  }
};

export const createMeetingRoom: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = createRoomSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid room data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const room: MeetingRoom = {
      id: `room_${Date.now()}`,
      workspace_id: "default",
      ...validation.data,
      status: "inactive",
      participants: [],
      created_by: user.id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      total_meetings: 0,
      total_duration_minutes: 0
    };

    meetingRooms.push(room);

    res.status(201).json({
      success: true,
      data: room
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create meeting room"
    } as ApiResponse);
  }
};

export const startMeeting: RequestHandler = async (req, res) => {
  try {
    const user = (req as any).user as User;
    const { roomId } = req.params;
    const validation = startMeetingSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid meeting data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const room = meetingRooms.find(r => r.id === roomId);
    if (!room) {
      return res.status(404).json({
        success: false,
        error: "Meeting room not found"
      } as ApiResponse);
    }

    // Check if room is already in a meeting
    if (room.status === 'in_meeting') {
      return res.status(400).json({
        success: false,
        error: "Room is already in a meeting"
      } as ApiResponse);
    }

    const session: MeetingSession = {
      id: generateSessionId(),
      room_id: roomId,
      title: validation.data.title,
      started_at: new Date().toISOString(),
      host_id: user.id,
      participants: [
        {
          user_id: user.id,
          joined_at: new Date().toISOString(),
          duration_minutes: 0,
          role: 'host'
        }
      ],
      chat_messages: [],
      screen_recordings: []
    };

    meetingSessions.push(session);

    // Update room status
    const roomIndex = meetingRooms.findIndex(r => r.id === roomId);
    if (roomIndex !== -1) {
      meetingRooms[roomIndex].status = 'in_meeting';
      meetingRooms[roomIndex].participants = [
        {
          user_id: user.id,
          role: 'host',
          joined_at: new Date().toISOString(),
          status: 'connected',
          permissions: ['all']
        }
      ];
    }

    res.status(201).json({
      success: true,
      data: session,
      message: "Meeting started successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to start meeting"
    } as ApiResponse);
  }
};

export const endMeeting: RequestHandler = async (req, res) => {
  try {
    const { sessionId } = req.params;
    const user = (req as any).user as User;
    
    const sessionIndex = meetingSessions.findIndex(s => s.id === sessionId);
    if (sessionIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Meeting session not found"
      } as ApiResponse);
    }

    const session = meetingSessions[sessionIndex];
    
    // Only host can end meeting
    if (session.host_id !== user.id) {
      return res.status(403).json({
        success: false,
        error: "Only the host can end the meeting"
      } as ApiResponse);
    }

    const endTime = new Date();
    const startTime = new Date(session.started_at);
    const durationMinutes = Math.round((endTime.getTime() - startTime.getTime()) / (1000 * 60));

    // Update session
    meetingSessions[sessionIndex] = {
      ...session,
      ended_at: endTime.toISOString(),
      duration_minutes: durationMinutes,
      participants: session.participants.map(p => ({
        ...p,
        left_at: p.left_at || endTime.toISOString(),
        duration_minutes: Math.round((endTime.getTime() - new Date(p.joined_at).getTime()) / (1000 * 60))
      }))
    };

    // Simulate recording and transcription processing
    if (req.body.save_recording) {
      meetingSessions[sessionIndex].recording = {
        id: `rec_${Date.now()}`,
        file_url: `https://recordings.example.com/${sessionId}.mp4`,
        thumbnail_url: `https://recordings.example.com/${sessionId}_thumb.jpg`,
        size_bytes: Math.random() * 500000000, // Random size up to 500MB
        duration_seconds: durationMinutes * 60,
        format: 'mp4',
        quality: '1080p',
        status: 'processing'
      };

      // Simulate processing completion
      setTimeout(() => {
        const index = meetingSessions.findIndex(s => s.id === sessionId);
        if (index !== -1 && meetingSessions[index].recording) {
          meetingSessions[index].recording!.status = 'ready';
        }
      }, 5000);
    }

    if (req.body.save_transcription) {
      meetingSessions[sessionIndex].transcription = simulateTranscription(durationMinutes);
      meetingSessions[sessionIndex].summary = generateMeetingSummary(meetingSessions[sessionIndex].transcription);
    }

    // Update room status and stats
    const room = meetingRooms.find(r => r.id === session.room_id);
    if (room) {
      const roomIndex = meetingRooms.findIndex(r => r.id === session.room_id);
      meetingRooms[roomIndex] = {
        ...room,
        status: 'inactive',
        participants: [],
        last_meeting_at: endTime.toISOString(),
        total_meetings: room.total_meetings + 1,
        total_duration_minutes: room.total_duration_minutes + durationMinutes,
        updated_at: endTime.toISOString()
      };
    }

    res.json({
      success: true,
      data: meetingSessions[sessionIndex],
      message: "Meeting ended successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to end meeting"
    } as ApiResponse);
  }
};

export const getMeetingSessions: RequestHandler = (req, res) => {
  try {
    const { roomId } = req.params;
    const { limit = 20, offset = 0 } = req.query;
    
    let filteredSessions = roomId 
      ? meetingSessions.filter(s => s.room_id === roomId)
      : meetingSessions;
    
    // Sort by start time descending
    filteredSessions.sort((a, b) => 
      new Date(b.started_at).getTime() - new Date(a.started_at).getTime()
    );
    
    const paginatedSessions = filteredSessions.slice(
      Number(offset), 
      Number(offset) + Number(limit)
    );
    
    res.json({
      success: true,
      data: {
        sessions: paginatedSessions,
        total: filteredSessions.length,
        offset: Number(offset),
        limit: Number(limit)
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get meeting sessions"
    } as ApiResponse);
  }
};

export const getVoiceClips: RequestHandler = (req, res) => {
  try {
    const { created_by, tags, public_only } = req.query;
    
    let filteredClips = voiceClips.filter(clip => 
      clip.workspace_id === "default"
    );
    
    if (created_by) {
      filteredClips = filteredClips.filter(clip => clip.created_by === created_by);
    }
    
    if (tags) {
      const tagList = (tags as string).split(',');
      filteredClips = filteredClips.filter(clip => 
        tagList.some(tag => clip.tags.includes(tag))
      );
    }
    
    if (public_only === 'true') {
      filteredClips = filteredClips.filter(clip => clip.is_public);
    }
    
    // Sort by creation date descending
    filteredClips.sort((a, b) => 
      new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
    
    res.json({
      success: true,
      data: filteredClips
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get voice clips"
    } as ApiResponse);
  }
};

export const createVoiceClip: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = voiceClipSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid voice clip data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const voiceClip: VoiceClip = {
      id: `clip_${Date.now()}`,
      workspace_id: "default",
      created_by: user.id,
      ...validation.data,
      file_url: `https://voiceclips.example.com/${Date.now()}.webm`,
      waveform_data: Array.from({ length: 100 }, () => Math.random() * 100),
      transcription: validation.data.transcription_text ? {
        text: validation.data.transcription_text,
        confidence: 0.95,
        language: "en-US"
      } : undefined,
      created_at: new Date().toISOString(),
      play_count: 0,
      liked_by: []
    };

    voiceClips.push(voiceClip);

    res.status(201).json({
      success: true,
      data: voiceClip
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create voice clip"
    } as ApiResponse);
  }
};

export const getMeetingTemplates: RequestHandler = (req, res) => {
  try {
    const templates = meetingTemplates.filter(template => 
      template.workspace_id === "default"
    );
    
    // Sort by usage count descending
    templates.sort((a, b) => b.usage_count - a.usage_count);
    
    res.json({
      success: true,
      data: templates
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get meeting templates"
    } as ApiResponse);
  }
};

export const createMeetingTemplate: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = meetingTemplateSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid template data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const totalDuration = validation.data.agenda_template.items.reduce(
      (sum, item) => sum + item.duration_minutes, 0
    );

    const template: MeetingTemplate = {
      id: `template_${Date.now()}`,
      workspace_id: "default",
      ...validation.data,
      agenda_template: {
        ...validation.data.agenda_template,
        total_duration_minutes: totalDuration
      },
      created_by: user.id,
      created_at: new Date().toISOString(),
      usage_count: 0
    };

    meetingTemplates.push(template);

    res.status(201).json({
      success: true,
      data: template
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create meeting template"
    } as ApiResponse);
  }
};

export const getMeetingAnalytics: RequestHandler = (req, res) => {
  try {
    const { period = '30d' } = req.query;
    
    // Calculate analytics from meeting sessions
    const totalMeetings = meetingSessions.length;
    const totalDuration = meetingSessions.reduce((sum, session) => 
      sum + (session.duration_minutes || 0), 0
    );
    const avgDuration = totalMeetings > 0 ? totalDuration / totalMeetings : 0;
    const totalParticipants = new Set(
      meetingSessions.flatMap(session => 
        session.participants.map(p => p.user_id)
      )
    ).size;

    // Generate time series data (mock)
    const timeSeriesData = Array.from({ length: 30 }, (_, i) => ({
      date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      meetings: Math.floor(Math.random() * 10),
      participants: Math.floor(Math.random() * 50),
      duration_minutes: Math.floor(Math.random() * 500)
    }));

    const analytics = {
      period,
      total_meetings: totalMeetings,
      total_duration_minutes: totalDuration,
      average_duration_minutes: Math.round(avgDuration),
      total_participants: totalParticipants,
      recordings_created: meetingSessions.filter(s => s.recording).length,
      transcriptions_created: meetingSessions.filter(s => s.transcription).length,
      time_series: timeSeriesData,
      popular_rooms: meetingRooms
        .sort((a, b) => b.total_meetings - a.total_meetings)
        .slice(0, 5)
        .map(room => ({
          id: room.id,
          name: room.name,
          meetings: room.total_meetings,
          total_duration: room.total_duration_minutes
        })),
      meeting_types: {
        persistent: meetingRooms.filter(r => r.type === 'persistent').length,
        scheduled: meetingRooms.filter(r => r.type === 'scheduled').length,
        instant: meetingRooms.filter(r => r.type === 'instant').length
      }
    };

    res.json({
      success: true,
      data: analytics
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get meeting analytics"
    } as ApiResponse);
  }
};
