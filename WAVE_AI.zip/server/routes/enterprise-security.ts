import { RequestHandler } from "express";
import { z } from "zod";
import { ApiResponse, User } from "@shared/api";
import crypto from 'crypto';

// Security and compliance interfaces
interface SSOProvider {
  id: string;
  workspace_id: string;
  provider_type: 'saml' | 'oidc' | 'oauth2';
  name: string;
  domain: string;
  metadata_url?: string;
  entity_id?: string;
  login_url: string;
  logout_url?: string;
  certificate?: string;
  client_id?: string;
  client_secret?: string;
  is_active: boolean;
  auto_provision: boolean;
  default_role: 'admin' | 'member' | 'guest';
  created_at: string;
  updated_at: string;
}

interface SCIMConfiguration {
  id: string;
  workspace_id: string;
  endpoint_url: string;
  token: string;
  is_active: boolean;
  sync_users: boolean;
  sync_groups: boolean;
  auto_deactivate: boolean;
  last_sync: string;
  created_at: string;
}

interface RetentionPolicy {
  id: string;
  workspace_id: string;
  name: string;
  resource_type: 'messages' | 'files' | 'calls' | 'all';
  retention_period_days: number;
  applies_to: {
    channels: string[];
    user_types: ('admin' | 'member' | 'guest')[];
    file_types?: string[];
  };
  exceptions: {
    legal_hold_channels: string[];
    compliance_channels: string[];
  };
  auto_delete: boolean;
  is_active: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
}

interface AuditLog {
  id: string;
  workspace_id: string;
  user_id: string;
  action: string;
  resource_type: 'user' | 'channel' | 'message' | 'file' | 'workspace' | 'admin';
  resource_id: string;
  details: {
    old_value?: any;
    new_value?: any;
    metadata?: Record<string, any>;
  };
  ip_address: string;
  user_agent: string;
  timestamp: string;
  severity: 'info' | 'warning' | 'critical';
}

interface SecurityPolicy {
  id: string;
  workspace_id: string;
  name: string;
  policy_type: 'password' | 'session' | 'access' | 'data';
  rules: {
    min_password_length?: number;
    require_uppercase?: boolean;
    require_lowercase?: boolean;
    require_numbers?: boolean;
    require_symbols?: boolean;
    max_login_attempts?: number;
    session_timeout_minutes?: number;
    require_2fa?: boolean;
    allowed_domains?: string[];
    blocked_domains?: string[];
    ip_whitelist?: string[];
    data_classification_required?: boolean;
  };
  is_active: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
}

interface ComplianceReport {
  id: string;
  workspace_id: string;
  report_type: 'gdpr' | 'hipaa' | 'sox' | 'custom';
  requested_by: string;
  date_range: {
    start: string;
    end: string;
  };
  status: 'pending' | 'processing' | 'completed' | 'failed';
  file_url?: string;
  includes: {
    messages: boolean;
    files: boolean;
    user_activity: boolean;
    admin_actions: boolean;
  };
  created_at: string;
  completed_at?: string;
}

// Mock databases
let ssoProviders: SSOProvider[] = [];
let scimConfigurations: SCIMConfiguration[] = [];
let retentionPolicies: RetentionPolicy[] = [
  {
    id: "default-retention",
    workspace_id: "default",
    name: "Default Message Retention",
    resource_type: "messages",
    retention_period_days: 365,
    applies_to: {
      channels: [],
      user_types: ['admin', 'member', 'guest']
    },
    exceptions: {
      legal_hold_channels: [],
      compliance_channels: []
    },
    auto_delete: false,
    is_active: true,
    created_by: "1",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];
let auditLogs: AuditLog[] = [];
let securityPolicies: SecurityPolicy[] = [
  {
    id: "default-password-policy",
    workspace_id: "default",
    name: "Default Password Policy",
    policy_type: "password",
    rules: {
      min_password_length: 8,
      require_uppercase: true,
      require_lowercase: true,
      require_numbers: true,
      require_symbols: false,
      max_login_attempts: 5
    },
    is_active: true,
    created_by: "1",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];
let complianceReports: ComplianceReport[] = [];

// Validation schemas
const createSSOProviderSchema = z.object({
  provider_type: z.enum(['saml', 'oidc', 'oauth2']),
  name: z.string().min(1).max(100),
  domain: z.string().min(1),
  metadata_url: z.string().url().optional(),
  entity_id: z.string().optional(),
  login_url: z.string().url(),
  logout_url: z.string().url().optional(),
  certificate: z.string().optional(),
  client_id: z.string().optional(),
  client_secret: z.string().optional(),
  auto_provision: z.boolean().default(true),
  default_role: z.enum(['admin', 'member', 'guest']).default('member')
});

const scimConfigSchema = z.object({
  endpoint_url: z.string().url(),
  sync_users: z.boolean().default(true),
  sync_groups: z.boolean().default(true),
  auto_deactivate: z.boolean().default(true)
});

const retentionPolicySchema = z.object({
  name: z.string().min(1).max(100),
  resource_type: z.enum(['messages', 'files', 'calls', 'all']),
  retention_period_days: z.number().min(1).max(3650),
  applies_to: z.object({
    channels: z.array(z.string()),
    user_types: z.array(z.enum(['admin', 'member', 'guest'])),
    file_types: z.array(z.string()).optional()
  }),
  exceptions: z.object({
    legal_hold_channels: z.array(z.string()),
    compliance_channels: z.array(z.string())
  }),
  auto_delete: z.boolean().default(false)
});

const securityPolicySchema = z.object({
  name: z.string().min(1).max(100),
  policy_type: z.enum(['password', 'session', 'access', 'data']),
  rules: z.object({
    min_password_length: z.number().min(6).max(128).optional(),
    require_uppercase: z.boolean().optional(),
    require_lowercase: z.boolean().optional(),
    require_numbers: z.boolean().optional(),
    require_symbols: z.boolean().optional(),
    max_login_attempts: z.number().min(1).max(20).optional(),
    session_timeout_minutes: z.number().min(5).max(10080).optional(),
    require_2fa: z.boolean().optional(),
    allowed_domains: z.array(z.string()).optional(),
    blocked_domains: z.array(z.string()).optional(),
    ip_whitelist: z.array(z.string()).optional(),
    data_classification_required: z.boolean().optional()
  })
});

const complianceReportSchema = z.object({
  report_type: z.enum(['gdpr', 'hipaa', 'sox', 'custom']),
  date_range: z.object({
    start: z.string(),
    end: z.string()
  }),
  includes: z.object({
    messages: z.boolean().default(true),
    files: z.boolean().default(true),
    user_activity: z.boolean().default(true),
    admin_actions: z.boolean().default(true)
  })
});

// Helper function to require admin access
export const requireAdminOrOwner: RequestHandler = (req, res, next) => {
  const user = (req as any).user as User;
  // In a real app, check user's admin role in current workspace
  if (user.id !== "1") { // Temporary admin check
    return res.status(403).json({
      success: false,
      error: "Admin or owner access required"
    } as ApiResponse);
  }
  next();
};

// Helper function to log audit events
function logAuditEvent(
  workspaceId: string,
  userId: string,
  action: string,
  resourceType: string,
  resourceId: string,
  details: any,
  req: any
) {
  const auditEvent: AuditLog = {
    id: Date.now().toString(),
    workspace_id: workspaceId,
    user_id: userId,
    action,
    resource_type: resourceType as any,
    resource_id: resourceId,
    details,
    ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
    user_agent: req.get('user-agent') || 'unknown',
    timestamp: new Date().toISOString(),
    severity: 'info'
  };
  auditLogs.push(auditEvent);
}

// SSO Provider endpoints
export const getSSOProviders: RequestHandler = (req, res) => {
  try {
    const { workspaceId } = req.params;
    const providers = ssoProviders.filter(p => p.workspace_id === workspaceId);
    
    res.json({
      success: true,
      data: providers
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const createSSOProvider: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId } = req.params;
    const validation = createSSOProviderSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid SSO provider data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const provider: SSOProvider = {
      id: Date.now().toString(),
      workspace_id: workspaceId,
      ...validation.data,
      is_active: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    ssoProviders.push(provider);

    logAuditEvent(
      workspaceId,
      user.id,
      'sso_provider_created',
      'admin',
      provider.id,
      { provider_name: provider.name, provider_type: provider.provider_type },
      req
    );

    res.status(201).json({
      success: true,
      data: provider
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const updateSSOProvider: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId, providerId } = req.params;
    
    const providerIndex = ssoProviders.findIndex(p => 
      p.id === providerId && p.workspace_id === workspaceId
    );

    if (providerIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "SSO provider not found"
      } as ApiResponse);
    }

    const oldProvider = { ...ssoProviders[providerIndex] };
    ssoProviders[providerIndex] = {
      ...ssoProviders[providerIndex],
      ...req.body,
      updated_at: new Date().toISOString()
    };

    logAuditEvent(
      workspaceId,
      user.id,
      'sso_provider_updated',
      'admin',
      providerId,
      { old_value: oldProvider, new_value: ssoProviders[providerIndex] },
      req
    );

    res.json({
      success: true,
      data: ssoProviders[providerIndex]
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const deleteSSOProvider: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId, providerId } = req.params;
    
    const providerIndex = ssoProviders.findIndex(p => 
      p.id === providerId && p.workspace_id === workspaceId
    );

    if (providerIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "SSO provider not found"
      } as ApiResponse);
    }

    const deletedProvider = ssoProviders[providerIndex];
    ssoProviders.splice(providerIndex, 1);

    logAuditEvent(
      workspaceId,
      user.id,
      'sso_provider_deleted',
      'admin',
      providerId,
      { provider_name: deletedProvider.name },
      req
    );

    res.json({
      success: true,
      message: "SSO provider deleted successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

// SCIM Configuration endpoints
export const getSCIMConfiguration: RequestHandler = (req, res) => {
  try {
    const { workspaceId } = req.params;
    const config = scimConfigurations.find(c => c.workspace_id === workspaceId);
    
    res.json({
      success: true,
      data: config || null
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const createSCIMConfiguration: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId } = req.params;
    const validation = scimConfigSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid SCIM configuration",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    // Check if configuration already exists
    const existingConfig = scimConfigurations.find(c => c.workspace_id === workspaceId);
    if (existingConfig) {
      return res.status(400).json({
        success: false,
        error: "SCIM configuration already exists for this workspace"
      } as ApiResponse);
    }

    const config: SCIMConfiguration = {
      id: Date.now().toString(),
      workspace_id: workspaceId,
      ...validation.data,
      token: crypto.randomBytes(32).toString('hex'),
      is_active: true,
      last_sync: new Date().toISOString(),
      created_at: new Date().toISOString()
    };

    scimConfigurations.push(config);

    logAuditEvent(
      workspaceId,
      user.id,
      'scim_configuration_created',
      'admin',
      config.id,
      { endpoint_url: config.endpoint_url },
      req
    );

    res.status(201).json({
      success: true,
      data: config
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

// Retention Policy endpoints
export const getRetentionPolicies: RequestHandler = (req, res) => {
  try {
    const { workspaceId } = req.params;
    const policies = retentionPolicies.filter(p => p.workspace_id === workspaceId);
    
    res.json({
      success: true,
      data: policies
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const createRetentionPolicy: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId } = req.params;
    const validation = retentionPolicySchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid retention policy data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const policy: RetentionPolicy = {
      id: Date.now().toString(),
      workspace_id: workspaceId,
      ...validation.data,
      is_active: true,
      created_by: user.id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    retentionPolicies.push(policy);

    logAuditEvent(
      workspaceId,
      user.id,
      'retention_policy_created',
      'admin',
      policy.id,
      { 
        policy_name: policy.name,
        resource_type: policy.resource_type,
        retention_days: policy.retention_period_days
      },
      req
    );

    res.status(201).json({
      success: true,
      data: policy
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

// Security Policy endpoints
export const getSecurityPolicies: RequestHandler = (req, res) => {
  try {
    const { workspaceId } = req.params;
    const policies = securityPolicies.filter(p => p.workspace_id === workspaceId);
    
    res.json({
      success: true,
      data: policies
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const createSecurityPolicy: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId } = req.params;
    const validation = securityPolicySchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid security policy data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const policy: SecurityPolicy = {
      id: Date.now().toString(),
      workspace_id: workspaceId,
      ...validation.data,
      is_active: true,
      created_by: user.id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    securityPolicies.push(policy);

    logAuditEvent(
      workspaceId,
      user.id,
      'security_policy_created',
      'admin',
      policy.id,
      { 
        policy_name: policy.name,
        policy_type: policy.policy_type
      },
      req
    );

    res.status(201).json({
      success: true,
      data: policy
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

// Audit Log endpoints
export const getAuditLogs: RequestHandler = (req, res) => {
  try {
    const { workspaceId } = req.params;
    const { 
      action, 
      resource_type, 
      user_id, 
      start_date, 
      end_date, 
      limit = 100,
      offset = 0 
    } = req.query;

    let filteredLogs = auditLogs.filter(log => log.workspace_id === workspaceId);

    // Apply filters
    if (action) {
      filteredLogs = filteredLogs.filter(log => log.action === action);
    }
    if (resource_type) {
      filteredLogs = filteredLogs.filter(log => log.resource_type === resource_type);
    }
    if (user_id) {
      filteredLogs = filteredLogs.filter(log => log.user_id === user_id);
    }
    if (start_date) {
      filteredLogs = filteredLogs.filter(log => log.timestamp >= start_date);
    }
    if (end_date) {
      filteredLogs = filteredLogs.filter(log => log.timestamp <= end_date);
    }

    // Sort by timestamp descending
    filteredLogs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    // Apply pagination
    const total = filteredLogs.length;
    const paginatedLogs = filteredLogs.slice(Number(offset), Number(offset) + Number(limit));

    res.json({
      success: true,
      data: {
        logs: paginatedLogs,
        total,
        offset: Number(offset),
        limit: Number(limit)
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

// Compliance Report endpoints
export const getComplianceReports: RequestHandler = (req, res) => {
  try {
    const { workspaceId } = req.params;
    const reports = complianceReports.filter(r => r.workspace_id === workspaceId);
    
    res.json({
      success: true,
      data: reports
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const createComplianceReport: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId } = req.params;
    const validation = complianceReportSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid compliance report request",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const report: ComplianceReport = {
      id: Date.now().toString(),
      workspace_id: workspaceId,
      ...validation.data,
      requested_by: user.id,
      status: 'pending',
      created_at: new Date().toISOString()
    };

    complianceReports.push(report);

    logAuditEvent(
      workspaceId,
      user.id,
      'compliance_report_requested',
      'admin',
      report.id,
      { 
        report_type: report.report_type,
        date_range: report.date_range
      },
      req
    );

    // In production, trigger background job to generate report
    setTimeout(() => {
      const reportIndex = complianceReports.findIndex(r => r.id === report.id);
      if (reportIndex !== -1) {
        complianceReports[reportIndex].status = 'completed';
        complianceReports[reportIndex].completed_at = new Date().toISOString();
        complianceReports[reportIndex].file_url = `https://example.com/reports/${report.id}.zip`;
      }
    }, 2000);

    res.status(201).json({
      success: true,
      data: report,
      message: "Compliance report generation started"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

// Data encryption simulation
export const encryptWorkspaceData: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId } = req.params;
    const { enable_encryption } = req.body;

    logAuditEvent(
      workspaceId,
      user.id,
      enable_encryption ? 'encryption_enabled' : 'encryption_disabled',
      'admin',
      workspaceId,
      { encryption_status: enable_encryption },
      req
    );

    res.json({
      success: true,
      data: {
        workspace_id: workspaceId,
        encryption_enabled: enable_encryption,
        encryption_algorithm: 'AES-256-GCM',
        key_rotation_schedule: '90 days'
      },
      message: `Workspace encryption ${enable_encryption ? 'enabled' : 'disabled'} successfully`
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};
