import { RequestHandler } from "express";
import { z } from "zod";
import { Workspace, ApiResponse, User } from "@shared/api";
import crypto from 'crypto';

// Enhanced workspace with branding and settings
interface ExtendedWorkspace extends Workspace {
  description?: string;
  domain?: string;
  is_private: boolean;
  logo_url?: string;
  banner_url?: string;
  brand_color?: string;
  custom_domain?: string;
  join_policy: 'open' | 'approval' | 'invite_only';
  email_domain_restriction?: string;
  max_members?: number;
  settings: {
    allow_guest_invites: boolean;
    require_approval_for_guests: boolean;
    allow_public_channels: boolean;
    retention_days?: number;
    enforce_2fa: boolean;
    allowed_file_types: string[];
    max_file_size_mb: number;
  };
}

interface WorkspaceMember {
  workspace_id: string;
  user_id: string;
  role: 'owner' | 'admin' | 'member' | 'guest';
  joined_at: string;
  invited_by?: string;
  permissions: string[];
  status: 'active' | 'suspended' | 'pending_approval';
  last_seen?: string;
  department?: string;
  title?: string;
}

interface WorkspaceInvitation {
  id: string;
  workspace_id: string;
  email: string;
  role: 'admin' | 'member' | 'guest';
  invited_by: string;
  expires_at: string;
  created_at: string;
  used: boolean;
  message?: string;
  requires_approval: boolean;
  approval_status?: 'pending' | 'approved' | 'rejected';
  approved_by?: string;
  approved_at?: string;
  link_token?: string;
  max_uses?: number;
  uses_count: number;
}

interface JoinRequest {
  id: string;
  workspace_id: string;
  user_id: string;
  email: string;
  message?: string;
  requested_at: string;
  status: 'pending' | 'approved' | 'rejected';
  reviewed_by?: string;
  reviewed_at?: string;
  review_message?: string;
}

interface WorkspaceBranding {
  workspace_id: string;
  logo_url?: string;
  banner_url?: string;
  primary_color: string;
  secondary_color: string;
  font_family: string;
  custom_css?: string;
  favicon_url?: string;
  login_background_url?: string;
}

// Mock databases
let workspaces: ExtendedWorkspace[] = [
  {
    id: "default",
    name: "New Workspace",
    created_by: "1",
    created_at: new Date().toISOString(),
    trial_ends_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    description: "Default workspace for collaboration",
    is_private: false,
    join_policy: 'approval',
    brand_color: '#6366f1',
    settings: {
      allow_guest_invites: true,
      require_approval_for_guests: true,
      allow_public_channels: true,
      enforce_2fa: false,
      allowed_file_types: ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'txt'],
      max_file_size_mb: 100
    }
  }
];

let workspaceMembers: WorkspaceMember[] = [
  {
    workspace_id: "default",
    user_id: "1",
    role: "owner",
    joined_at: new Date().toISOString(),
    permissions: ["all"],
    status: "active",
    title: "Workspace Owner",
    department: "Administration"
  }
];

let workspaceInvitations: WorkspaceInvitation[] = [];
let joinRequests: JoinRequest[] = [];
let workspaceBranding: WorkspaceBranding[] = [];

// Validation schemas
const createWorkspaceSchema = z.object({
  name: z.string().min(1).max(50),
  description: z.string().max(500).optional(),
  domain: z.string().optional(),
  is_private: z.boolean().default(false),
  join_policy: z.enum(['open', 'approval', 'invite_only']).default('approval'),
  email_domain_restriction: z.string().optional(),
  max_members: z.number().min(1).max(10000).optional(),
  brand_color: z.string().regex(/^#[0-9A-F]{6}$/i).optional(),
  settings: z.object({
    allow_guest_invites: z.boolean().default(true),
    require_approval_for_guests: z.boolean().default(true),
    allow_public_channels: z.boolean().default(true),
    retention_days: z.number().min(1).max(3650).optional(),
    enforce_2fa: z.boolean().default(false),
    allowed_file_types: z.array(z.string()).default(['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'txt']),
    max_file_size_mb: z.number().min(1).max(1000).default(100)
  }).optional()
});

const inviteMemberSchema = z.object({
  email: z.string().email(),
  role: z.enum(['admin', 'member', 'guest']).default('member'),
  message: z.string().max(500).optional(),
  requires_approval: z.boolean().default(false),
  max_uses: z.number().min(1).max(100).optional(),
  expires_in_days: z.number().min(1).max(365).default(7),
  department: z.string().max(100).optional(),
  title: z.string().max(100).optional()
});

const createInviteLinkSchema = z.object({
  role: z.enum(['member', 'guest']).default('member'),
  max_uses: z.number().min(1).max(1000).default(50),
  expires_in_days: z.number().min(1).max(365).default(7),
  requires_approval: z.boolean().default(false)
});

const joinRequestSchema = z.object({
  workspace_id: z.string(),
  message: z.string().max(500).optional()
});

const reviewJoinRequestSchema = z.object({
  action: z.enum(['approve', 'reject']),
  message: z.string().max(500).optional()
});

const updateBrandingSchema = z.object({
  logo_url: z.string().url().optional(),
  banner_url: z.string().url().optional(),
  primary_color: z.string().regex(/^#[0-9A-F]{6}$/i),
  secondary_color: z.string().regex(/^#[0-9A-F]{6}$/i),
  font_family: z.enum(['Inter', 'Roboto', 'Open Sans', 'Lato', 'Montserrat']).default('Inter'),
  custom_css: z.string().max(5000).optional(),
  favicon_url: z.string().url().optional(),
  login_background_url: z.string().url().optional()
});

const updateMemberRoleSchema = z.object({
  role: z.enum(['admin', 'member', 'guest']),
  permissions: z.array(z.string()).optional()
});

export const getUserWorkspaces: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    
    // Get workspaces where user is a member
    const userMemberships = workspaceMembers.filter(m => m.user_id === user.id);
    const userWorkspaces = workspaces.filter(w => 
      userMemberships.some(m => m.workspace_id === w.id)
    ).map(workspace => {
      const membership = userMemberships.find(m => m.workspace_id === workspace.id);
      return {
        ...workspace,
        user_role: membership?.role,
        user_permissions: membership?.permissions || [],
        member_count: workspaceMembers.filter(m => m.workspace_id === workspace.id).length
      };
    });

    res.json({
      success: true,
      data: userWorkspaces
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const createWorkspace: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = createWorkspaceSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid workspace data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    // Destructuring already done above

    // Check if user already has a workspace with this name
    const existingWorkspace = workspaces.find(w => 
      w.name.toLowerCase() === name.toLowerCase() && 
      workspaceMembers.some(m => m.workspace_id === w.id && m.user_id === user.id)
    );

    if (existingWorkspace) {
      return res.status(400).json({
        success: false,
        error: "You already have a workspace with this name"
      } as ApiResponse);
    }

    const { name, description, domain, is_private, join_policy, email_domain_restriction, max_members, brand_color, settings } = validation.data;

    const workspace: ExtendedWorkspace = {
      id: Date.now().toString(),
      name,
      description,
      domain,
      is_private,
      join_policy,
      email_domain_restriction,
      max_members,
      brand_color: brand_color || '#6366f1',
      created_by: user.id,
      created_at: new Date().toISOString(),
      trial_ends_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      settings: settings || {
        allow_guest_invites: true,
        require_approval_for_guests: true,
        allow_public_channels: true,
        enforce_2fa: false,
        allowed_file_types: ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'txt'],
        max_file_size_mb: 100
      }
    };

    workspaces.push(workspace);

    // Add creator as owner
    const membership: WorkspaceMember = {
      workspace_id: workspace.id,
      user_id: user.id,
      role: 'owner',
      joined_at: new Date().toISOString(),
      permissions: ['all'],
      status: 'active',
      title: 'Workspace Owner',
      department: 'Administration'
    };

    // Create default branding
    const branding: WorkspaceBranding = {
      workspace_id: workspace.id,
      primary_color: brand_color || '#6366f1',
      secondary_color: '#f3f4f6',
      font_family: 'Inter'
    };
    workspaceBranding.push(branding);

    workspaceMembers.push(membership);

    res.status(201).json({
      success: true,
      data: {
        ...workspace,
        user_role: 'owner',
        user_permissions: ['all'],
        member_count: 1
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getWorkspaceDetails: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId } = req.params;

    const workspace = workspaces.find(w => w.id === workspaceId);
    if (!workspace) {
      return res.status(404).json({
        success: false,
        error: "Workspace not found"
      } as ApiResponse);
    }

    // Check if user is a member
    const membership = workspaceMembers.find(m => 
      m.workspace_id === workspaceId && m.user_id === user.id
    );

    if (!membership) {
      return res.status(403).json({
        success: false,
        error: "Access denied"
      } as ApiResponse);
    }

    const members = workspaceMembers.filter(m => m.workspace_id === workspaceId);
    
    res.json({
      success: true,
      data: {
        ...workspace,
        user_role: membership.role,
        user_permissions: membership.permissions,
        member_count: members.length,
        members: members.map(m => ({
          user_id: m.user_id,
          role: m.role,
          joined_at: m.joined_at,
          permissions: m.permissions
        }))
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const updateWorkspace: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId } = req.params;

    // Check if user has permission to update workspace
    const membership = workspaceMembers.find(m => 
      m.workspace_id === workspaceId && 
      m.user_id === user.id && 
      (m.role === 'owner' || m.role === 'admin')
    );

    if (!membership) {
      return res.status(403).json({
        success: false,
        error: "Insufficient permissions"
      } as ApiResponse);
    }

    const workspaceIndex = workspaces.findIndex(w => w.id === workspaceId);
    if (workspaceIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Workspace not found"
      } as ApiResponse);
    }

    const updates = req.body;
    workspaces[workspaceIndex] = {
      ...workspaces[workspaceIndex],
      ...updates
    };

    res.json({
      success: true,
      data: workspaces[workspaceIndex]
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const deleteWorkspace: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId } = req.params;

    // Only owners can delete workspaces
    const membership = workspaceMembers.find(m => 
      m.workspace_id === workspaceId && 
      m.user_id === user.id && 
      m.role === 'owner'
    );

    if (!membership) {
      return res.status(403).json({
        success: false,
        error: "Only workspace owners can delete workspaces"
      } as ApiResponse);
    }

    // Remove workspace
    const workspaceIndex = workspaces.findIndex(w => w.id === workspaceId);
    if (workspaceIndex !== -1) {
      workspaces.splice(workspaceIndex, 1);
    }

    // Remove all members
    workspaceMembers = workspaceMembers.filter(m => m.workspace_id !== workspaceId);

    // Remove all invitations
    workspaceInvitations = workspaceInvitations.filter(i => i.workspace_id !== workspaceId);

    res.json({
      success: true,
      message: "Workspace deleted successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const inviteMember: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId } = req.params;
    const validation = inviteMemberSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid invitation data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const { email, role, message, requires_approval, max_uses, expires_in_days, department, title } = validation.data;

    // Check if user has permission to invite
    const membership = workspaceMembers.find(m => 
      m.workspace_id === workspaceId && 
      m.user_id === user.id && 
      (m.role === 'owner' || m.role === 'admin')
    );

    if (!membership) {
      return res.status(403).json({
        success: false,
        error: "Insufficient permissions to invite members"
      } as ApiResponse);
    }

    // Check if user is already a member
    const existingMember = workspaceMembers.find(m => 
      m.workspace_id === workspaceId && 
      // In production, match by email from user database
      m.user_id === email
    );

    if (existingMember) {
      return res.status(400).json({
        success: false,
        error: "User is already a member of this workspace"
      } as ApiResponse);
    }

    // Check for existing invitation
    const existingInvitation = workspaceInvitations.find(i => 
      i.workspace_id === workspaceId && 
      i.email === email && 
      !i.used &&
      new Date(i.expires_at) > new Date()
    );

    if (existingInvitation) {
      return res.status(400).json({
        success: false,
        error: "An active invitation already exists for this email"
      } as ApiResponse);
    }

    // Check workspace member limits
    const workspace = workspaces.find(w => w.id === workspaceId);
    if (workspace?.max_members) {
      const currentMemberCount = workspaceMembers.filter(m => m.workspace_id === workspaceId).length;
      if (currentMemberCount >= workspace.max_members) {
        return res.status(400).json({
          success: false,
          error: `Workspace has reached maximum member limit of ${workspace.max_members}`
        } as ApiResponse);
      }
    }

    // Check email domain restriction
    if (workspace?.email_domain_restriction) {
      const emailDomain = email.split('@')[1];
      if (emailDomain !== workspace.email_domain_restriction) {
        return res.status(400).json({
          success: false,
          error: `Only emails from ${workspace.email_domain_restriction} domain are allowed`
        } as ApiResponse);
      }
    }

    const invitation: WorkspaceInvitation = {
      id: Date.now().toString(),
      workspace_id: workspaceId,
      email,
      role,
      invited_by: user.id,
      expires_at: new Date(Date.now() + expires_in_days * 24 * 60 * 60 * 1000).toISOString(),
      created_at: new Date().toISOString(),
      used: false,
      message,
      requires_approval: requires_approval || (role === 'guest' && workspace?.settings.require_approval_for_guests),
      max_uses,
      uses_count: 0,
      link_token: crypto.randomBytes(32).toString('hex')
    };

    workspaceInvitations.push(invitation);

    // In production, send invitation email here

    res.status(201).json({
      success: true,
      data: invitation,
      message: "Invitation sent successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const acceptInvitation: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { invitationId } = req.params;

    const invitation = workspaceInvitations.find(i => 
      i.id === invitationId && 
      !i.used &&
      new Date(i.expires_at) > new Date()
    );

    if (!invitation) {
      return res.status(404).json({
        success: false,
        error: "Invalid or expired invitation"
      } as ApiResponse);
    }

    // Check if user email matches invitation (in production)
    // For demo, we'll accept any authenticated user

    // Check if user is already a member
    const existingMember = workspaceMembers.find(m => 
      m.workspace_id === invitation.workspace_id && 
      m.user_id === user.id
    );

    if (existingMember) {
      return res.status(400).json({
        success: false,
        error: "You are already a member of this workspace"
      } as ApiResponse);
    }

    // Check if invitation requires approval
    if (invitation.requires_approval && invitation.approval_status !== 'approved') {
      return res.status(400).json({
        success: false,
        error: "This invitation requires approval before you can join"
      } as ApiResponse);
    }

    // Add user as member
    const membership: WorkspaceMember = {
      workspace_id: invitation.workspace_id,
      user_id: user.id,
      role: invitation.role,
      joined_at: new Date().toISOString(),
      invited_by: invitation.invited_by,
      permissions: getDefaultPermissions(invitation.role),
      status: 'active'
    };

    workspaceMembers.push(membership);

    // Mark invitation as used
    const invitationIndex = workspaceInvitations.findIndex(i => i.id === invitationId);
    if (invitationIndex !== -1) {
      workspaceInvitations[invitationIndex].used = true;
    }

    // Get workspace details
    const workspace = workspaces.find(w => w.id === invitation.workspace_id);

    res.json({
      success: true,
      data: {
        workspace,
        membership
      },
      message: "Successfully joined workspace"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const leaveWorkspace: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId } = req.params;

    const membershipIndex = workspaceMembers.findIndex(m => 
      m.workspace_id === workspaceId && m.user_id === user.id
    );

    if (membershipIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "You are not a member of this workspace"
      } as ApiResponse);
    }

    const membership = workspaceMembers[membershipIndex];

    // Don't allow owners to leave if they're the only owner
    if (membership.role === 'owner') {
      const ownerCount = workspaceMembers.filter(m => 
        m.workspace_id === workspaceId && m.role === 'owner'
      ).length;

      if (ownerCount === 1) {
        return res.status(400).json({
          success: false,
          error: "Cannot leave workspace as the only owner. Transfer ownership first."
        } as ApiResponse);
      }
    }

    workspaceMembers.splice(membershipIndex, 1);

    res.json({
      success: true,
      message: "Successfully left workspace"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const updateMemberRole: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId, memberId } = req.params;
    const validation = updateMemberRoleSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid role data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const { role, permissions } = validation.data;

    // Check if user has permission to update roles
    const userMembership = workspaceMembers.find(m => 
      m.workspace_id === workspaceId && 
      m.user_id === user.id && 
      (m.role === 'owner' || m.role === 'admin')
    );

    if (!userMembership) {
      return res.status(403).json({
        success: false,
        error: "Insufficient permissions"
      } as ApiResponse);
    }

    const membershipIndex = workspaceMembers.findIndex(m => 
      m.workspace_id === workspaceId && m.user_id === memberId
    );

    if (membershipIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Member not found"
      } as ApiResponse);
    }

    workspaceMembers[membershipIndex].role = role;
    if (permissions) {
      workspaceMembers[membershipIndex].permissions = permissions;
    }

    res.json({
      success: true,
      data: workspaceMembers[membershipIndex]
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const removeMember: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId, memberId } = req.params;

    // Check if user has permission to remove members
    const userMembership = workspaceMembers.find(m => 
      m.workspace_id === workspaceId && 
      m.user_id === user.id && 
      (m.role === 'owner' || m.role === 'admin')
    );

    if (!userMembership) {
      return res.status(403).json({
        success: false,
        error: "Insufficient permissions"
      } as ApiResponse);
    }

    const membershipIndex = workspaceMembers.findIndex(m => 
      m.workspace_id === workspaceId && m.user_id === memberId
    );

    if (membershipIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Member not found"
      } as ApiResponse);
    }

    const targetMembership = workspaceMembers[membershipIndex];

    // Don't allow removing the last owner
    if (targetMembership.role === 'owner') {
      const ownerCount = workspaceMembers.filter(m => 
        m.workspace_id === workspaceId && m.role === 'owner'
      ).length;

      if (ownerCount === 1) {
        return res.status(400).json({
          success: false,
          error: "Cannot remove the last owner of the workspace"
        } as ApiResponse);
      }
    }

    workspaceMembers.splice(membershipIndex, 1);

    res.json({
      success: true,
      message: "Member removed successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getWorkspaceInvitations: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId } = req.params;

    // Check permissions
    const membership = workspaceMembers.find(m => 
      m.workspace_id === workspaceId && 
      m.user_id === user.id && 
      (m.role === 'owner' || m.role === 'admin')
    );

    if (!membership) {
      return res.status(403).json({
        success: false,
        error: "Insufficient permissions"
      } as ApiResponse);
    }

    const invitations = workspaceInvitations.filter(i => 
      i.workspace_id === workspaceId
    );

    res.json({
      success: true,
      data: invitations
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

// New enterprise endpoints

export const createInviteLink: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId } = req.params;
    const validation = createInviteLinkSchema.safeParse(req.body);

    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid invite link data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const { role, max_uses, expires_in_days, requires_approval } = validation.data;

    // Check permissions
    const membership = workspaceMembers.find(m =>
      m.workspace_id === workspaceId &&
      m.user_id === user.id &&
      (m.role === 'owner' || m.role === 'admin')
    );

    if (!membership) {
      return res.status(403).json({
        success: false,
        error: "Insufficient permissions"
      } as ApiResponse);
    }

    const inviteLink: WorkspaceInvitation = {
      id: Date.now().toString(),
      workspace_id: workspaceId,
      email: '',
      role,
      invited_by: user.id,
      expires_at: new Date(Date.now() + expires_in_days * 24 * 60 * 60 * 1000).toISOString(),
      created_at: new Date().toISOString(),
      used: false,
      requires_approval,
      max_uses,
      uses_count: 0,
      link_token: crypto.randomBytes(32).toString('hex')
    };

    workspaceInvitations.push(inviteLink);

    res.status(201).json({
      success: true,
      data: {
        ...inviteLink,
        invite_url: `${req.protocol}://${req.get('host')}/join/${inviteLink.link_token}`
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const joinWorkspaceByLink: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { linkToken } = req.params;

    const invitation = workspaceInvitations.find(i =>
      i.link_token === linkToken &&
      !i.used &&
      new Date(i.expires_at) > new Date() &&
      (!i.max_uses || i.uses_count < i.max_uses)
    );

    if (!invitation) {
      return res.status(404).json({
        success: false,
        error: "Invalid or expired invite link"
      } as ApiResponse);
    }

    // Check if user is already a member
    const existingMember = workspaceMembers.find(m =>
      m.workspace_id === invitation.workspace_id &&
      m.user_id === user.id
    );

    if (existingMember) {
      return res.status(400).json({
        success: false,
        error: "You are already a member of this workspace"
      } as ApiResponse);
    }

    const workspace = workspaces.find(w => w.id === invitation.workspace_id);

    if (invitation.requires_approval || workspace?.join_policy === 'approval') {
      // Create join request
      const joinRequest: JoinRequest = {
        id: Date.now().toString(),
        workspace_id: invitation.workspace_id,
        user_id: user.id,
        email: user.email || '',
        message: 'Joined via invite link',
        requested_at: new Date().toISOString(),
        status: 'pending'
      };

      joinRequests.push(joinRequest);

      return res.json({
        success: true,
        data: {
          message: "Join request submitted for approval",
          requires_approval: true
        }
      } as ApiResponse);
    }

    // Direct join
    const membership: WorkspaceMember = {
      workspace_id: invitation.workspace_id,
      user_id: user.id,
      role: invitation.role,
      joined_at: new Date().toISOString(),
      invited_by: invitation.invited_by,
      permissions: getDefaultPermissions(invitation.role),
      status: 'active'
    };

    workspaceMembers.push(membership);

    // Update invitation usage
    const invitationIndex = workspaceInvitations.findIndex(i => i.id === invitation.id);
    if (invitationIndex !== -1) {
      workspaceInvitations[invitationIndex].uses_count++;
      if (workspaceInvitations[invitationIndex].max_uses &&
          workspaceInvitations[invitationIndex].uses_count >= workspaceInvitations[invitationIndex].max_uses!) {
        workspaceInvitations[invitationIndex].used = true;
      }
    }

    res.json({
      success: true,
      data: {
        workspace,
        membership,
        message: "Successfully joined workspace"
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const requestToJoin: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = joinRequestSchema.safeParse(req.body);

    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid join request data"
      } as ApiResponse);
    }

    const { workspace_id, message } = validation.data;

    const workspace = workspaces.find(w => w.id === workspace_id);
    if (!workspace) {
      return res.status(404).json({
        success: false,
        error: "Workspace not found"
      } as ApiResponse);
    }

    if (workspace.join_policy === 'invite_only') {
      return res.status(403).json({
        success: false,
        error: "This workspace only accepts invited members"
      } as ApiResponse);
    }

    // Check if user is already a member
    const existingMember = workspaceMembers.find(m =>
      m.workspace_id === workspace_id && m.user_id === user.id
    );

    if (existingMember) {
      return res.status(400).json({
        success: false,
        error: "You are already a member of this workspace"
      } as ApiResponse);
    }

    // Check for existing request
    const existingRequest = joinRequests.find(r =>
      r.workspace_id === workspace_id &&
      r.user_id === user.id &&
      r.status === 'pending'
    );

    if (existingRequest) {
      return res.status(400).json({
        success: false,
        error: "You already have a pending join request"
      } as ApiResponse);
    }

    const joinRequest: JoinRequest = {
      id: Date.now().toString(),
      workspace_id,
      user_id: user.id,
      email: user.email || '',
      message,
      requested_at: new Date().toISOString(),
      status: 'pending'
    };

    joinRequests.push(joinRequest);

    res.status(201).json({
      success: true,
      data: joinRequest,
      message: "Join request submitted successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getJoinRequests: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId } = req.params;

    // Check permissions
    const membership = workspaceMembers.find(m =>
      m.workspace_id === workspaceId &&
      m.user_id === user.id &&
      (m.role === 'owner' || m.role === 'admin')
    );

    if (!membership) {
      return res.status(403).json({
        success: false,
        error: "Insufficient permissions"
      } as ApiResponse);
    }

    const requests = joinRequests.filter(r => r.workspace_id === workspaceId);

    res.json({
      success: true,
      data: requests
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const reviewJoinRequest: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId, requestId } = req.params;
    const validation = reviewJoinRequestSchema.safeParse(req.body);

    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid review data"
      } as ApiResponse);
    }

    const { action, message: reviewMessage } = validation.data;

    // Check permissions
    const membership = workspaceMembers.find(m =>
      m.workspace_id === workspaceId &&
      m.user_id === user.id &&
      (m.role === 'owner' || m.role === 'admin')
    );

    if (!membership) {
      return res.status(403).json({
        success: false,
        error: "Insufficient permissions"
      } as ApiResponse);
    }

    const requestIndex = joinRequests.findIndex(r =>
      r.id === requestId && r.workspace_id === workspaceId
    );

    if (requestIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Join request not found"
      } as ApiResponse);
    }

    const joinRequest = joinRequests[requestIndex];

    if (joinRequest.status !== 'pending') {
      return res.status(400).json({
        success: false,
        error: "Join request has already been reviewed"
      } as ApiResponse);
    }

    // Update request status
    joinRequests[requestIndex] = {
      ...joinRequest,
      status: action === 'approve' ? 'approved' : 'rejected',
      reviewed_by: user.id,
      reviewed_at: new Date().toISOString(),
      review_message: reviewMessage
    };

    // If approved, add user as member
    if (action === 'approve') {
      const newMembership: WorkspaceMember = {
        workspace_id: workspaceId,
        user_id: joinRequest.user_id,
        role: 'member',
        joined_at: new Date().toISOString(),
        permissions: getDefaultPermissions('member'),
        status: 'active'
      };

      workspaceMembers.push(newMembership);
    }

    res.json({
      success: true,
      data: joinRequests[requestIndex],
      message: `Join request ${action}d successfully`
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const updateWorkspaceBranding: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspaceId } = req.params;
    const validation = updateBrandingSchema.safeParse(req.body);

    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid branding data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    // Check permissions
    const membership = workspaceMembers.find(m =>
      m.workspace_id === workspaceId &&
      m.user_id === user.id &&
      (m.role === 'owner' || m.role === 'admin')
    );

    if (!membership) {
      return res.status(403).json({
        success: false,
        error: "Insufficient permissions"
      } as ApiResponse);
    }

    const brandingIndex = workspaceBranding.findIndex(b => b.workspace_id === workspaceId);

    if (brandingIndex === -1) {
      // Create new branding
      const newBranding: WorkspaceBranding = {
        workspace_id: workspaceId,
        ...validation.data
      };
      workspaceBranding.push(newBranding);

      res.status(201).json({
        success: true,
        data: newBranding
      } as ApiResponse);
    } else {
      // Update existing branding
      workspaceBranding[brandingIndex] = {
        ...workspaceBranding[brandingIndex],
        ...validation.data
      };

      res.json({
        success: true,
        data: workspaceBranding[brandingIndex]
      } as ApiResponse);
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getWorkspaceBranding: RequestHandler = (req, res) => {
  try {
    const { workspaceId } = req.params;

    const branding = workspaceBranding.find(b => b.workspace_id === workspaceId);

    if (!branding) {
      // Return default branding
      const defaultBranding: WorkspaceBranding = {
        workspace_id: workspaceId,
        primary_color: '#6366f1',
        secondary_color: '#f3f4f6',
        font_family: 'Inter'
      };

      res.json({
        success: true,
        data: defaultBranding
      } as ApiResponse);
    } else {
      res.json({
        success: true,
        data: branding
      } as ApiResponse);
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getWorkspacePublicInfo: RequestHandler = (req, res) => {
  try {
    const { workspaceId } = req.params;

    const workspace = workspaces.find(w => w.id === workspaceId);
    if (!workspace) {
      return res.status(404).json({
        success: false,
        error: "Workspace not found"
      } as ApiResponse);
    }

    // Only return public information
    const publicInfo = {
      id: workspace.id,
      name: workspace.name,
      description: workspace.description,
      logo_url: workspace.logo_url,
      brand_color: workspace.brand_color,
      join_policy: workspace.join_policy,
      is_private: workspace.is_private,
      member_count: workspaceMembers.filter(m => m.workspace_id === workspaceId).length,
      max_members: workspace.max_members
    };

    const branding = workspaceBranding.find(b => b.workspace_id === workspaceId);

    res.json({
      success: true,
      data: {
        workspace: publicInfo,
        branding
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

function getDefaultPermissions(role: string): string[] {
  switch (role) {
    case 'owner':
      return ['all'];
    case 'admin':
      return ['manage_channels', 'manage_members', 'manage_integrations', 'manage_workspace'];
    case 'member':
      return ['read_messages', 'send_messages', 'upload_files', 'create_channels'];
    case 'guest':
      return ['read_messages', 'send_messages'];
    default:
      return ['read_messages'];
  }
}
