import { RequestHandler } from "express";
import { z } from "zod";
import { ApiResponse, User } from "@shared/api";

// Accessibility and internationalization interfaces
interface AccessibilitySettings {
  id: string;
  user_id: string;
  workspace_id: string;
  preferences: {
    high_contrast: boolean;
    large_text: boolean;
    reduce_motion: boolean;
    screen_reader_optimized: boolean;
    keyboard_navigation: boolean;
    focus_indicators: boolean;
    color_blind_friendly: boolean;
    dyslexia_friendly: boolean;
    font_family: 'default' | 'dyslexia' | 'high_contrast';
    font_size: 'small' | 'medium' | 'large' | 'extra_large';
    line_height: 'normal' | 'relaxed' | 'loose';
    letter_spacing: 'normal' | 'wide' | 'wider';
  };
  announcements: {
    new_messages: boolean;
    user_joins: boolean;
    typing_indicators: boolean;
    reactions: boolean;
    system_alerts: boolean;
  };
  shortcuts: {
    [key: string]: string;
  };
  updated_at: string;
}

interface Translation {
  id: string;
  workspace_id: string;
  language_code: string;
  namespace: string;
  key: string;
  value: string;
  context?: string;
  pluralization?: {
    zero?: string;
    one?: string;
    two?: string;
    few?: string;
    many?: string;
    other: string;
  };
  variables?: string[];
  approved: boolean;
  translated_by?: string;
  reviewed_by?: string;
  created_at: string;
  updated_at: string;
}

interface LanguageConfig {
  id: string;
  workspace_id: string;
  language_code: string;
  language_name: string;
  native_name: string;
  is_rtl: boolean;
  is_active: boolean;
  is_default: boolean;
  completion_percentage: number;
  translators: string[];
  date_format: string;
  time_format: string;
  number_format: {
    decimal_separator: string;
    thousands_separator: string;
    currency_symbol: string;
    currency_position: 'before' | 'after';
  };
  created_at: string;
  updated_at: string;
}

interface ThemeConfig {
  id: string;
  workspace_id: string;
  name: string;
  type: 'light' | 'dark' | 'high_contrast' | 'custom';
  is_system_theme: boolean;
  is_active: boolean;
  accessibility_features: {
    high_contrast: boolean;
    color_blind_safe: boolean;
    focus_visible: boolean;
    motion_reduced: boolean;
  };
  colors: {
    primary: string;
    secondary: string;
    background: string;
    surface: string;
    text_primary: string;
    text_secondary: string;
    border: string;
    error: string;
    warning: string;
    success: string;
    info: string;
    focus: string;
    hover: string;
    disabled: string;
  };
  typography: {
    font_family_primary: string;
    font_family_secondary: string;
    font_size_base: number;
    line_height_base: number;
    letter_spacing_base: number;
    heading_scale: number[];
  };
  spacing: {
    base_unit: number;
    scale: number[];
  };
  custom_css?: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

interface AccessibilityAudit {
  id: string;
  workspace_id: string;
  audit_type: 'automated' | 'manual' | 'user_testing';
  page_url: string;
  issues: {
    level: 'A' | 'AA' | 'AAA';
    severity: 'critical' | 'serious' | 'moderate' | 'minor';
    rule_id: string;
    rule_name: string;
    description: string;
    element_selector: string;
    recommendation: string;
    wcag_criterion: string;
  }[];
  score: {
    overall: number;
    level_a: number;
    level_aa: number;
    level_aaa: number;
  };
  conducted_by: string;
  conducted_at: string;
  status: 'in_progress' | 'completed' | 'failed';
}

// Mock databases
let accessibilitySettings: AccessibilitySettings[] = [
  {
    id: "settings-1",
    user_id: "1",
    workspace_id: "default",
    preferences: {
      high_contrast: false,
      large_text: false,
      reduce_motion: false,
      screen_reader_optimized: false,
      keyboard_navigation: true,
      focus_indicators: true,
      color_blind_friendly: false,
      dyslexia_friendly: false,
      font_family: 'default',
      font_size: 'medium',
      line_height: 'normal',
      letter_spacing: 'normal'
    },
    announcements: {
      new_messages: true,
      user_joins: false,
      typing_indicators: true,
      reactions: true,
      system_alerts: true
    },
    shortcuts: {
      'ctrl+k': 'quick_search',
      'ctrl+shift+k': 'command_palette',
      'ctrl+n': 'new_message',
      'ctrl+shift+n': 'new_channel',
      'esc': 'close_modal',
      'tab': 'next_element',
      'shift+tab': 'previous_element'
    },
    updated_at: new Date().toISOString()
  }
];

let translations: Translation[] = [
  // English (default)
  {
    id: "trans-1",
    workspace_id: "default",
    language_code: "en",
    namespace: "common",
    key: "welcome",
    value: "Welcome",
    approved: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "trans-2",
    workspace_id: "default",
    language_code: "en",
    namespace: "messages",
    key: "new_message",
    value: "New message",
    approved: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  // Spanish
  {
    id: "trans-3",
    workspace_id: "default",
    language_code: "es",
    namespace: "common",
    key: "welcome",
    value: "Bienvenido",
    approved: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "trans-4",
    workspace_id: "default",
    language_code: "es",
    namespace: "messages",
    key: "new_message",
    value: "Nuevo mensaje",
    approved: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  // Arabic (RTL)
  {
    id: "trans-5",
    workspace_id: "default",
    language_code: "ar",
    namespace: "common",
    key: "welcome",
    value: "مرحبا",
    approved: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  // French
  {
    id: "trans-6",
    workspace_id: "default",
    language_code: "fr",
    namespace: "common",
    key: "welcome",
    value: "Bienvenue",
    approved: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

let languageConfigs: LanguageConfig[] = [
  {
    id: "lang-en",
    workspace_id: "default",
    language_code: "en",
    language_name: "English",
    native_name: "English",
    is_rtl: false,
    is_active: true,
    is_default: true,
    completion_percentage: 100,
    translators: ["system"],
    date_format: "MM/DD/YYYY",
    time_format: "12h",
    number_format: {
      decimal_separator: ".",
      thousands_separator: ",",
      currency_symbol: "$",
      currency_position: "before"
    },
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "lang-es",
    workspace_id: "default",
    language_code: "es",
    language_name: "Spanish",
    native_name: "Español",
    is_rtl: false,
    is_active: true,
    is_default: false,
    completion_percentage: 75,
    translators: ["translator1"],
    date_format: "DD/MM/YYYY",
    time_format: "24h",
    number_format: {
      decimal_separator: ",",
      thousands_separator: ".",
      currency_symbol: "€",
      currency_position: "after"
    },
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "lang-ar",
    workspace_id: "default",
    language_code: "ar",
    language_name: "Arabic",
    native_name: "العربية",
    is_rtl: true,
    is_active: true,
    is_default: false,
    completion_percentage: 60,
    translators: ["translator2"],
    date_format: "DD/MM/YYYY",
    time_format: "12h",
    number_format: {
      decimal_separator: ".",
      thousands_separator: ",",
      currency_symbol: "ر.س",
      currency_position: "after"
    },
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "lang-fr",
    workspace_id: "default",
    language_code: "fr",
    language_name: "French",
    native_name: "Français",
    is_rtl: false,
    is_active: true,
    is_default: false,
    completion_percentage: 90,
    translators: ["translator3"],
    date_format: "DD/MM/YYYY",
    time_format: "24h",
    number_format: {
      decimal_separator: ",",
      thousands_separator: " ",
      currency_symbol: "€",
      currency_position: "after"
    },
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

let themeConfigs: ThemeConfig[] = [
  {
    id: "theme-default",
    workspace_id: "default",
    name: "Default Light",
    type: "light",
    is_system_theme: true,
    is_active: true,
    accessibility_features: {
      high_contrast: false,
      color_blind_safe: true,
      focus_visible: true,
      motion_reduced: false
    },
    colors: {
      primary: "#3b82f6",
      secondary: "#64748b",
      background: "#ffffff",
      surface: "#f8fafc",
      text_primary: "#1e293b",
      text_secondary: "#475569",
      border: "#e2e8f0",
      error: "#ef4444",
      warning: "#f59e0b",
      success: "#10b981",
      info: "#3b82f6",
      focus: "#2563eb",
      hover: "#f1f5f9",
      disabled: "#94a3b8"
    },
    typography: {
      font_family_primary: "Inter, system-ui, sans-serif",
      font_family_secondary: "JetBrains Mono, monospace",
      font_size_base: 14,
      line_height_base: 1.5,
      letter_spacing_base: 0,
      heading_scale: [2.5, 2, 1.75, 1.5, 1.25, 1.125]
    },
    spacing: {
      base_unit: 4,
      scale: [0, 1, 2, 3, 4, 6, 8, 12, 16, 20, 24, 32, 40, 48, 64]
    },
    created_by: "system",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "theme-dark",
    workspace_id: "default",
    name: "Dark",
    type: "dark",
    is_system_theme: true,
    is_active: false,
    accessibility_features: {
      high_contrast: false,
      color_blind_safe: true,
      focus_visible: true,
      motion_reduced: false
    },
    colors: {
      primary: "#60a5fa",
      secondary: "#94a3b8",
      background: "#0f172a",
      surface: "#1e293b",
      text_primary: "#f1f5f9",
      text_secondary: "#cbd5e1",
      border: "#334155",
      error: "#f87171",
      warning: "#fbbf24",
      success: "#34d399",
      info: "#60a5fa",
      focus: "#3b82f6",
      hover: "#334155",
      disabled: "#64748b"
    },
    typography: {
      font_family_primary: "Inter, system-ui, sans-serif",
      font_family_secondary: "JetBrains Mono, monospace",
      font_size_base: 14,
      line_height_base: 1.5,
      letter_spacing_base: 0,
      heading_scale: [2.5, 2, 1.75, 1.5, 1.25, 1.125]
    },
    spacing: {
      base_unit: 4,
      scale: [0, 1, 2, 3, 4, 6, 8, 12, 16, 20, 24, 32, 40, 48, 64]
    },
    created_by: "system",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "theme-high-contrast",
    workspace_id: "default",
    name: "High Contrast",
    type: "high_contrast",
    is_system_theme: true,
    is_active: false,
    accessibility_features: {
      high_contrast: true,
      color_blind_safe: true,
      focus_visible: true,
      motion_reduced: true
    },
    colors: {
      primary: "#000000",
      secondary: "#333333",
      background: "#ffffff",
      surface: "#ffffff",
      text_primary: "#000000",
      text_secondary: "#333333",
      border: "#000000",
      error: "#cc0000",
      warning: "#ff6600",
      success: "#008800",
      info: "#0066cc",
      focus: "#ff0000",
      hover: "#eeeeee",
      disabled: "#999999"
    },
    typography: {
      font_family_primary: "Arial, sans-serif",
      font_family_secondary: "Courier, monospace",
      font_size_base: 16,
      line_height_base: 1.6,
      letter_spacing_base: 0.5,
      heading_scale: [2.5, 2, 1.75, 1.5, 1.25, 1.125]
    },
    spacing: {
      base_unit: 6,
      scale: [0, 1, 2, 3, 4, 6, 8, 12, 16, 20, 24, 32, 40, 48, 64]
    },
    created_by: "system",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

let accessibilityAudits: AccessibilityAudit[] = [];

// Validation schemas
const accessibilitySettingsSchema = z.object({
  preferences: z.object({
    high_contrast: z.boolean().default(false),
    large_text: z.boolean().default(false),
    reduce_motion: z.boolean().default(false),
    screen_reader_optimized: z.boolean().default(false),
    keyboard_navigation: z.boolean().default(true),
    focus_indicators: z.boolean().default(true),
    color_blind_friendly: z.boolean().default(false),
    dyslexia_friendly: z.boolean().default(false),
    font_family: z.enum(['default', 'dyslexia', 'high_contrast']).default('default'),
    font_size: z.enum(['small', 'medium', 'large', 'extra_large']).default('medium'),
    line_height: z.enum(['normal', 'relaxed', 'loose']).default('normal'),
    letter_spacing: z.enum(['normal', 'wide', 'wider']).default('normal')
  }),
  announcements: z.object({
    new_messages: z.boolean().default(true),
    user_joins: z.boolean().default(false),
    typing_indicators: z.boolean().default(true),
    reactions: z.boolean().default(true),
    system_alerts: z.boolean().default(true)
  }),
  shortcuts: z.record(z.string()).default({})
});

const translationSchema = z.object({
  language_code: z.string().min(2).max(5),
  namespace: z.string().min(1).max(50),
  key: z.string().min(1).max(100),
  value: z.string().min(1),
  context: z.string().optional(),
  pluralization: z.object({
    zero: z.string().optional(),
    one: z.string().optional(),
    two: z.string().optional(),
    few: z.string().optional(),
    many: z.string().optional(),
    other: z.string()
  }).optional(),
  variables: z.array(z.string()).default([])
});

const languageConfigSchema = z.object({
  language_code: z.string().min(2).max(5),
  language_name: z.string().min(1).max(50),
  native_name: z.string().min(1).max(50),
  is_rtl: z.boolean().default(false),
  is_active: z.boolean().default(true),
  date_format: z.string().default("MM/DD/YYYY"),
  time_format: z.enum(['12h', '24h']).default('12h'),
  number_format: z.object({
    decimal_separator: z.string().length(1),
    thousands_separator: z.string().max(1),
    currency_symbol: z.string().max(5),
    currency_position: z.enum(['before', 'after'])
  })
});

const themeConfigSchema = z.object({
  name: z.string().min(1).max(50),
  type: z.enum(['light', 'dark', 'high_contrast', 'custom']),
  accessibility_features: z.object({
    high_contrast: z.boolean().default(false),
    color_blind_safe: z.boolean().default(true),
    focus_visible: z.boolean().default(true),
    motion_reduced: z.boolean().default(false)
  }),
  colors: z.object({
    primary: z.string().regex(/^#[0-9A-F]{6}$/i),
    secondary: z.string().regex(/^#[0-9A-F]{6}$/i),
    background: z.string().regex(/^#[0-9A-F]{6}$/i),
    surface: z.string().regex(/^#[0-9A-F]{6}$/i),
    text_primary: z.string().regex(/^#[0-9A-F]{6}$/i),
    text_secondary: z.string().regex(/^#[0-9A-F]{6}$/i),
    border: z.string().regex(/^#[0-9A-F]{6}$/i),
    error: z.string().regex(/^#[0-9A-F]{6}$/i),
    warning: z.string().regex(/^#[0-9A-F]{6}$/i),
    success: z.string().regex(/^#[0-9A-F]{6}$/i),
    info: z.string().regex(/^#[0-9A-F]{6}$/i),
    focus: z.string().regex(/^#[0-9A-F]{6}$/i),
    hover: z.string().regex(/^#[0-9A-F]{6}$/i),
    disabled: z.string().regex(/^#[0-9A-F]{6}$/i)
  }),
  typography: z.object({
    font_family_primary: z.string(),
    font_family_secondary: z.string(),
    font_size_base: z.number().min(10).max(24),
    line_height_base: z.number().min(1).max(3),
    letter_spacing_base: z.number().min(-2).max(5),
    heading_scale: z.array(z.number()).length(6)
  }),
  custom_css: z.string().optional()
});

// API endpoints
export const getAccessibilitySettings: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const userSettings = accessibilitySettings.find(s => s.user_id === user.id);
    
    res.json({
      success: true,
      data: userSettings || {
        id: `new-${Date.now()}`,
        user_id: user.id,
        workspace_id: "default",
        preferences: {
          high_contrast: false,
          large_text: false,
          reduce_motion: false,
          screen_reader_optimized: false,
          keyboard_navigation: true,
          focus_indicators: true,
          color_blind_friendly: false,
          dyslexia_friendly: false,
          font_family: 'default',
          font_size: 'medium',
          line_height: 'normal',
          letter_spacing: 'normal'
        },
        announcements: {
          new_messages: true,
          user_joins: false,
          typing_indicators: true,
          reactions: true,
          system_alerts: true
        },
        shortcuts: {},
        updated_at: new Date().toISOString()
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get accessibility settings"
    } as ApiResponse);
  }
};

export const updateAccessibilitySettings: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = accessibilitySettingsSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid settings data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const existingIndex = accessibilitySettings.findIndex(s => s.user_id === user.id);
    
    const settings: AccessibilitySettings = {
      id: existingIndex !== -1 ? accessibilitySettings[existingIndex].id : `settings-${Date.now()}`,
      user_id: user.id,
      workspace_id: "default",
      ...validation.data,
      updated_at: new Date().toISOString()
    };

    if (existingIndex !== -1) {
      accessibilitySettings[existingIndex] = settings;
    } else {
      accessibilitySettings.push(settings);
    }

    res.json({
      success: true,
      data: settings
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to update accessibility settings"
    } as ApiResponse);
  }
};

export const getLanguages: RequestHandler = (req, res) => {
  try {
    const { active_only = 'false' } = req.query;
    
    let filteredLanguages = languageConfigs.filter(lang => lang.workspace_id === "default");
    
    if (active_only === 'true') {
      filteredLanguages = filteredLanguages.filter(lang => lang.is_active);
    }
    
    // Sort by completion percentage descending
    filteredLanguages.sort((a, b) => b.completion_percentage - a.completion_percentage);
    
    res.json({
      success: true,
      data: filteredLanguages
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get languages"
    } as ApiResponse);
  }
};

export const createLanguage: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = languageConfigSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid language data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    // Check if language already exists
    const existingLanguage = languageConfigs.find(lang => 
      lang.language_code === validation.data.language_code && 
      lang.workspace_id === "default"
    );

    if (existingLanguage) {
      return res.status(400).json({
        success: false,
        error: "Language already exists"
      } as ApiResponse);
    }

    const language: LanguageConfig = {
      id: `lang-${validation.data.language_code}`,
      workspace_id: "default",
      ...validation.data,
      is_default: false,
      completion_percentage: 0,
      translators: [user.id],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    languageConfigs.push(language);

    res.status(201).json({
      success: true,
      data: language
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create language"
    } as ApiResponse);
  }
};

export const getTranslations: RequestHandler = (req, res) => {
  try {
    const { language_code, namespace, approved_only = 'false' } = req.query;
    
    let filteredTranslations = translations.filter(t => t.workspace_id === "default");
    
    if (language_code) {
      filteredTranslations = filteredTranslations.filter(t => t.language_code === language_code);
    }
    
    if (namespace) {
      filteredTranslations = filteredTranslations.filter(t => t.namespace === namespace);
    }
    
    if (approved_only === 'true') {
      filteredTranslations = filteredTranslations.filter(t => t.approved);
    }
    
    // Group by namespace and key for easier frontend consumption
    const groupedTranslations = filteredTranslations.reduce((acc, translation) => {
      const key = `${translation.namespace}.${translation.key}`;
      if (!acc[key]) {
        acc[key] = {};
      }
      acc[key][translation.language_code] = translation;
      return acc;
    }, {} as Record<string, Record<string, Translation>>);
    
    res.json({
      success: true,
      data: {
        translations: filteredTranslations,
        grouped: groupedTranslations,
        total: filteredTranslations.length
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get translations"
    } as ApiResponse);
  }
};

export const createTranslation: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = translationSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid translation data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    // Check if translation already exists
    const existingTranslation = translations.find(t => 
      t.workspace_id === "default" &&
      t.language_code === validation.data.language_code &&
      t.namespace === validation.data.namespace &&
      t.key === validation.data.key
    );

    if (existingTranslation) {
      return res.status(400).json({
        success: false,
        error: "Translation already exists"
      } as ApiResponse);
    }

    const translation: Translation = {
      id: `trans-${Date.now()}`,
      workspace_id: "default",
      ...validation.data,
      approved: false,
      translated_by: user.id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    translations.push(translation);

    // Update language completion percentage
    updateLanguageCompletionPercentage(validation.data.language_code);

    res.status(201).json({
      success: true,
      data: translation
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create translation"
    } as ApiResponse);
  }
};

export const getThemes: RequestHandler = (req, res) => {
  try {
    const { type, active_only = 'false' } = req.query;
    
    let filteredThemes = themeConfigs.filter(theme => theme.workspace_id === "default");
    
    if (type) {
      filteredThemes = filteredThemes.filter(theme => theme.type === type);
    }
    
    if (active_only === 'true') {
      filteredThemes = filteredThemes.filter(theme => theme.is_active);
    }
    
    res.json({
      success: true,
      data: filteredThemes
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get themes"
    } as ApiResponse);
  }
};

export const createTheme: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = themeConfigSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid theme data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const theme: ThemeConfig = {
      id: `theme-${Date.now()}`,
      workspace_id: "default",
      ...validation.data,
      is_system_theme: false,
      is_active: false,
      spacing: {
        base_unit: 4,
        scale: [0, 1, 2, 3, 4, 6, 8, 12, 16, 20, 24, 32, 40, 48, 64]
      },
      created_by: user.id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    themeConfigs.push(theme);

    res.status(201).json({
      success: true,
      data: theme
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create theme"
    } as ApiResponse);
  }
};

export const runAccessibilityAudit: RequestHandler = async (req, res) => {
  try {
    const user = (req as any).user as User;
    const { page_url, audit_type = 'automated' } = req.body;
    
    if (!page_url) {
      return res.status(400).json({
        success: false,
        error: "Page URL is required"
      } as ApiResponse);
    }

    const audit: AccessibilityAudit = {
      id: `audit-${Date.now()}`,
      workspace_id: "default",
      audit_type: audit_type as any,
      page_url,
      issues: [], // Will be populated by actual audit
      score: {
        overall: 0,
        level_a: 0,
        level_aa: 0,
        level_aaa: 0
      },
      conducted_by: user.id,
      conducted_at: new Date().toISOString(),
      status: 'in_progress'
    };

    accessibilityAudits.push(audit);

    // Simulate audit process
    setTimeout(() => {
      const auditIndex = accessibilityAudits.findIndex(a => a.id === audit.id);
      if (auditIndex !== -1) {
        // Mock audit results
        accessibilityAudits[auditIndex] = {
          ...audit,
          issues: [
            {
              level: 'AA',
              severity: 'serious',
              rule_id: 'color-contrast',
              rule_name: 'Color Contrast',
              description: 'Elements must have sufficient color contrast',
              element_selector: '.button-primary',
              recommendation: 'Increase contrast ratio to at least 4.5:1',
              wcag_criterion: '1.4.3'
            },
            {
              level: 'A',
              severity: 'critical',
              rule_id: 'keyboard-navigation',
              rule_name: 'Keyboard Navigation',
              description: 'All interactive elements must be keyboard accessible',
              element_selector: '.modal-close',
              recommendation: 'Add tabindex and keyboard event handlers',
              wcag_criterion: '2.1.1'
            }
          ],
          score: {
            overall: 85,
            level_a: 90,
            level_aa: 80,
            level_aaa: 75
          },
          status: 'completed'
        };
      }
    }, 3000);

    res.status(201).json({
      success: true,
      data: audit,
      message: "Accessibility audit started"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to run accessibility audit"
    } as ApiResponse);
  }
};

export const getAccessibilityAudits: RequestHandler = (req, res) => {
  try {
    const { status, limit = 20, offset = 0 } = req.query;
    
    let filteredAudits = accessibilityAudits.filter(audit => audit.workspace_id === "default");
    
    if (status) {
      filteredAudits = filteredAudits.filter(audit => audit.status === status);
    }
    
    // Sort by conducted date descending
    filteredAudits.sort((a, b) => 
      new Date(b.conducted_at).getTime() - new Date(a.conducted_at).getTime()
    );
    
    const paginatedAudits = filteredAudits.slice(
      Number(offset), 
      Number(offset) + Number(limit)
    );
    
    res.json({
      success: true,
      data: {
        audits: paginatedAudits,
        total: filteredAudits.length,
        offset: Number(offset),
        limit: Number(limit)
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get accessibility audits"
    } as ApiResponse);
  }
};

// Helper function to update language completion percentage
function updateLanguageCompletionPercentage(languageCode: string) {
  const englishTranslations = translations.filter(t => 
    t.language_code === 'en' && t.workspace_id === "default"
  );
  const languageTranslations = translations.filter(t => 
    t.language_code === languageCode && t.workspace_id === "default"
  );
  
  const completionPercentage = englishTranslations.length > 0 
    ? Math.round((languageTranslations.length / englishTranslations.length) * 100)
    : 0;
  
  const languageIndex = languageConfigs.findIndex(lang => 
    lang.language_code === languageCode && lang.workspace_id === "default"
  );
  
  if (languageIndex !== -1) {
    languageConfigs[languageIndex].completion_percentage = completionPercentage;
    languageConfigs[languageIndex].updated_at = new Date().toISOString();
  }
}
