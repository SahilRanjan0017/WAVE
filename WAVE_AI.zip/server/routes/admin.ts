import { RequestHandler } from "express";
import { z } from "zod";
import { ApiResponse, User } from "@shared/api";

interface AdminUser extends User {
  role: 'admin' | 'moderator' | 'user';
  permissions: string[];
  last_login: string;
  is_suspended: boolean;
}

interface WorkspaceAnalytics {
  total_users: number;
  active_users_today: number;
  active_users_week: number;
  total_messages: number;
  messages_today: number;
  total_channels: number;
  total_files: number;
  storage_used: number; // in bytes
  top_channels: { name: string; message_count: number; member_count: number }[];
  user_activity: { date: string; active_users: number; messages: number }[];
  growth_metrics: {
    users: { current: number; previous: number; change: number };
    messages: { current: number; previous: number; change: number };
    engagement: { current: number; previous: number; change: number };
  };
}

interface SystemMetrics {
  server_uptime: number;
  memory_usage: number;
  cpu_usage: number;
  disk_usage: number;
  active_connections: number;
  response_time: number;
  error_rate: number;
}

interface SecurityEvent {
  id: string;
  type: 'login_failure' | 'suspicious_activity' | 'permission_change' | 'data_export';
  user_id: string;
  ip_address: string;
  user_agent: string;
  details: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  created_at: string;
}

// Mock data
let adminUsers: AdminUser[] = [
  {
    id: "1",
    email: "sahil@example.com",
    username: "sahil",
    full_name: "Sahil Ranjan",
    avatar_url: "",
    status: "online",
    created_at: new Date().toISOString(),
    role: "admin",
    permissions: ["all"],
    last_login: new Date().toISOString(),
    is_suspended: false
  }
];

let securityEvents: SecurityEvent[] = [];

// Middleware to check admin permissions
export const requireAdmin: RequestHandler = (req, res, next) => {
  const user = (req as any).user as User;
  const adminUser = adminUsers.find(u => u.id === user.id);
  
  if (!adminUser || (adminUser.role !== 'admin' && adminUser.role !== 'moderator')) {
    return res.status(403).json({
      success: false,
      error: "Admin access required"
    } as ApiResponse);
  }
  
  (req as any).adminUser = adminUser;
  next();
};

export const getWorkspaceAnalytics: RequestHandler = (req, res) => {
  try {
    const { workspace_id, period = '30d' } = req.query;
    
    // Mock analytics data - in production, query from database
    const analytics: WorkspaceAnalytics = {
      total_users: 150,
      active_users_today: 85,
      active_users_week: 120,
      total_messages: 15420,
      messages_today: 380,
      total_channels: 25,
      total_files: 890,
      storage_used: 2.4 * 1024 * 1024 * 1024, // 2.4 GB
      top_channels: [
        { name: "general", message_count: 3420, member_count: 150 },
        { name: "development", message_count: 2890, member_count: 45 },
        { name: "design", message_count: 1650, member_count: 20 },
        { name: "marketing", message_count: 1200, member_count: 15 },
        { name: "support", message_count: 980, member_count: 30 }
      ],
      user_activity: generateActivityData(period as string),
      growth_metrics: {
        users: { current: 150, previous: 140, change: 7.1 },
        messages: { current: 15420, previous: 14200, change: 8.6 },
        engagement: { current: 75.2, previous: 72.8, change: 3.3 }
      }
    };

    res.json({
      success: true,
      data: analytics
    } as ApiResponse<WorkspaceAnalytics>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to fetch analytics"
    } as ApiResponse);
  }
};

export const getSystemMetrics: RequestHandler = (req, res) => {
  try {
    // Mock system metrics - in production, get from monitoring service
    const metrics: SystemMetrics = {
      server_uptime: 99.8,
      memory_usage: 65.2,
      cpu_usage: 45.7,
      disk_usage: 78.3,
      active_connections: 342,
      response_time: 145, // ms
      error_rate: 0.02 // percentage
    };

    res.json({
      success: true,
      data: metrics
    } as ApiResponse<SystemMetrics>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to fetch system metrics"
    } as ApiResponse);
  }
};

export const getAllUsers: RequestHandler = (req, res) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 50;
    const search = req.query.search as string;
    const role = req.query.role as string;
    const status = req.query.status as string;

    let filteredUsers = adminUsers;

    // Apply filters
    if (search) {
      filteredUsers = filteredUsers.filter(user => 
        user.full_name.toLowerCase().includes(search.toLowerCase()) ||
        user.email.toLowerCase().includes(search.toLowerCase()) ||
        user.username.toLowerCase().includes(search.toLowerCase())
      );
    }

    if (role) {
      filteredUsers = filteredUsers.filter(user => user.role === role);
    }

    if (status) {
      if (status === 'suspended') {
        filteredUsers = filteredUsers.filter(user => user.is_suspended);
      } else {
        filteredUsers = filteredUsers.filter(user => user.status === status);
      }
    }

    // Pagination
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedUsers = filteredUsers.slice(startIndex, endIndex);

    res.json({
      success: true,
      data: {
        data: paginatedUsers,
        page,
        limit,
        total: filteredUsers.length,
        has_more: endIndex < filteredUsers.length
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to fetch users"
    } as ApiResponse);
  }
};

export const updateUserRole: RequestHandler = (req, res) => {
  try {
    const { userId } = req.params;
    const { role, permissions } = req.body;
    const adminUser = (req as any).adminUser as AdminUser;

    // Only admins can change roles
    if (adminUser.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: "Only admins can change user roles"
      } as ApiResponse);
    }

    const userIndex = adminUsers.findIndex(u => u.id === userId);
    if (userIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "User not found"
      } as ApiResponse);
    }

    adminUsers[userIndex].role = role;
    if (permissions) {
      adminUsers[userIndex].permissions = permissions;
    }

    // Log security event
    logSecurityEvent('permission_change', adminUser.id, {
      target_user: userId,
      new_role: role,
      new_permissions: permissions
    });

    res.json({
      success: true,
      data: adminUsers[userIndex]
    } as ApiResponse<AdminUser>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to update user role"
    } as ApiResponse);
  }
};

export const suspendUser: RequestHandler = (req, res) => {
  try {
    const { userId } = req.params;
    const { reason, duration } = req.body;
    const adminUser = (req as any).adminUser as AdminUser;

    const userIndex = adminUsers.findIndex(u => u.id === userId);
    if (userIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "User not found"
      } as ApiResponse);
    }

    adminUsers[userIndex].is_suspended = true;

    // Log security event
    logSecurityEvent('suspicious_activity', adminUser.id, {
      action: 'user_suspended',
      target_user: userId,
      reason,
      duration
    });

    res.json({
      success: true,
      message: "User suspended successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to suspend user"
    } as ApiResponse);
  }
};

export const getSecurityEvents: RequestHandler = (req, res) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 50;
    const severity = req.query.severity as string;
    const type = req.query.type as string;

    let filteredEvents = securityEvents;

    if (severity) {
      filteredEvents = filteredEvents.filter(event => event.severity === severity);
    }

    if (type) {
      filteredEvents = filteredEvents.filter(event => event.type === type);
    }

    // Sort by most recent
    filteredEvents.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedEvents = filteredEvents.slice(startIndex, endIndex);

    res.json({
      success: true,
      data: {
        data: paginatedEvents,
        page,
        limit,
        total: filteredEvents.length,
        has_more: endIndex < filteredEvents.length
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to fetch security events"
    } as ApiResponse);
  }
};

export const getAuditLog: RequestHandler = (req, res) => {
  try {
    const { start_date, end_date, user_id, action_type } = req.query;
    
    // Mock audit log - in production, query from audit database
    const auditLog = [
      {
        id: "1",
        user_id: "1",
        action: "user_login",
        resource: "system",
        details: "User logged in successfully",
        ip_address: "192.168.1.100",
        user_agent: "Mozilla/5.0...",
        timestamp: new Date(Date.now() - 3600000).toISOString()
      },
      {
        id: "2",
        user_id: "1",
        action: "channel_created",
        resource: "channel:general",
        details: "Created new channel #general",
        ip_address: "192.168.1.100",
        user_agent: "Mozilla/5.0...",
        timestamp: new Date(Date.now() - 7200000).toISOString()
      }
    ];

    res.json({
      success: true,
      data: auditLog
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to fetch audit log"
    } as ApiResponse);
  }
};

export const exportData: RequestHandler = (req, res) => {
  try {
    const { data_type, format = 'json', date_range } = req.body;
    const adminUser = (req as any).adminUser as AdminUser;

    // Log data export event
    logSecurityEvent('data_export', adminUser.id, {
      data_type,
      format,
      date_range
    });

    // In production, generate and return export file
    const exportData = {
      export_id: Date.now().toString(),
      status: 'processing',
      estimated_completion: new Date(Date.now() + 300000).toISOString(), // 5 minutes
      download_url: null
    };

    res.json({
      success: true,
      data: exportData
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to initiate data export"
    } as ApiResponse);
  }
};

export const getWorkspaceSettings: RequestHandler = (req, res) => {
  try {
    const { workspace_id } = req.params;
    
    // Mock workspace settings
    const settings = {
      workspace_id,
      name: "Acme Corp Workspace",
      description: "Main workspace for Acme Corporation",
      settings: {
        message_retention_days: 365,
        file_retention_days: 730,
        max_file_size_mb: 100,
        allow_external_integrations: true,
        require_2fa: false,
        allowed_domains: ["acme.com"],
        custom_emojis_enabled: true,
        guest_access_enabled: false
      },
      features: {
        voice_calls: true,
        screen_sharing: true,
        workflows: true,
        ai_search: true,
        analytics: true
      },
      billing: {
        plan: "Enterprise",
        seats_total: 150,
        seats_used: 142,
        billing_cycle: "monthly",
        next_billing_date: "2024-02-01T00:00:00Z"
      }
    };

    res.json({
      success: true,
      data: settings
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to fetch workspace settings"
    } as ApiResponse);
  }
};

export const updateWorkspaceSettings: RequestHandler = (req, res) => {
  try {
    const { workspace_id } = req.params;
    const updates = req.body;
    const adminUser = (req as any).adminUser as AdminUser;

    // Log configuration change
    logSecurityEvent('permission_change', adminUser.id, {
      action: 'workspace_settings_updated',
      workspace_id,
      changes: Object.keys(updates)
    });

    res.json({
      success: true,
      message: "Workspace settings updated successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to update workspace settings"
    } as ApiResponse);
  }
};

// Helper functions
function generateActivityData(period: string) {
  const days = period === '7d' ? 7 : period === '30d' ? 30 : 90;
  const data = [];
  
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    data.push({
      date: date.toISOString().split('T')[0],
      active_users: Math.floor(Math.random() * 100) + 50,
      messages: Math.floor(Math.random() * 500) + 200
    });
  }
  
  return data;
}

function logSecurityEvent(
  type: SecurityEvent['type'], 
  userId: string, 
  details: any,
  severity: SecurityEvent['severity'] = 'medium'
) {
  const event: SecurityEvent = {
    id: Date.now().toString(),
    type,
    user_id: userId,
    ip_address: '192.168.1.100', // In production, get from request
    user_agent: 'Admin Panel', // In production, get from request
    details: JSON.stringify(details),
    severity,
    created_at: new Date().toISOString()
  };
  
  securityEvents.unshift(event);
  
  // Keep only latest 1000 events
  if (securityEvents.length > 1000) {
    securityEvents = securityEvents.slice(0, 1000);
  }
}
