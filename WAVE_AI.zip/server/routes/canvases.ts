import { RequestHandler } from "express";
import { z } from "zod";
import { ApiResponse, User } from "@shared/api";

interface Canvas {
  id: string;
  title: string;
  workspace_id: string;
  channel_id?: string;
  created_by: string;
  content: CanvasBlock[];
  collaborators: CanvasCollaborator[];
  version: number;
  is_template: boolean;
  template_category?: string;
  permissions: {
    read: string[];
    write: string[];
    comment: string[];
  };
  created_at: string;
  updated_at: string;
  last_accessed: string;
}

interface CanvasBlock {
  id: string;
  type: 'text' | 'heading' | 'list' | 'image' | 'link' | 'table' | 'code' | 'divider' | 'embed' | 'file';
  content: any;
  position: { x: number; y: number };
  size: { width: number; height: number };
  style?: { [key: string]: any };
  created_by: string;
  created_at: string;
  updated_at: string;
}

interface CanvasCollaborator {
  user_id: string;
  role: 'editor' | 'commenter' | 'viewer';
  cursor_position?: { x: number; y: number };
  selection?: { block_id: string; start: number; end: number };
  last_seen: string;
  is_online: boolean;
}

interface CanvasComment {
  id: string;
  canvas_id: string;
  block_id?: string;
  position?: { x: number; y: number };
  content: string;
  author_id: string;
  replies: CanvasComment[];
  resolved: boolean;
  created_at: string;
  updated_at: string;
}

interface CanvasVersion {
  id: string;
  canvas_id: string;
  version_number: number;
  content: CanvasBlock[];
  changes_summary: string;
  created_by: string;
  created_at: string;
}

// Mock databases
let canvases: Canvas[] = [];
let canvasComments: CanvasComment[] = [];
let canvasVersions: CanvasVersion[] = [];

// Canvas templates
const canvasTemplates: Partial<Canvas>[] = [
  {
    id: 'meeting_notes',
    title: 'Meeting Notes Template',
    is_template: true,
    template_category: 'meetings',
    content: [
      {
        id: '1',
        type: 'heading',
        content: { text: 'Meeting Notes - [Date]', level: 1 },
        position: { x: 0, y: 0 },
        size: { width: 800, height: 60 },
        created_by: 'system',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: '2',
        type: 'text',
        content: { text: '**Attendees:**\n• \n• \n• ' },
        position: { x: 0, y: 80 },
        size: { width: 400, height: 100 },
        created_by: 'system',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: '3',
        type: 'text',
        content: { text: '**Agenda:**\n1. \n2. \n3. ' },
        position: { x: 0, y: 200 },
        size: { width: 400, height: 120 },
        created_by: 'system',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: '4',
        type: 'text',
        content: { text: '**Action Items:**\n- [ ] \n- [ ] \n- [ ] ' },
        position: { x: 0, y: 340 },
        size: { width: 400, height: 120 },
        created_by: 'system',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }
    ]
  },
  {
    id: 'project_brief',
    title: 'Project Brief Template',
    is_template: true,
    template_category: 'projects',
    content: [
      {
        id: '1',
        type: 'heading',
        content: { text: 'Project Brief: [Project Name]', level: 1 },
        position: { x: 0, y: 0 },
        size: { width: 800, height: 60 },
        created_by: 'system',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: '2',
        type: 'text',
        content: { text: '**Project Overview:**\n\nDescribe the project goals, scope, and key objectives here.' },
        position: { x: 0, y: 80 },
        size: { width: 800, height: 120 },
        created_by: 'system',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: '3',
        type: 'table',
        content: {
          headers: ['Milestone', 'Due Date', 'Owner', 'Status'],
          rows: [
            ['Phase 1 Complete', 'TBD', 'TBD', 'Not Started'],
            ['Phase 2 Complete', 'TBD', 'TBD', 'Not Started']
          ]
        },
        position: { x: 0, y: 220 },
        size: { width: 800, height: 150 },
        created_by: 'system',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }
    ]
  }
];

// Validation schemas
const createCanvasSchema = z.object({
  title: z.string().min(1).max(200),
  workspace_id: z.string(),
  channel_id: z.string().optional(),
  template_id: z.string().optional(),
  permissions: z.object({
    read: z.array(z.string()),
    write: z.array(z.string()),
    comment: z.array(z.string())
  }).optional()
});

const updateCanvasSchema = z.object({
  title: z.string().min(1).max(200).optional(),
  content: z.array(z.any()).optional(),
  permissions: z.object({
    read: z.array(z.string()),
    write: z.array(z.string()),
    comment: z.array(z.string())
  }).optional()
});

const addBlockSchema = z.object({
  type: z.enum(['text', 'heading', 'list', 'image', 'link', 'table', 'code', 'divider', 'embed', 'file']),
  content: z.any(),
  position: z.object({
    x: z.number(),
    y: z.number()
  }),
  size: z.object({
    width: z.number(),
    height: z.number()
  }),
  style: z.record(z.any()).optional()
});

export const getCanvases: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspace_id, channel_id } = req.query;

    let userCanvases = canvases.filter(canvas => {
      // Check if user has read permission
      return canvas.permissions.read.includes('all') || 
             canvas.permissions.read.includes(user.id) ||
             canvas.created_by === user.id;
    });

    if (workspace_id) {
      userCanvases = userCanvases.filter(c => c.workspace_id === workspace_id);
    }

    if (channel_id) {
      userCanvases = userCanvases.filter(c => c.channel_id === channel_id);
    }

    // Sort by last accessed
    userCanvases.sort((a, b) => 
      new Date(b.last_accessed).getTime() - new Date(a.last_accessed).getTime()
    );

    res.json({
      success: true,
      data: userCanvases.map(canvas => ({
        ...canvas,
        content: undefined, // Don't include full content in list
        content_preview: canvas.content.slice(0, 3).map(block => ({
          type: block.type,
          content: typeof block.content === 'string' 
            ? block.content.substring(0, 100) 
            : block.content
        }))
      }))
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getCanvas: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { canvasId } = req.params;

    const canvas = canvases.find(c => c.id === canvasId);
    if (!canvas) {
      return res.status(404).json({
        success: false,
        error: "Canvas not found"
      } as ApiResponse);
    }

    // Check read permission
    if (!canvas.permissions.read.includes('all') && 
        !canvas.permissions.read.includes(user.id) &&
        canvas.created_by !== user.id) {
      return res.status(403).json({
        success: false,
        error: "Access denied"
      } as ApiResponse);
    }

    // Update last accessed
    const canvasIndex = canvases.findIndex(c => c.id === canvasId);
    if (canvasIndex !== -1) {
      canvases[canvasIndex].last_accessed = new Date().toISOString();
    }

    // Add user as collaborator if not already present
    const collaboratorIndex = canvas.collaborators.findIndex(c => c.user_id === user.id);
    if (collaboratorIndex === -1) {
      canvas.collaborators.push({
        user_id: user.id,
        role: canvas.permissions.write.includes(user.id) || canvas.created_by === user.id ? 'editor' : 'viewer',
        last_seen: new Date().toISOString(),
        is_online: true
      });
    } else {
      canvas.collaborators[collaboratorIndex].is_online = true;
      canvas.collaborators[collaboratorIndex].last_seen = new Date().toISOString();
    }

    res.json({
      success: true,
      data: canvas
    } as ApiResponse<Canvas>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const createCanvas: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = createCanvasSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid canvas data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const { title, workspace_id, channel_id, template_id, permissions } = validation.data;

    let content: CanvasBlock[] = [];
    
    // Use template if specified
    if (template_id) {
      const template = canvasTemplates.find(t => t.id === template_id);
      if (template && template.content) {
        content = template.content.map(block => ({
          ...block,
          id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
          created_by: user.id
        }));
      }
    }

    const canvas: Canvas = {
      id: Date.now().toString(),
      title,
      workspace_id,
      channel_id,
      created_by: user.id,
      content,
      collaborators: [{
        user_id: user.id,
        role: 'editor',
        last_seen: new Date().toISOString(),
        is_online: true
      }],
      version: 1,
      is_template: false,
      permissions: permissions || {
        read: ['all'],
        write: [user.id],
        comment: ['all']
      },
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      last_accessed: new Date().toISOString()
    };

    canvases.push(canvas);

    res.status(201).json({
      success: true,
      data: canvas
    } as ApiResponse<Canvas>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const updateCanvas: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { canvasId } = req.params;
    const validation = updateCanvasSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid update data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const canvasIndex = canvases.findIndex(c => c.id === canvasId);
    if (canvasIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Canvas not found"
      } as ApiResponse);
    }

    const canvas = canvases[canvasIndex];

    // Check write permission
    if (!canvas.permissions.write.includes(user.id) && canvas.created_by !== user.id) {
      return res.status(403).json({
        success: false,
        error: "Insufficient permissions"
      } as ApiResponse);
    }

    const updates = validation.data;

    // Create version snapshot before update
    if (updates.content) {
      const version: CanvasVersion = {
        id: Date.now().toString(),
        canvas_id: canvasId,
        version_number: canvas.version,
        content: canvas.content,
        changes_summary: 'Canvas updated',
        created_by: user.id,
        created_at: new Date().toISOString()
      };
      canvasVersions.push(version);
    }

    // Update canvas
    canvases[canvasIndex] = {
      ...canvas,
      ...updates,
      version: updates.content ? canvas.version + 1 : canvas.version,
      updated_at: new Date().toISOString()
    };

    res.json({
      success: true,
      data: canvases[canvasIndex]
    } as ApiResponse<Canvas>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const deleteCanvas: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { canvasId } = req.params;

    const canvasIndex = canvases.findIndex(c => c.id === canvasId);
    if (canvasIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Canvas not found"
      } as ApiResponse);
    }

    const canvas = canvases[canvasIndex];

    // Only creator can delete
    if (canvas.created_by !== user.id) {
      return res.status(403).json({
        success: false,
        error: "Only the creator can delete this canvas"
      } as ApiResponse);
    }

    canvases.splice(canvasIndex, 1);

    // Clean up related data
    canvasComments = canvasComments.filter(c => c.canvas_id !== canvasId);
    canvasVersions = canvasVersions.filter(v => v.canvas_id !== canvasId);

    res.json({
      success: true,
      message: "Canvas deleted successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const addBlock: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { canvasId } = req.params;
    const validation = addBlockSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid block data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const canvasIndex = canvases.findIndex(c => c.id === canvasId);
    if (canvasIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Canvas not found"
      } as ApiResponse);
    }

    const canvas = canvases[canvasIndex];

    // Check write permission
    if (!canvas.permissions.write.includes(user.id) && canvas.created_by !== user.id) {
      return res.status(403).json({
        success: false,
        error: "Insufficient permissions"
      } as ApiResponse);
    }

    const blockData = validation.data;
    const block: CanvasBlock = {
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      ...blockData,
      created_by: user.id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    canvases[canvasIndex].content.push(block);
    canvases[canvasIndex].version++;
    canvases[canvasIndex].updated_at = new Date().toISOString();

    res.status(201).json({
      success: true,
      data: block
    } as ApiResponse<CanvasBlock>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const updateBlock: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { canvasId, blockId } = req.params;

    const canvasIndex = canvases.findIndex(c => c.id === canvasId);
    if (canvasIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Canvas not found"
      } as ApiResponse);
    }

    const canvas = canvases[canvasIndex];

    // Check write permission
    if (!canvas.permissions.write.includes(user.id) && canvas.created_by !== user.id) {
      return res.status(403).json({
        success: false,
        error: "Insufficient permissions"
      } as ApiResponse);
    }

    const blockIndex = canvas.content.findIndex(b => b.id === blockId);
    if (blockIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Block not found"
      } as ApiResponse);
    }

    const updates = req.body;
    canvases[canvasIndex].content[blockIndex] = {
      ...canvas.content[blockIndex],
      ...updates,
      updated_at: new Date().toISOString()
    };

    canvases[canvasIndex].updated_at = new Date().toISOString();

    res.json({
      success: true,
      data: canvases[canvasIndex].content[blockIndex]
    } as ApiResponse<CanvasBlock>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const deleteBlock: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { canvasId, blockId } = req.params;

    const canvasIndex = canvases.findIndex(c => c.id === canvasId);
    if (canvasIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Canvas not found"
      } as ApiResponse);
    }

    const canvas = canvases[canvasIndex];

    // Check write permission
    if (!canvas.permissions.write.includes(user.id) && canvas.created_by !== user.id) {
      return res.status(403).json({
        success: false,
        error: "Insufficient permissions"
      } as ApiResponse);
    }

    const blockIndex = canvas.content.findIndex(b => b.id === blockId);
    if (blockIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Block not found"
      } as ApiResponse);
    }

    canvases[canvasIndex].content.splice(blockIndex, 1);
    canvases[canvasIndex].updated_at = new Date().toISOString();

    res.json({
      success: true,
      message: "Block deleted successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getCanvasTemplates: RequestHandler = (req, res) => {
  try {
    const { category } = req.query;
    
    let templates = canvasTemplates;
    
    if (category) {
      templates = templates.filter(t => t.template_category === category);
    }

    res.json({
      success: true,
      data: templates
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const addComment: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { canvasId } = req.params;
    const { content, block_id, position } = req.body;

    const canvas = canvases.find(c => c.id === canvasId);
    if (!canvas) {
      return res.status(404).json({
        success: false,
        error: "Canvas not found"
      } as ApiResponse);
    }

    // Check comment permission
    if (!canvas.permissions.comment.includes('all') && 
        !canvas.permissions.comment.includes(user.id) &&
        canvas.created_by !== user.id) {
      return res.status(403).json({
        success: false,
        error: "Insufficient permissions to comment"
      } as ApiResponse);
    }

    const comment: CanvasComment = {
      id: Date.now().toString(),
      canvas_id: canvasId,
      block_id,
      position,
      content,
      author_id: user.id,
      replies: [],
      resolved: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    canvasComments.push(comment);

    res.status(201).json({
      success: true,
      data: comment
    } as ApiResponse<CanvasComment>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getCanvasComments: RequestHandler = (req, res) => {
  try {
    const { canvasId } = req.params;

    const comments = canvasComments.filter(c => c.canvas_id === canvasId);

    res.json({
      success: true,
      data: comments
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getCanvasVersions: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { canvasId } = req.params;

    const canvas = canvases.find(c => c.id === canvasId);
    if (!canvas) {
      return res.status(404).json({
        success: false,
        error: "Canvas not found"
      } as ApiResponse);
    }

    // Check read permission
    if (!canvas.permissions.read.includes('all') && 
        !canvas.permissions.read.includes(user.id) &&
        canvas.created_by !== user.id) {
      return res.status(403).json({
        success: false,
        error: "Access denied"
      } as ApiResponse);
    }

    const versions = canvasVersions
      .filter(v => v.canvas_id === canvasId)
      .sort((a, b) => b.version_number - a.version_number);

    res.json({
      success: true,
      data: versions
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};
