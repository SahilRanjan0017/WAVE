import { RequestHandler } from "express";
import { z } from "zod";
import { SearchResult, ApiResponse, User, Message } from "@shared/api";

// Knowledge Management interfaces
interface KnowledgeArticle {
  id: string;
  workspace_id: string;
  title: string;
  content: string;
  summary: string;
  tags: string[];
  category: string;
  author_id: string;
  created_at: string;
  updated_at: string;
  version: number;
  status: 'draft' | 'published' | 'archived';
  views: number;
  helpful_votes: number;
  not_helpful_votes: number;
  related_articles: string[];
  attachments: {
    id: string;
    name: string;
    url: string;
    type: string;
  }[];
}

interface KnowledgeCategory {
  id: string;
  workspace_id: string;
  name: string;
  description: string;
  parent_id?: string;
  icon: string;
  color: string;
  article_count: number;
  created_at: string;
}

interface SearchFacet {
  type: 'file_type' | 'sender' | 'channel' | 'date_range' | 'message_type' | 'has_attachments' | 'category' | 'tag';
  label: string;
  options: {
    value: string;
    label: string;
    count: number;
  }[];
}

interface FacetedSearchRequest {
  query: string;
  filters: {
    file_types?: string[];
    senders?: string[];
    channels?: string[];
    date_range?: {
      start: string;
      end: string;
    };
    message_types?: ('text' | 'file' | 'image' | 'video' | 'audio')[];
    has_attachments?: boolean;
    categories?: string[];
    tags?: string[];
  };
  sort_by: 'relevance' | 'date' | 'popularity' | 'views';
  limit: number;
  offset: number;
}

interface SearchInsight {
  type: 'summary' | 'answer' | 'trend' | 'recommendation';
  title: string;
  content: string;
  confidence: number;
  sources: {
    id: string;
    type: 'message' | 'file' | 'article';
    title: string;
    url: string;
  }[];
}

// Mock databases
let knowledgeArticles: KnowledgeArticle[] = [
  {
    id: "article-1",
    workspace_id: "default",
    title: "Getting Started with Our Platform",
    content: `# Getting Started Guide

Welcome to our collaboration platform! This guide will help you get up and running quickly.

## First Steps
1. Set up your profile
2. Join your first channel
3. Send your first message
4. Customize your notifications

## Tips for Success
- Use @mentions to get someone's attention
- Create channels for different topics
- Use threads to keep conversations organized
- Pin important messages for easy reference

## Advanced Features
- Set up automated workflows
- Integrate with external tools
- Use AI search to find information quickly
- Create custom slash commands`,
    summary: "A comprehensive guide to help new users get started with the platform, covering basic setup, essential features, and advanced capabilities.",
    tags: ["getting-started", "guide", "onboarding"],
    category: "getting-started",
    author_id: "1",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    version: 1,
    status: "published",
    views: 156,
    helpful_votes: 23,
    not_helpful_votes: 2,
    related_articles: ["article-2"],
    attachments: []
  },
  {
    id: "article-2",
    workspace_id: "default",
    title: "Advanced Search Techniques",
    content: `# Advanced Search Techniques

Learn how to find exactly what you're looking for using our powerful search features.

## Basic Search
Simply type your query in the search box. Our AI will understand natural language queries.

## Search Operators
- Use quotes for exact phrases: "project update"
- Use AND/OR operators: meeting AND agenda
- Use wildcards: proj* (finds project, projects, etc.)

## Filters
- Filter by file type: type:pdf
- Filter by sender: from:@john
- Filter by date: after:2023-01-01
- Filter by channel: in:#general

## AI Features
- Ask questions in natural language
- Get summarized answers from multiple sources
- Find related content automatically`,
    summary: "Master advanced search techniques including operators, filters, and AI-powered features to find information quickly and efficiently.",
    tags: ["search", "advanced", "tips", "ai"],
    category: "features",
    author_id: "1",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    version: 1,
    status: "published",
    views: 89,
    helpful_votes: 18,
    not_helpful_votes: 1,
    related_articles: ["article-1"],
    attachments: []
  }
];

let knowledgeCategories: KnowledgeCategory[] = [
  {
    id: "getting-started",
    workspace_id: "default",
    name: "Getting Started",
    description: "Essential guides for new users",
    icon: "🚀",
    color: "#3b82f6",
    article_count: 1,
    created_at: new Date().toISOString()
  },
  {
    id: "features",
    workspace_id: "default",
    name: "Features",
    description: "Learn about platform features",
    icon: "⚡",
    color: "#10b981",
    article_count: 1,
    created_at: new Date().toISOString()
  },
  {
    id: "troubleshooting",
    workspace_id: "default",
    name: "Troubleshooting",
    description: "Common issues and solutions",
    icon: "🔧",
    color: "#f59e0b",
    article_count: 0,
    created_at: new Date().toISOString()
  }
];

// Mock search data for faceted search
const mockMessages: Message[] = [
  { id: "1", text: "Project update meeting tomorrow", author: "john@example.com", channel_id: "general", timestamp: new Date().toISOString(), thread_id: null },
  { id: "2", text: "Can someone review the design document?", author: "jane@example.com", channel_id: "design", timestamp: new Date().toISOString(), thread_id: null },
  { id: "3", text: "Q3 quarterly report is now available", author: "mike@example.com", channel_id: "announcements", timestamp: new Date().toISOString(), thread_id: null }
];

const mockFiles = [
  { id: "f1", name: "proposal.pdf", type: "pdf", author: "john@example.com", channel_id: "general", uploaded_at: new Date().toISOString() },
  { id: "f2", name: "design.sketch", type: "sketch", author: "jane@example.com", channel_id: "design", uploaded_at: new Date().toISOString() },
  { id: "f3", name: "report.xlsx", type: "xlsx", author: "mike@example.com", channel_id: "announcements", uploaded_at: new Date().toISOString() }
];

// Validation schemas
const facetedSearchSchema = z.object({
  query: z.string().min(1),
  filters: z.object({
    file_types: z.array(z.string()).optional(),
    senders: z.array(z.string()).optional(),
    channels: z.array(z.string()).optional(),
    date_range: z.object({
      start: z.string(),
      end: z.string()
    }).optional(),
    message_types: z.array(z.enum(['text', 'file', 'image', 'video', 'audio'])).optional(),
    has_attachments: z.boolean().optional(),
    categories: z.array(z.string()).optional(),
    tags: z.array(z.string()).optional()
  }).optional(),
  sort_by: z.enum(['relevance', 'date', 'popularity', 'views']).default('relevance'),
  limit: z.number().min(1).max(100).default(20),
  offset: z.number().min(0).default(0)
});

const knowledgeArticleSchema = z.object({
  title: z.string().min(1).max(200),
  content: z.string().min(1),
  summary: z.string().max(500).optional(),
  tags: z.array(z.string()).default([]),
  category: z.string(),
  status: z.enum(['draft', 'published', 'archived']).default('draft')
});

const knowledgeCategorySchema = z.object({
  name: z.string().min(1).max(100),
  description: z.string().max(500),
  parent_id: z.string().optional(),
  icon: z.string().max(10),
  color: z.string().regex(/^#[0-9A-F]{6}$/i)
});

// Enhanced AI Search Engine with faceted search
class EnhancedAISearchEngine {
  async facetedSearch(request: FacetedSearchRequest, userId: string): Promise<{
    results: SearchResult[];
    facets: SearchFacet[];
    insights: SearchInsight[];
    total: number;
    took_ms: number;
  }> {
    const startTime = Date.now();
    
    // Apply filters and search
    let filteredMessages = [...mockMessages];
    let filteredFiles = [...mockFiles];
    let filteredArticles = [...knowledgeArticles];

    // Apply text search
    if (request.query) {
      const queryLower = request.query.toLowerCase();
      filteredMessages = filteredMessages.filter(m => 
        m.text.toLowerCase().includes(queryLower)
      );
      filteredFiles = filteredFiles.filter(f => 
        f.name.toLowerCase().includes(queryLower)
      );
      filteredArticles = filteredArticles.filter(a => 
        a.title.toLowerCase().includes(queryLower) || 
        a.content.toLowerCase().includes(queryLower) ||
        a.tags.some(tag => tag.toLowerCase().includes(queryLower))
      );
    }

    // Apply filters
    if (request.filters) {
      // File type filter
      if (request.filters.file_types?.length) {
        filteredFiles = filteredFiles.filter(f => 
          request.filters.file_types!.includes(f.type)
        );
      }

      // Sender filter
      if (request.filters.senders?.length) {
        filteredMessages = filteredMessages.filter(m => 
          request.filters.senders!.includes(m.author)
        );
        filteredFiles = filteredFiles.filter(f => 
          request.filters.senders!.includes(f.author)
        );
      }

      // Channel filter
      if (request.filters.channels?.length) {
        filteredMessages = filteredMessages.filter(m => 
          request.filters.channels!.includes(m.channel_id)
        );
        filteredFiles = filteredFiles.filter(f => 
          request.filters.channels!.includes(f.channel_id)
        );
      }

      // Category filter for knowledge articles
      if (request.filters.categories?.length) {
        filteredArticles = filteredArticles.filter(a => 
          request.filters.categories!.includes(a.category)
        );
      }

      // Tag filter for knowledge articles
      if (request.filters.tags?.length) {
        filteredArticles = filteredArticles.filter(a => 
          request.filters.tags!.some(tag => a.tags.includes(tag))
        );
      }
    }

    // Convert to search results
    const messageResults: SearchResult[] = filteredMessages.map(m => ({
      id: m.id,
      type: 'message',
      title: m.text.substring(0, 100),
      content: m.text,
      author: m.author,
      channel: m.channel_id,
      timestamp: m.timestamp,
      relevance_score: 0.9,
      highlights: [m.text.substring(0, 200)]
    }));

    const fileResults: SearchResult[] = filteredFiles.map(f => ({
      id: f.id,
      type: 'file',
      title: f.name,
      content: `File: ${f.name} (${f.type})`,
      author: f.author,
      channel: f.channel_id,
      timestamp: f.uploaded_at,
      relevance_score: 0.8,
      highlights: [f.name]
    }));

    const articleResults: SearchResult[] = filteredArticles.map(a => ({
      id: a.id,
      type: 'knowledge',
      title: a.title,
      content: a.summary || a.content.substring(0, 200),
      author: a.author_id,
      channel: 'knowledge-base',
      timestamp: a.updated_at,
      relevance_score: 0.95,
      highlights: [a.title, a.summary || '']
    }));

    const allResults = [...articleResults, ...messageResults, ...fileResults];

    // Sort results
    this.sortResults(allResults, request.sort_by);

    // Apply pagination
    const paginatedResults = allResults.slice(request.offset, request.offset + request.limit);

    // Generate facets
    const facets = this.generateFacets(filteredMessages, filteredFiles, filteredArticles);

    // Generate AI insights
    const insights = await this.generateInsights(request.query, paginatedResults);

    const tookMs = Date.now() - startTime;

    return {
      results: paginatedResults,
      facets,
      insights,
      total: allResults.length,
      took_ms: tookMs
    };
  }

  private sortResults(results: SearchResult[], sortBy: string) {
    switch (sortBy) {
      case 'date':
        results.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        break;
      case 'popularity':
        results.sort((a, b) => b.relevance_score - a.relevance_score);
        break;
      case 'relevance':
      default:
        results.sort((a, b) => b.relevance_score - a.relevance_score);
        break;
    }
  }

  private generateFacets(messages: Message[], files: any[], articles: KnowledgeArticle[]): SearchFacet[] {
    return [
      {
        type: 'file_type',
        label: 'File Type',
        options: this.aggregateFileTypes(files)
      },
      {
        type: 'sender',
        label: 'Sender',
        options: this.aggregateSenders([...messages, ...files])
      },
      {
        type: 'channel',
        label: 'Channel',
        options: this.aggregateChannels([...messages, ...files])
      },
      {
        type: 'category',
        label: 'Category',
        options: this.aggregateCategories(articles)
      },
      {
        type: 'tag',
        label: 'Tags',
        options: this.aggregateTags(articles)
      }
    ];
  }

  private aggregateFileTypes(files: any[]) {
    const counts = files.reduce((acc, file) => {
      acc[file.type] = (acc[file.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(counts).map(([type, count]) => ({
      value: type,
      label: type.toUpperCase(),
      count
    }));
  }

  private aggregateSenders(items: any[]) {
    const counts = items.reduce((acc, item) => {
      const author = item.author || item.author_id;
      acc[author] = (acc[author] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(counts).map(([author, count]) => ({
      value: author,
      label: author.split('@')[0] || author,
      count
    }));
  }

  private aggregateChannels(items: any[]) {
    const counts = items.reduce((acc, item) => {
      acc[item.channel_id] = (acc[item.channel_id] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(counts).map(([channel, count]) => ({
      value: channel,
      label: `#${channel}`,
      count
    }));
  }

  private aggregateCategories(articles: KnowledgeArticle[]) {
    const counts = articles.reduce((acc, article) => {
      acc[article.category] = (acc[article.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(counts).map(([category, count]) => ({
      value: category,
      label: category.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase()),
      count
    }));
  }

  private aggregateTags(articles: KnowledgeArticle[]) {
    const counts = articles.reduce((acc, article) => {
      article.tags.forEach(tag => {
        acc[tag] = (acc[tag] || 0) + 1;
      });
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(counts).map(([tag, count]) => ({
      value: tag,
      label: tag,
      count
    }));
  }

  private async generateInsights(query: string, results: SearchResult[]): Promise<SearchInsight[]> {
    const insights: SearchInsight[] = [];

    // Generate summary insight
    if (results.length > 0) {
      insights.push({
        type: 'summary',
        title: 'Search Summary',
        content: `Found ${results.length} relevant results. The most relevant content includes ${results[0]?.type}s and covers topics related to "${query}".`,
        confidence: 0.85,
        sources: results.slice(0, 3).map(r => ({
          id: r.id,
          type: r.type as any,
          title: r.title,
          url: `/${r.type}/${r.id}`
        }))
      });
    }

    // Generate answer insight for questions
    if (query.includes('?') || query.startsWith('how') || query.startsWith('what') || query.startsWith('why')) {
      insights.push({
        type: 'answer',
        title: 'AI Answer',
        content: this.generateAIAnswer(query, results),
        confidence: 0.78,
        sources: results.slice(0, 2).map(r => ({
          id: r.id,
          type: r.type as any,
          title: r.title,
          url: `/${r.type}/${r.id}`
        }))
      });
    }

    return insights;
  }

  private generateAIAnswer(query: string, results: SearchResult[]): string {
    if (query.toLowerCase().includes('how to')) {
      return "Based on the available documentation and discussions, here are the key steps to accomplish what you're looking for. Check the linked resources for detailed instructions.";
    } else if (query.toLowerCase().includes('what is')) {
      return "Based on the search results, this appears to be a feature/concept that is discussed in the linked content. The documentation provides comprehensive information about this topic.";
    } else {
      return "The search results contain relevant information that should help answer your question. Review the highlighted content in the results below for more details.";
    }
  }
}

const searchEngine = new EnhancedAISearchEngine();

// API endpoints
export const performFacetedSearch: RequestHandler = async (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = facetedSearchSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid search request",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const searchResult = await searchEngine.facetedSearch(validation.data, user.id);

    res.json({
      success: true,
      data: searchResult
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Search failed"
    } as ApiResponse);
  }
};

export const getSearchFacets: RequestHandler = (req, res) => {
  try {
    // Get all available facet options
    const facets = [
      {
        type: 'file_type',
        label: 'File Type',
        options: [
          { value: 'pdf', label: 'PDF', count: 12 },
          { value: 'docx', label: 'Word Document', count: 8 },
          { value: 'xlsx', label: 'Excel', count: 5 },
          { value: 'jpg', label: 'Image', count: 23 },
          { value: 'mp4', label: 'Video', count: 3 }
        ]
      },
      {
        type: 'channel',
        label: 'Channel',
        options: [
          { value: 'general', label: '#general', count: 45 },
          { value: 'design', label: '#design', count: 28 },
          { value: 'engineering', label: '#engineering', count: 67 },
          { value: 'marketing', label: '#marketing', count: 19 }
        ]
      },
      {
        type: 'message_type',
        label: 'Content Type',
        options: [
          { value: 'text', label: 'Messages', count: 234 },
          { value: 'file', label: 'Files', count: 48 },
          { value: 'knowledge', label: 'Knowledge Base', count: knowledgeArticles.length }
        ]
      }
    ];

    res.json({
      success: true,
      data: facets
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get search facets"
    } as ApiResponse);
  }
};

// Knowledge Base endpoints
export const getKnowledgeArticles: RequestHandler = (req, res) => {
  try {
    const { category, tag, status = 'published' } = req.query;
    
    let filteredArticles = knowledgeArticles.filter(a => a.status === status);
    
    if (category) {
      filteredArticles = filteredArticles.filter(a => a.category === category);
    }
    
    if (tag) {
      filteredArticles = filteredArticles.filter(a => a.tags.includes(tag as string));
    }

    res.json({
      success: true,
      data: filteredArticles
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get knowledge articles"
    } as ApiResponse);
  }
};

export const getKnowledgeArticle: RequestHandler = (req, res) => {
  try {
    const { articleId } = req.params;
    
    const article = knowledgeArticles.find(a => a.id === articleId);
    if (!article) {
      return res.status(404).json({
        success: false,
        error: "Article not found"
      } as ApiResponse);
    }

    // Increment view count
    article.views++;

    res.json({
      success: true,
      data: article
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get article"
    } as ApiResponse);
  }
};

export const createKnowledgeArticle: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = knowledgeArticleSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid article data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const article: KnowledgeArticle = {
      id: Date.now().toString(),
      workspace_id: "default", // In production, get from context
      ...validation.data,
      author_id: user.id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      version: 1,
      views: 0,
      helpful_votes: 0,
      not_helpful_votes: 0,
      related_articles: [],
      attachments: []
    };

    knowledgeArticles.push(article);

    res.status(201).json({
      success: true,
      data: article
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create article"
    } as ApiResponse);
  }
};

export const getKnowledgeCategories: RequestHandler = (req, res) => {
  try {
    res.json({
      success: true,
      data: knowledgeCategories
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get categories"
    } as ApiResponse);
  }
};

export const createKnowledgeCategory: RequestHandler = (req, res) => {
  try {
    const validation = knowledgeCategorySchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid category data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const category: KnowledgeCategory = {
      id: Date.now().toString(),
      workspace_id: "default",
      ...validation.data,
      article_count: 0,
      created_at: new Date().toISOString()
    };

    knowledgeCategories.push(category);

    res.status(201).json({
      success: true,
      data: category
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create category"
    } as ApiResponse);
  }
};

export const voteOnArticle: RequestHandler = (req, res) => {
  try {
    const { articleId } = req.params;
    const { helpful } = req.body;
    
    const article = knowledgeArticles.find(a => a.id === articleId);
    if (!article) {
      return res.status(404).json({
        success: false,
        error: "Article not found"
      } as ApiResponse);
    }

    if (helpful) {
      article.helpful_votes++;
    } else {
      article.not_helpful_votes++;
    }

    res.json({
      success: true,
      data: {
        helpful_votes: article.helpful_votes,
        not_helpful_votes: article.not_helpful_votes
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to vote on article"
    } as ApiResponse);
  }
};
