import { Router } from 'express';
import { z } from 'zod';

const router = Router();

// Mock database for notes
interface Note {
  id: string;
  channel_id: string;
  user_id: string;
  content: string;
  created_at: string;
  updated_at: string;
  version: number;
}

const mockNotes: Note[] = [
  {
    id: 'note-1',
    channel_id: 'all-new-workspace',
    user_id: 'user-123',
    content: 'Meeting notes for project kickoff:\n\n- Define project scope\n- Assign team roles\n- Set initial timeline\n\nNext steps:\n- Create wireframes\n- Schedule design review',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:30:00Z',
    version: 1
  }
];

// Validation schemas
const CreateNoteSchema = z.object({
  channel_id: z.string(),
  content: z.string()
});

const UpdateNoteSchema = z.object({
  content: z.string()
});

// Get notes for a channel
router.get('/:channelId', (req, res) => {
  try {
    const { channelId } = req.params;
    
    const note = mockNotes.find(n => n.channel_id === channelId);
    
    res.json({
      success: true,
      data: note || { content: '', channel_id: channelId }
    });
  } catch (error) {
    console.error('Error fetching notes:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch notes'
    });
  }
});

// Create or update notes for a channel
router.post('/', (req, res) => {
  try {
    const validation = CreateNoteSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: 'Invalid request data',
        details: validation.error.errors
      });
    }

    const { channel_id, content } = validation.data;
    const userId = req.user?.id || 'user-123';

    // Find existing note for this channel
    const existingNoteIndex = mockNotes.findIndex(n => n.channel_id === channel_id);
    
    if (existingNoteIndex !== -1) {
      // Update existing note
      const existingNote = mockNotes[existingNoteIndex];
      const updatedNote: Note = {
        ...existingNote,
        content,
        updated_at: new Date().toISOString(),
        version: existingNote.version + 1
      };
      
      mockNotes[existingNoteIndex] = updatedNote;
      
      res.json({
        success: true,
        data: updatedNote
      });
    } else {
      // Create new note
      const newNote: Note = {
        id: `note-${Date.now()}`,
        channel_id,
        user_id: userId,
        content,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        version: 1
      };
      
      mockNotes.push(newNote);
      
      res.json({
        success: true,
        data: newNote
      });
    }
  } catch (error) {
    console.error('Error creating/updating note:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to save note'
    });
  }
});

// Get note history/versions
router.get('/:channelId/history', (req, res) => {
  try {
    const { channelId } = req.params;
    
    // In a real implementation, you'd store version history
    const noteVersions = mockNotes
      .filter(n => n.channel_id === channelId)
      .sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime());
    
    res.json({
      success: true,
      data: noteVersions
    });
  } catch (error) {
    console.error('Error fetching note history:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch note history'
    });
  }
});

// Delete note
router.delete('/:channelId', (req, res) => {
  try {
    const { channelId } = req.params;
    
    const noteIndex = mockNotes.findIndex(n => n.channel_id === channelId);
    if (noteIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Note not found'
      });
    }
    
    mockNotes.splice(noteIndex, 1);
    
    res.json({
      success: true,
      message: 'Note deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting note:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete note'
    });
  }
});

// Search notes across all channels
router.get('/search/:query', (req, res) => {
  try {
    const { query } = req.params;
    const searchTerm = query.toLowerCase();
    
    const matchingNotes = mockNotes.filter(note => 
      note.content.toLowerCase().includes(searchTerm)
    );
    
    res.json({
      success: true,
      data: matchingNotes,
      total: matchingNotes.length
    });
  } catch (error) {
    console.error('Error searching notes:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to search notes'
    });
  }
});

export default router;
