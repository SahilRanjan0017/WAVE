import { RequestHandler } from "express";
import { z } from "zod";
import { ApiResponse, User } from "@shared/api";

interface WorkflowTrigger {
  type: 'message_posted' | 'user_joined' | 'reaction_added' | 'file_uploaded' | 'schedule' | 'webhook';
  conditions: {
    channel_id?: string;
    keywords?: string[];
    user_id?: string;
    file_type?: string;
    schedule?: string; // cron expression
  };
}

interface WorkflowAction {
  type: 'send_message' | 'create_reminder' | 'assign_task' | 'send_email' | 'webhook_call' | 'move_to_channel';
  parameters: {
    target?: string; // channel_id, user_id, or URL
    message?: string;
    template?: string;
    delay?: number; // seconds
    data?: any;
  };
}

interface Workflow {
  id: string;
  name: string;
  description: string;
  workspace_id: string;
  created_by: string;
  is_active: boolean;
  trigger: WorkflowTrigger;
  actions: WorkflowAction[];
  created_at: string;
  updated_at: string;
  last_run?: string;
  run_count: number;
}

interface WorkflowRun {
  id: string;
  workflow_id: string;
  trigger_data: any;
  status: 'running' | 'completed' | 'failed';
  started_at: string;
  completed_at?: string;
  error?: string;
  actions_executed: number;
}

// Mock database
let workflows: Workflow[] = [];
let workflowRuns: WorkflowRun[] = [];

// Predefined workflow templates
const workflowTemplates = [
  {
    id: 'welcome_new_user',
    name: 'Welcome New Team Member',
    description: 'Automatically welcome new users and provide onboarding information',
    trigger: {
      type: 'user_joined' as const,
      conditions: {}
    },
    actions: [
      {
        type: 'send_message' as const,
        parameters: {
          target: 'general',
          template: 'welcome_user',
          message: 'Welcome {{user.name}} to the team! 🎉'
        }
      },
      {
        type: 'send_message' as const,
        parameters: {
          target: '{{user.id}}',
          message: 'Hi {{user.name}}! Welcome to our workspace. Here are some resources to get you started...'
        }
      }
    ]
  },
  {
    id: 'daily_standup_reminder',
    name: 'Daily Standup Reminder',
    description: 'Send daily standup reminders to the team',
    trigger: {
      type: 'schedule' as const,
      conditions: {
        schedule: '0 9 * * 1-5' // 9 AM on weekdays
      }
    },
    actions: [
      {
        type: 'send_message' as const,
        parameters: {
          target: 'general',
          message: '📅 Good morning team! Time for our daily standup. Please share:\n• What did you work on yesterday?\n• What are you working on today?\n• Any blockers?'
        }
      }
    ]
  },
  {
    id: 'file_backup',
    name: 'Important File Backup',
    description: 'Automatically backup important files when uploaded',
    trigger: {
      type: 'file_uploaded' as const,
      conditions: {
        file_type: 'document'
      }
    },
    actions: [
      {
        type: 'webhook_call' as const,
        parameters: {
          target: 'https://api.backup-service.com/upload',
          data: {
            file_url: '{{file.url}}',
            workspace: '{{workspace.name}}'
          }
        }
      }
    ]
  }
];

// Validation schemas
const createWorkflowSchema = z.object({
  name: z.string().min(1).max(100),
  description: z.string().max(500),
  workspace_id: z.string(),
  trigger: z.object({
    type: z.enum(['message_posted', 'user_joined', 'reaction_added', 'file_uploaded', 'schedule', 'webhook']),
    conditions: z.object({
      channel_id: z.string().optional(),
      keywords: z.array(z.string()).optional(),
      user_id: z.string().optional(),
      file_type: z.string().optional(),
      schedule: z.string().optional()
    })
  }),
  actions: z.array(z.object({
    type: z.enum(['send_message', 'create_reminder', 'assign_task', 'send_email', 'webhook_call', 'move_to_channel']),
    parameters: z.object({
      target: z.string().optional(),
      message: z.string().optional(),
      template: z.string().optional(),
      delay: z.number().optional(),
      data: z.any().optional()
    })
  }))
});

// Workflow execution engine
class WorkflowEngine {
  async executeWorkflow(workflow: Workflow, triggerData: any): Promise<WorkflowRun> {
    const run: WorkflowRun = {
      id: Date.now().toString(),
      workflow_id: workflow.id,
      trigger_data: triggerData,
      status: 'running',
      started_at: new Date().toISOString(),
      actions_executed: 0
    };

    workflowRuns.push(run);

    try {
      for (const action of workflow.actions) {
        await this.executeAction(action, triggerData, run);
        run.actions_executed++;
      }

      run.status = 'completed';
      run.completed_at = new Date().toISOString();

      // Update workflow stats
      const workflowIndex = workflows.findIndex(w => w.id === workflow.id);
      if (workflowIndex !== -1) {
        workflows[workflowIndex].last_run = new Date().toISOString();
        workflows[workflowIndex].run_count++;
      }

    } catch (error) {
      run.status = 'failed';
      run.error = error instanceof Error ? error.message : 'Unknown error';
      run.completed_at = new Date().toISOString();
    }

    return run;
  }

  private async executeAction(action: WorkflowAction, triggerData: any, run: WorkflowRun): Promise<void> {
    const processedParams = this.processTemplate(action.parameters, triggerData);

    switch (action.type) {
      case 'send_message':
        await this.sendMessage(processedParams);
        break;
      case 'create_reminder':
        await this.createReminder(processedParams);
        break;
      case 'webhook_call':
        await this.callWebhook(processedParams);
        break;
      case 'send_email':
        await this.sendEmail(processedParams);
        break;
      default:
        console.log(`Action type ${action.type} not implemented`);
    }

    // Add delay if specified
    if (action.parameters.delay) {
      await new Promise(resolve => setTimeout(resolve, action.parameters.delay! * 1000));
    }
  }

  private processTemplate(parameters: any, data: any): any {
    const processed = { ...parameters };
    
    for (const [key, value] of Object.entries(processed)) {
      if (typeof value === 'string') {
        // Simple template processing
        processed[key] = value.replace(/\{\{([^}]+)\}\}/g, (match, path) => {
          const keys = path.split('.');
          let result = data;
          for (const k of keys) {
            result = result?.[k];
          }
          return result || match;
        });
      }
    }

    return processed;
  }

  private async sendMessage(params: any): Promise<void> {
    // Simulate sending message through the messaging system
    console.log(`Sending message to ${params.target}: ${params.message}`);
    // In real implementation, call the message API
  }

  private async createReminder(params: any): Promise<void> {
    console.log(`Creating reminder: ${params.message}`);
    // In real implementation, integrate with reminder system
  }

  private async callWebhook(params: any): Promise<void> {
    console.log(`Calling webhook: ${params.target}`);
    // In real implementation, make HTTP request to webhook URL
  }

  private async sendEmail(params: any): Promise<void> {
    console.log(`Sending email to ${params.target}: ${params.message}`);
    // In real implementation, integrate with email service
  }
}

const workflowEngine = new WorkflowEngine();

export const getWorkflows: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspace_id } = req.query;

    let userWorkflows = workflows;
    
    if (workspace_id) {
      userWorkflows = workflows.filter(w => w.workspace_id === workspace_id);
    }

    res.json({
      success: true,
      data: userWorkflows
    } as ApiResponse<Workflow[]>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const createWorkflow: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = createWorkflowSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid workflow data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const workflowData = validation.data;
    
    const workflow: Workflow = {
      id: Date.now().toString(),
      name: workflowData.name,
      description: workflowData.description,
      workspace_id: workflowData.workspace_id,
      created_by: user.id,
      is_active: true,
      trigger: workflowData.trigger,
      actions: workflowData.actions,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      run_count: 0
    };

    workflows.push(workflow);

    res.status(201).json({
      success: true,
      data: workflow
    } as ApiResponse<Workflow>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const updateWorkflow: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workflowId } = req.params;
    
    const workflowIndex = workflows.findIndex(w => w.id === workflowId && w.created_by === user.id);
    if (workflowIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Workflow not found"
      } as ApiResponse);
    }

    const updates = req.body;
    workflows[workflowIndex] = {
      ...workflows[workflowIndex],
      ...updates,
      updated_at: new Date().toISOString()
    };

    res.json({
      success: true,
      data: workflows[workflowIndex]
    } as ApiResponse<Workflow>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const deleteWorkflow: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workflowId } = req.params;
    
    const workflowIndex = workflows.findIndex(w => w.id === workflowId && w.created_by === user.id);
    if (workflowIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Workflow not found"
      } as ApiResponse);
    }

    workflows.splice(workflowIndex, 1);

    res.json({
      success: true,
      message: "Workflow deleted successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const executeWorkflow: RequestHandler = async (req, res) => {
  try {
    const { workflowId } = req.params;
    const { trigger_data } = req.body;
    
    const workflow = workflows.find(w => w.id === workflowId && w.is_active);
    if (!workflow) {
      return res.status(404).json({
        success: false,
        error: "Workflow not found or inactive"
      } as ApiResponse);
    }

    const run = await workflowEngine.executeWorkflow(workflow, trigger_data);

    res.json({
      success: true,
      data: run
    } as ApiResponse<WorkflowRun>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Workflow execution failed"
    } as ApiResponse);
  }
};

export const getWorkflowRuns: RequestHandler = (req, res) => {
  try {
    const { workflowId } = req.params;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;

    let runs = workflowRuns.filter(r => r.workflow_id === workflowId);
    runs.sort((a, b) => new Date(b.started_at).getTime() - new Date(a.started_at).getTime());

    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedRuns = runs.slice(startIndex, endIndex);

    res.json({
      success: true,
      data: {
        data: paginatedRuns,
        page,
        limit,
        total: runs.length,
        has_more: endIndex < runs.length
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getWorkflowTemplates: RequestHandler = (req, res) => {
  try {
    res.json({
      success: true,
      data: workflowTemplates
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const toggleWorkflow: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workflowId } = req.params;
    
    const workflowIndex = workflows.findIndex(w => w.id === workflowId && w.created_by === user.id);
    if (workflowIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Workflow not found"
      } as ApiResponse);
    }

    workflows[workflowIndex].is_active = !workflows[workflowIndex].is_active;
    workflows[workflowIndex].updated_at = new Date().toISOString();

    res.json({
      success: true,
      data: workflows[workflowIndex]
    } as ApiResponse<Workflow>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

// Function to trigger workflows based on events
export const triggerWorkflows = async (eventType: string, data: any) => {
  const applicableWorkflows = workflows.filter(w => 
    w.is_active && w.trigger.type === eventType
  );

  for (const workflow of applicableWorkflows) {
    // Check if conditions match
    if (checkTriggerConditions(workflow.trigger, data)) {
      await workflowEngine.executeWorkflow(workflow, data);
    }
  }
};

function checkTriggerConditions(trigger: WorkflowTrigger, data: any): boolean {
  const { conditions } = trigger;
  
  if (conditions.channel_id && data.channel_id !== conditions.channel_id) {
    return false;
  }
  
  if (conditions.user_id && data.user_id !== conditions.user_id) {
    return false;
  }
  
  if (conditions.keywords && conditions.keywords.length > 0) {
    const content = (data.content || '').toLowerCase();
    const hasKeyword = conditions.keywords.some(keyword => 
      content.includes(keyword.toLowerCase())
    );
    if (!hasKeyword) return false;
  }
  
  if (conditions.file_type && data.file_type !== conditions.file_type) {
    return false;
  }
  
  return true;
}
