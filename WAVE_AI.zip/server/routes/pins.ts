import { RequestHandler } from "express";
import { z } from "zod";
import { PinMessageRequest, Message, ApiResponse, User } from "@shared/api";

// Mock database for pinned messages
let pinnedMessages: Map<string, string[]> = new Map(); // channelId -> messageIds[]

// Validation schemas
const pinMessageSchema = z.object({
  message_id: z.string(),
  channel_id: z.string()
});

export const pinMessage: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = pinMessageSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid input",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const { message_id, channel_id } = validation.data as PinMessageRequest;

    // Get current pinned messages for channel
    const channelPins = pinnedMessages.get(channel_id) || [];
    
    // Check if message is already pinned
    if (channelPins.includes(message_id)) {
      return res.status(400).json({
        success: false,
        error: "Message is already pinned"
      } as ApiResponse);
    }

    // Pin limit check (Slack has a limit of 100 pinned items per channel)
    if (channelPins.length >= 100) {
      return res.status(400).json({
        success: false,
        error: "Channel has reached the maximum of 100 pinned items"
      } as ApiResponse);
    }

    // Add to pinned messages
    channelPins.unshift(message_id); // Add to beginning
    pinnedMessages.set(channel_id, channelPins);

    // In a real app, also update the message record to mark it as pinned

    // Broadcast pin event via WebSocket
    const wsManager = (req as any).app?.wsManager;
    if (wsManager) {
      wsManager.broadcastToChannel(channel_id, {
        type: 'message_pinned',
        data: {
          message_id,
          pinned_by: user,
          channel_id
        }
      });
    }

    res.json({
      success: true,
      message: "Message pinned successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const unpinMessage: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { messageId } = req.params;
    const { channel_id } = req.body;

    const channelPins = pinnedMessages.get(channel_id) || [];
    const messageIndex = channelPins.indexOf(messageId);

    if (messageIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Message is not pinned"
      } as ApiResponse);
    }

    // Remove from pinned messages
    channelPins.splice(messageIndex, 1);
    pinnedMessages.set(channel_id, channelPins);

    // Broadcast unpin event via WebSocket
    const wsManager = (req as any).app?.wsManager;
    if (wsManager) {
      wsManager.broadcastToChannel(channel_id, {
        type: 'message_unpinned',
        data: {
          message_id: messageId,
          unpinned_by: user,
          channel_id
        }
      });
    }

    res.json({
      success: true,
      message: "Message unpinned successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getPinnedMessages: RequestHandler = (req, res) => {
  try {
    const { channelId } = req.params;
    
    const channelPins = pinnedMessages.get(channelId) || [];
    
    // In a real app, fetch the actual message objects from database
    // For now, return mock message data
    const mockPinnedMessages = channelPins.map(messageId => ({
      id: messageId,
      sender_id: "1",
      channel_id: channelId,
      content: `This is pinned message ${messageId}`,
      type: 'text' as const,
      is_edited: false,
      is_pinned: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      pinned_at: new Date().toISOString(),
      pinned_by: {
        id: "1",
        username: "admin",
        full_name: "Admin User",
        email: "admin@example.com",
        status: 'online' as const,
        created_at: new Date().toISOString()
      },
      sender: {
        id: "1",
        username: "user",
        full_name: "User Name",
        email: "user@example.com",
        status: 'online' as const,
        created_at: new Date().toISOString()
      },
      reactions: []
    }));

    res.json({
      success: true,
      data: mockPinnedMessages
    } as ApiResponse<Message[]>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getPinnedCount: RequestHandler = (req, res) => {
  try {
    const { channelId } = req.params;
    
    const channelPins = pinnedMessages.get(channelId) || [];
    
    res.json({
      success: true,
      data: {
        channel_id: channelId,
        pinned_count: channelPins.length,
        max_pins: 100
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getUserBookmarks: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    
    // Mock bookmarked items for the user
    const bookmarks = [
      {
        id: "1",
        type: "message",
        title: "Important project update",
        content: "The new feature launch is scheduled for next week...",
        channel_name: "general",
        created_at: new Date(Date.now() - 86400000).toISOString(),
        bookmarked_at: new Date(Date.now() - 3600000).toISOString()
      },
      {
        id: "2",
        type: "file",
        title: "Design Mockups.figma",
        content: "Latest UI/UX designs for the dashboard",
        channel_name: "design-team",
        file_url: "/api/files/mockup.figma",
        created_at: new Date(Date.now() - 172800000).toISOString(),
        bookmarked_at: new Date(Date.now() - 7200000).toISOString()
      }
    ];

    res.json({
      success: true,
      data: bookmarks
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const addBookmark: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { item_type, item_id, channel_id } = req.body;

    // In a real app, save bookmark to database
    const bookmark = {
      id: Date.now().toString(),
      user_id: user.id,
      item_type,
      item_id,
      channel_id,
      created_at: new Date().toISOString()
    };

    res.status(201).json({
      success: true,
      data: bookmark,
      message: "Item bookmarked successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const removeBookmark: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { bookmarkId } = req.params;

    // In a real app, remove bookmark from database
    res.json({
      success: true,
      message: "Bookmark removed successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};
