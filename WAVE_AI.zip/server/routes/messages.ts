import { RequestHandler } from "express";
import { z } from "zod";
import { Message, DirectMessage, SendMessageRequest, ApiResponse, PaginatedResponse, User } from "@shared/api";

// Mock database
let messages: Message[] = [
  {
    id: "1",
    sender_id: "1",
    channel_id: "general",
    content: "Welcome to the workspace!",
    type: "text",
    is_edited: false,
    created_at: new Date(Date.now() - 3600000).toISOString(),
    updated_at: new Date(Date.now() - 3600000).toISOString(),
    sender: {
      id: "1",
      email: "sahil@example.com",
      username: "sahil",
      full_name: "Sahil Ranjan",
      avatar_url: "",
      status: "online",
      created_at: new Date().toISOString()
    }
  }
];

let directMessages: DirectMessage[] = [];

// Validation schemas
const sendMessageSchema = z.object({
  content: z.string().min(1),
  channel_id: z.string().optional(),
  receiver_id: z.string().optional(),
  type: z.enum(['text', 'file', 'image', 'audio', 'video']).default('text'),
  file_url: z.string().optional()
});

// Helper to broadcast messages (in production, use WebSockets or Server-Sent Events)
const broadcastMessage = (message: Message | DirectMessage) => {
  // TODO: Implement real-time broadcasting
  console.log('Broadcasting message:', message.id);
};

export const sendMessage: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = sendMessageSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid input",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const data = validation.data as SendMessageRequest;

    // Validate that either channel_id or receiver_id is provided
    if (!data.channel_id && !data.receiver_id) {
      return res.status(400).json({
        success: false,
        error: "Either channel_id or receiver_id must be provided"
      } as ApiResponse);
    }

    if (data.channel_id) {
      // Channel message
      const message: Message = {
        id: Date.now().toString(),
        sender_id: user.id,
        channel_id: data.channel_id,
        content: data.content,
        type: data.type || 'text',
        file_url: data.file_url,
        is_edited: false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        sender: user,
        reactions: []
      };

      messages.push(message);
      broadcastMessage(message);

      res.status(201).json({
        success: true,
        data: message
      } as ApiResponse<Message>);
    } else {
      // Direct message
      const directMessage: DirectMessage = {
        id: Date.now().toString(),
        sender_id: user.id,
        receiver_id: data.receiver_id!,
        content: data.content,
        type: data.type || 'text',
        file_url: data.file_url,
        is_edited: false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        sender: user
      };

      directMessages.push(directMessage);
      broadcastMessage(directMessage);

      res.status(201).json({
        success: true,
        data: directMessage
      } as ApiResponse<DirectMessage>);
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getChannelMessages: RequestHandler = (req, res) => {
  try {
    const { channelId } = req.params;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 50;

    const channelMessages = messages
      .filter(msg => msg.channel_id === channelId)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedMessages = channelMessages.slice(startIndex, endIndex);

    res.json({
      success: true,
      data: {
        data: paginatedMessages.reverse(), // Show oldest first
        page,
        limit,
        total: channelMessages.length,
        has_more: endIndex < channelMessages.length
      }
    } as ApiResponse<PaginatedResponse<Message>>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getDirectMessages: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { userId } = req.params;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 50;

    const userDirectMessages = directMessages
      .filter(msg => 
        (msg.sender_id === user.id && msg.receiver_id === userId) ||
        (msg.sender_id === userId && msg.receiver_id === user.id)
      )
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedMessages = userDirectMessages.slice(startIndex, endIndex);

    res.json({
      success: true,
      data: {
        data: paginatedMessages.reverse(), // Show oldest first
        page,
        limit,
        total: userDirectMessages.length,
        has_more: endIndex < userDirectMessages.length
      }
    } as ApiResponse<PaginatedResponse<DirectMessage>>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const editMessage: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { messageId } = req.params;
    const { content } = req.body;

    if (!content || content.trim().length === 0) {
      return res.status(400).json({
        success: false,
        error: "Content is required"
      } as ApiResponse);
    }

    // Find message in channel messages
    const messageIndex = messages.findIndex(msg => msg.id === messageId && msg.sender_id === user.id);
    if (messageIndex !== -1) {
      messages[messageIndex].content = content;
      messages[messageIndex].is_edited = true;
      messages[messageIndex].updated_at = new Date().toISOString();

      return res.json({
        success: true,
        data: messages[messageIndex]
      } as ApiResponse<Message>);
    }

    // Find message in direct messages
    const dmIndex = directMessages.findIndex(msg => msg.id === messageId && msg.sender_id === user.id);
    if (dmIndex !== -1) {
      directMessages[dmIndex].content = content;
      directMessages[dmIndex].is_edited = true;
      directMessages[dmIndex].updated_at = new Date().toISOString();

      return res.json({
        success: true,
        data: directMessages[dmIndex]
      } as ApiResponse<DirectMessage>);
    }

    res.status(404).json({
      success: false,
      error: "Message not found or you don't have permission to edit it"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const deleteMessage: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { messageId } = req.params;

    // Remove from channel messages
    const messageIndex = messages.findIndex(msg => msg.id === messageId && msg.sender_id === user.id);
    if (messageIndex !== -1) {
      messages.splice(messageIndex, 1);
      return res.json({
        success: true,
        message: "Message deleted successfully"
      } as ApiResponse);
    }

    // Remove from direct messages
    const dmIndex = directMessages.findIndex(msg => msg.id === messageId && msg.sender_id === user.id);
    if (dmIndex !== -1) {
      directMessages.splice(dmIndex, 1);
      return res.json({
        success: true,
        message: "Message deleted successfully"
      } as ApiResponse);
    }

    res.status(404).json({
      success: false,
      error: "Message not found or you don't have permission to delete it"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};
