import { Router } from 'express';
import { z } from 'zod';

const router = Router();

// Mock database for whiteboards
interface Whiteboard {
  id: string;
  name: string;
  channel_id: string;
  workspace_id: string;
  user_id: string;
  content: any; // Canvas data (JSON)
  thumbnail_url?: string;
  created_at: string;
  updated_at: string;
  collaborators: string[];
  is_public: boolean;
  tags: string[];
}

interface WhiteboardVersion {
  id: string;
  whiteboard_id: string;
  content: any;
  created_at: string;
  user_id: string;
  version_number: number;
}

const mockWhiteboards: Whiteboard[] = [
  {
    id: 'whiteboard-1',
    name: 'Team Brainstorm Session',
    channel_id: 'all-new-workspace',
    workspace_id: 'workspace-1',
    user_id: 'user-123',
    content: {
      objects: [],
      background: '#ffffff',
      width: 1200,
      height: 800
    },
    thumbnail_url: '/thumbnails/whiteboard-1.png',
    created_at: '2024-01-15T09:00:00Z',
    updated_at: '2024-01-15T09:30:00Z',
    collaborators: ['user-123', 'user-456'],
    is_public: true,
    tags: ['brainstorm', 'planning']
  }
];

const mockVersions: WhiteboardVersion[] = [];

// Validation schemas
const CreateWhiteboardSchema = z.object({
  name: z.string().min(1).max(100),
  channel_id: z.string().optional(),
  content: z.any().optional(),
  is_public: z.boolean().default(true),
  tags: z.array(z.string()).default([])
});

const UpdateWhiteboardSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  content: z.any().optional(),
  is_public: z.boolean().optional(),
  tags: z.array(z.string()).optional()
});

const SaveSnapshotSchema = z.object({
  content: z.any(),
  save_as_image: z.boolean().default(false)
});

// Get all whiteboards for workspace
router.get('/', (req, res) => {
  try {
    const { channel_id, tags, search } = req.query;
    
    let filteredWhiteboards = mockWhiteboards;
    
    if (channel_id) {
      filteredWhiteboards = filteredWhiteboards.filter(w => w.channel_id === channel_id);
    }
    
    if (tags && typeof tags === 'string') {
      const tagList = tags.split(',');
      filteredWhiteboards = filteredWhiteboards.filter(w => 
        tagList.some(tag => w.tags.includes(tag))
      );
    }
    
    if (search && typeof search === 'string') {
      const searchTerm = search.toLowerCase();
      filteredWhiteboards = filteredWhiteboards.filter(w => 
        w.name.toLowerCase().includes(searchTerm)
      );
    }
    
    res.json({
      success: true,
      data: filteredWhiteboards,
      total: filteredWhiteboards.length
    });
  } catch (error) {
    console.error('Error fetching whiteboards:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch whiteboards'
    });
  }
});

// Get whiteboards for specific channel
router.get('/channel/:channelId', (req, res) => {
  try {
    const { channelId } = req.params;
    
    const channelWhiteboards = mockWhiteboards.filter(w => w.channel_id === channelId);
    
    res.json({
      success: true,
      data: channelWhiteboards,
      total: channelWhiteboards.length
    });
  } catch (error) {
    console.error('Error fetching channel whiteboards:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch channel whiteboards'
    });
  }
});

// Get specific whiteboard
router.get('/:id', (req, res) => {
  try {
    const { id } = req.params;
    
    const whiteboard = mockWhiteboards.find(w => w.id === id);
    if (!whiteboard) {
      return res.status(404).json({
        success: false,
        error: 'Whiteboard not found'
      });
    }
    
    res.json({
      success: true,
      data: whiteboard
    });
  } catch (error) {
    console.error('Error fetching whiteboard:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch whiteboard'
    });
  }
});

// Create new whiteboard
router.post('/', (req, res) => {
  try {
    const validation = CreateWhiteboardSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: 'Invalid request data',
        details: validation.error.errors
      });
    }

    const { name, channel_id, content, is_public, tags } = validation.data;
    const userId = req.user?.id || 'user-123';

    const newWhiteboard: Whiteboard = {
      id: `whiteboard-${Date.now()}`,
      name,
      channel_id: channel_id || '',
      workspace_id: 'workspace-1',
      user_id: userId,
      content: content || {
        objects: [],
        background: '#ffffff',
        width: 1200,
        height: 800
      },
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      collaborators: [userId],
      is_public,
      tags
    };

    mockWhiteboards.push(newWhiteboard);

    res.json({
      success: true,
      data: newWhiteboard
    });
  } catch (error) {
    console.error('Error creating whiteboard:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create whiteboard'
    });
  }
});

// Update whiteboard
router.put('/:id', (req, res) => {
  try {
    const { id } = req.params;
    const validation = UpdateWhiteboardSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: 'Invalid request data',
        details: validation.error.errors
      });
    }

    const whiteboardIndex = mockWhiteboards.findIndex(w => w.id === id);
    if (whiteboardIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Whiteboard not found'
      });
    }

    const updateData = validation.data;
    const existingWhiteboard = mockWhiteboards[whiteboardIndex];
    
    // Create version if content changed
    if (updateData.content) {
      const newVersion: WhiteboardVersion = {
        id: `version-${Date.now()}`,
        whiteboard_id: id,
        content: existingWhiteboard.content,
        created_at: new Date().toISOString(),
        user_id: req.user?.id || 'user-123',
        version_number: mockVersions.filter(v => v.whiteboard_id === id).length + 1
      };
      
      mockVersions.push(newVersion);
    }

    const updatedWhiteboard = {
      ...existingWhiteboard,
      ...updateData,
      updated_at: new Date().toISOString()
    };

    mockWhiteboards[whiteboardIndex] = updatedWhiteboard;

    res.json({
      success: true,
      data: updatedWhiteboard
    });
  } catch (error) {
    console.error('Error updating whiteboard:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update whiteboard'
    });
  }
});

// Save whiteboard snapshot
router.post('/:id/snapshot', (req, res) => {
  try {
    const { id } = req.params;
    const validation = SaveSnapshotSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: 'Invalid request data',
        details: validation.error.errors
      });
    }

    const { content, save_as_image } = validation.data;
    const whiteboard = mockWhiteboards.find(w => w.id === id);
    
    if (!whiteboard) {
      return res.status(404).json({
        success: false,
        error: 'Whiteboard not found'
      });
    }

    // Save snapshot to directory
    const snapshot = {
      id: `snapshot-${Date.now()}`,
      whiteboard_id: id,
      name: `${whiteboard.name} - Snapshot`,
      content,
      created_at: new Date().toISOString(),
      user_id: req.user?.id || 'user-123',
      format: save_as_image ? 'image' : 'json',
      file_url: save_as_image ? `/snapshots/${id}-${Date.now()}.png` : `/snapshots/${id}-${Date.now()}.json`
    };

    res.json({
      success: true,
      data: snapshot,
      message: 'Snapshot saved to directory successfully'
    });
  } catch (error) {
    console.error('Error saving snapshot:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to save snapshot'
    });
  }
});

// Get whiteboard versions
router.get('/:id/versions', (req, res) => {
  try {
    const { id } = req.params;
    
    const versions = mockVersions
      .filter(v => v.whiteboard_id === id)
      .sort((a, b) => b.version_number - a.version_number);
    
    res.json({
      success: true,
      data: versions,
      total: versions.length
    });
  } catch (error) {
    console.error('Error fetching versions:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch versions'
    });
  }
});

// Add collaborator
router.post('/:id/collaborators', (req, res) => {
  try {
    const { id } = req.params;
    const { user_id } = req.body;
    
    if (!user_id) {
      return res.status(400).json({
        success: false,
        error: 'User ID is required'
      });
    }

    const whiteboardIndex = mockWhiteboards.findIndex(w => w.id === id);
    if (whiteboardIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Whiteboard not found'
      });
    }

    const whiteboard = mockWhiteboards[whiteboardIndex];
    if (!whiteboard.collaborators.includes(user_id)) {
      whiteboard.collaborators.push(user_id);
      whiteboard.updated_at = new Date().toISOString();
    }

    res.json({
      success: true,
      data: whiteboard
    });
  } catch (error) {
    console.error('Error adding collaborator:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to add collaborator'
    });
  }
});

// Remove collaborator
router.delete('/:id/collaborators/:userId', (req, res) => {
  try {
    const { id, userId } = req.params;
    
    const whiteboardIndex = mockWhiteboards.findIndex(w => w.id === id);
    if (whiteboardIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Whiteboard not found'
      });
    }

    const whiteboard = mockWhiteboards[whiteboardIndex];
    whiteboard.collaborators = whiteboard.collaborators.filter(uid => uid !== userId);
    whiteboard.updated_at = new Date().toISOString();

    res.json({
      success: true,
      data: whiteboard
    });
  } catch (error) {
    console.error('Error removing collaborator:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to remove collaborator'
    });
  }
});

// Delete whiteboard
router.delete('/:id', (req, res) => {
  try {
    const { id } = req.params;
    
    const whiteboardIndex = mockWhiteboards.findIndex(w => w.id === id);
    if (whiteboardIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Whiteboard not found'
      });
    }
    
    mockWhiteboards.splice(whiteboardIndex, 1);
    
    // Also remove versions
    const versionIndices = mockVersions
      .map((v, index) => v.whiteboard_id === id ? index : -1)
      .filter(index => index !== -1)
      .reverse(); // Remove from end to start to avoid index issues
    
    versionIndices.forEach(index => mockVersions.splice(index, 1));
    
    res.json({
      success: true,
      message: 'Whiteboard deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting whiteboard:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete whiteboard'
    });
  }
});

// Duplicate whiteboard
router.post('/:id/duplicate', (req, res) => {
  try {
    const { id } = req.params;
    const { name } = req.body;
    
    const originalWhiteboard = mockWhiteboards.find(w => w.id === id);
    if (!originalWhiteboard) {
      return res.status(404).json({
        success: false,
        error: 'Whiteboard not found'
      });
    }

    const duplicatedWhiteboard: Whiteboard = {
      ...originalWhiteboard,
      id: `whiteboard-${Date.now()}`,
      name: name || `${originalWhiteboard.name} (Copy)`,
      user_id: req.user?.id || 'user-123',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      collaborators: [req.user?.id || 'user-123']
    };

    mockWhiteboards.push(duplicatedWhiteboard);

    res.json({
      success: true,
      data: duplicatedWhiteboard
    });
  } catch (error) {
    console.error('Error duplicating whiteboard:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to duplicate whiteboard'
    });
  }
});

export default router;
