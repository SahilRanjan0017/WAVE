import { RequestHandler } from "express";
import { z } from "zod";
import { Message, CreateThreadRequest, Thread, ApiResponse, User, PaginatedResponse } from "@shared/api";

// Mock database
let threads: Thread[] = [];
let threadMessages: Map<string, Message[]> = new Map();

// Validation schemas
const createThreadReplySchema = z.object({
  parent_message_id: z.string(),
  content: z.string().min(1),
  type: z.enum(['text', 'file', 'image', 'audio', 'video']).default('text'),
  file_url: z.string().optional()
});

export const createThreadReply: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = createThreadReplySchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid input",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const { parent_message_id, content, type, file_url } = validation.data as CreateThreadRequest;

    // Find or create thread
    let thread = threads.find(t => t.parent_message_id === parent_message_id);
    if (!thread) {
      thread = {
        id: Date.now().toString(),
        parent_message_id,
        channel_id: 'general', // In real app, get from parent message
        reply_count: 0,
        participants: [user],
        last_reply: new Date().toISOString(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      threads.push(thread);
      threadMessages.set(thread.id, []);
    }

    // Create thread reply
    const reply: Message = {
      id: Date.now().toString(),
      sender_id: user.id,
      content,
      formatted_content: content,
      type,
      file_url,
      is_edited: false,
      thread_ts: thread.id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      sender: user,
      reactions: []
    };

    // Add to thread messages
    const messages = threadMessages.get(thread.id) || [];
    messages.push(reply);
    threadMessages.set(thread.id, messages);

    // Update thread
    thread.reply_count = messages.length;
    thread.last_reply = new Date().toISOString();
    thread.updated_at = new Date().toISOString();

    // Add participant if not already in thread
    if (!thread.participants.find(p => p.id === user.id)) {
      thread.participants.push(user);
    }

    // Broadcast thread reply via WebSocket
    const wsManager = (req as any).app?.wsManager;
    if (wsManager) {
      wsManager.broadcastToChannel(thread.channel_id, {
        type: 'thread_reply',
        data: {
          thread,
          reply,
          parent_message_id
        }
      });
    }

    res.status(201).json({
      success: true,
      data: reply
    } as ApiResponse<Message>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getThreadReplies: RequestHandler = (req, res) => {
  try {
    const { threadId } = req.params;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 50;

    const messages = threadMessages.get(threadId) || [];
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedMessages = messages.slice(startIndex, endIndex);

    res.json({
      success: true,
      data: {
        data: paginatedMessages,
        page,
        limit,
        total: messages.length,
        has_more: endIndex < messages.length
      }
    } as ApiResponse<PaginatedResponse<Message>>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getMessageThread: RequestHandler = (req, res) => {
  try {
    const { messageId } = req.params;
    
    const thread = threads.find(t => t.parent_message_id === messageId);
    if (!thread) {
      return res.status(404).json({
        success: false,
        error: "Thread not found"
      } as ApiResponse);
    }

    const messages = threadMessages.get(thread.id) || [];
    
    res.json({
      success: true,
      data: {
        thread,
        messages
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getActiveThreads: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { channelId } = req.params;

    // Get threads where user is a participant
    const userThreads = threads
      .filter(thread => 
        thread.channel_id === channelId && 
        thread.participants.find(p => p.id === user.id)
      )
      .sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime())
      .slice(0, 20); // Limit to recent 20 threads

    res.json({
      success: true,
      data: userThreads
    } as ApiResponse<Thread[]>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};
