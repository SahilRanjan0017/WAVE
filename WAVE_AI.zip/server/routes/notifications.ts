import { RequestHandler } from "express";
import { z } from "zod";
import { Notification, ApiResponse, User, PaginatedResponse } from "@shared/api";

// Mock database for notifications
let notifications: Notification[] = [];
let userNotificationSettings: Map<string, {
  email_notifications: boolean;
  push_notifications: boolean;
  desktop_notifications: boolean;
  channel_notifications: { [channelId: string]: 'all' | 'mentions' | 'none' };
  dnd_start?: string;
  dnd_end?: string;
  keywords: string[];
}> = new Map();

// Initialize default notification settings
const defaultNotificationSettings = {
  email_notifications: true,
  push_notifications: true,
  desktop_notifications: true,
  channel_notifications: {},
  keywords: []
};

const createNotificationSchema = z.object({
  user_id: z.string(),
  type: z.enum(['mention', 'dm', 'invite', 'channel_add', 'reaction', 'thread_reply', 'file_share']),
  title: z.string(),
  message: z.string(),
  related_id: z.string().optional(),
  related_user_id: z.string().optional(),
  related_channel_id: z.string().optional()
});

const updateNotificationSettingsSchema = z.object({
  email_notifications: z.boolean().optional(),
  push_notifications: z.boolean().optional(),
  desktop_notifications: z.boolean().optional(),
  channel_notifications: z.record(z.enum(['all', 'mentions', 'none'])).optional(),
  dnd_start: z.string().optional(),
  dnd_end: z.string().optional(),
  keywords: z.array(z.string()).optional()
});

export const createNotification = async (
  userId: string,
  type: Notification['type'],
  title: string,
  message: string,
  relatedId?: string,
  relatedUserId?: string,
  relatedChannelId?: string
) => {
  const notification: Notification = {
    id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
    user_id: userId,
    type,
    title,
    message,
    read: false,
    created_at: new Date().toISOString(),
    related_id: relatedId,
    related_user: relatedUserId ? { 
      id: relatedUserId, 
      username: 'user', 
      full_name: 'User Name',
      email: 'user@example.com',
      status: 'online' as const,
      created_at: new Date().toISOString()
    } : undefined,
    related_channel: relatedChannelId ? {
      id: relatedChannelId,
      name: 'channel-name',
      workspace_id: 'default',
      created_by: relatedUserId || 'system',
      created_at: new Date().toISOString(),
      is_private: false
    } : undefined
  };

  notifications.unshift(notification);

  // Check if user should receive this notification
  const settings = userNotificationSettings.get(userId) || defaultNotificationSettings;
  
  // Check do not disturb
  const now = new Date();
  const currentTime = now.toTimeString().slice(0, 5);
  if (settings.dnd_start && settings.dnd_end) {
    if (currentTime >= settings.dnd_start && currentTime <= settings.dnd_end) {
      return notification; // Don't send during DND
    }
  }

  return notification;
};

export const getUserNotifications: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const unread_only = req.query.unread_only === 'true';

    let userNotifications = notifications.filter(n => n.user_id === user.id);
    
    if (unread_only) {
      userNotifications = userNotifications.filter(n => !n.read);
    }

    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedNotifications = userNotifications.slice(startIndex, endIndex);

    res.json({
      success: true,
      data: {
        data: paginatedNotifications,
        page,
        limit,
        total: userNotifications.length,
        has_more: endIndex < userNotifications.length,
        unread_count: notifications.filter(n => n.user_id === user.id && !n.read).length
      }
    } as ApiResponse<PaginatedResponse<Notification> & { unread_count: number }>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const markNotificationRead: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { notificationId } = req.params;

    const notificationIndex = notifications.findIndex(n => 
      n.id === notificationId && n.user_id === user.id
    );

    if (notificationIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Notification not found"
      } as ApiResponse);
    }

    notifications[notificationIndex].read = true;

    res.json({
      success: true,
      message: "Notification marked as read"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const markAllNotificationsRead: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;

    notifications.forEach(notification => {
      if (notification.user_id === user.id) {
        notification.read = true;
      }
    });

    res.json({
      success: true,
      message: "All notifications marked as read"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getNotificationSettings: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    
    const settings = userNotificationSettings.get(user.id) || defaultNotificationSettings;

    res.json({
      success: true,
      data: settings
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const updateNotificationSettings: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = updateNotificationSettingsSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid input",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const updates = validation.data;
    const currentSettings = userNotificationSettings.get(user.id) || defaultNotificationSettings;
    
    const newSettings = {
      ...currentSettings,
      ...updates
    };

    userNotificationSettings.set(user.id, newSettings);

    res.json({
      success: true,
      data: newSettings,
      message: "Notification settings updated"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const deleteNotification: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { notificationId } = req.params;

    const notificationIndex = notifications.findIndex(n => 
      n.id === notificationId && n.user_id === user.id
    );

    if (notificationIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Notification not found"
      } as ApiResponse);
    }

    notifications.splice(notificationIndex, 1);

    res.json({
      success: true,
      message: "Notification deleted"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

// Helper function to send notification
export const sendNotification = async (
  userId: string,
  type: Notification['type'],
  title: string,
  message: string,
  relatedId?: string,
  relatedUserId?: string,
  relatedChannelId?: string,
  wsManager?: any
) => {
  const notification = await createNotification(
    userId, type, title, message, relatedId, relatedUserId, relatedChannelId
  );

  // Send real-time notification via WebSocket
  if (wsManager) {
    wsManager.broadcastToUser(userId, {
      type: 'notification',
      data: notification
    });
  }

  return notification;
};

// Auto-generate notifications for common events
export const generateMentionNotification = async (
  mentionedUserId: string,
  senderUserId: string,
  messageContent: string,
  channelId: string,
  messageId: string,
  wsManager?: any
) => {
  return sendNotification(
    mentionedUserId,
    'mention',
    'You were mentioned',
    `${messageContent.substring(0, 100)}...`,
    messageId,
    senderUserId,
    channelId,
    wsManager
  );
};

export const generateDirectMessageNotification = async (
  receiverId: string,
  senderId: string,
  messageContent: string,
  messageId: string,
  wsManager?: any
) => {
  return sendNotification(
    receiverId,
    'dm',
    'New direct message',
    `${messageContent.substring(0, 100)}...`,
    messageId,
    senderId,
    undefined,
    wsManager
  );
};

export const generateReactionNotification = async (
  messageOwnerId: string,
  reactorId: string,
  emoji: string,
  messageId: string,
  channelId: string,
  wsManager?: any
) => {
  return sendNotification(
    messageOwnerId,
    'reaction',
    'Someone reacted to your message',
    `Reacted with ${emoji}`,
    messageId,
    reactorId,
    channelId,
    wsManager
  );
};
