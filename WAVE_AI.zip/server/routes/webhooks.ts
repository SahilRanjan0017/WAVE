import { RequestHandler } from "express";
import { z } from "zod";
import { ApiResponse, User } from "@shared/api";
import crypto from "crypto";

interface Webhook {
  id: string;
  name: string;
  url: string;
  workspace_id: string;
  channel_id?: string;
  created_by: string;
  secret: string;
  is_active: boolean;
  events: WebhookEvent[];
  headers: { [key: string]: string };
  created_at: string;
  updated_at: string;
  last_triggered?: string;
  trigger_count: number;
}

type WebhookEvent = 
  | 'message.posted' 
  | 'message.updated' 
  | 'message.deleted'
  | 'channel.created' 
  | 'channel.updated'
  | 'member.joined' 
  | 'member.left'
  | 'file.uploaded'
  | 'reaction.added'
  | 'reaction.removed';

interface WebhookDelivery {
  id: string;
  webhook_id: string;
  event_type: WebhookEvent;
  payload: any;
  response_status?: number;
  response_body?: string;
  response_time?: number;
  error?: string;
  created_at: string;
  delivered_at?: string;
}

interface Integration {
  id: string;
  name: string;
  description: string;
  category: 'productivity' | 'development' | 'communication' | 'analytics' | 'custom';
  icon_url: string;
  webhook_url?: string;
  oauth_url?: string;
  config_schema: any;
  supported_events: WebhookEvent[];
  is_official: boolean;
}

// Mock databases
let webhooks: Webhook[] = [];
let webhookDeliveries: WebhookDelivery[] = [];

// Popular integrations directory
const integrations: Integration[] = [
  {
    id: 'github',
    name: 'GitHub',
    description: 'Get notifications for commits, pull requests, and issues',
    category: 'development',
    icon_url: 'https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png',
    webhook_url: 'https://api.github.com/webhooks',
    oauth_url: 'https://github.com/login/oauth/authorize',
    config_schema: {
      repository: { type: 'string', required: true },
      events: { type: 'array', items: ['push', 'pull_request', 'issues'] }
    },
    supported_events: ['message.posted'],
    is_official: true
  },
  {
    id: 'jira',
    name: 'Jira',
    description: 'Track project progress and get issue notifications',
    category: 'productivity',
    icon_url: 'https://wac-cdn.atlassian.com/dam/jcr:8f4d5e0b-7c80-453f-8d2c-14b8e2c73ccf/jira%20logo.svg',
    config_schema: {
      instance_url: { type: 'string', required: true },
      project_key: { type: 'string', required: true }
    },
    supported_events: ['message.posted', 'channel.created'],
    is_official: true
  },
  {
    id: 'trello',
    name: 'Trello',
    description: 'Get updates when cards are moved or updated',
    category: 'productivity',
    icon_url: 'https://d2k1ftgv7pobq7.cloudfront.net/meta/c/p/res/images/trello-header-logos/167dc7b9900a5b241b15ba21f8037cf6/trello-logo-blue.svg',
    config_schema: {
      board_id: { type: 'string', required: true }
    },
    supported_events: ['message.posted'],
    is_official: true
  },
  {
    id: 'google_drive',
    name: 'Google Drive',
    description: 'Share files and get collaboration notifications',
    category: 'productivity',
    icon_url: 'https://ssl.gstatic.com/docs/doclist/images/drive_2022q3_32dp.png',
    oauth_url: 'https://accounts.google.com/oauth/authorize',
    config_schema: {
      folder_id: { type: 'string', required: false }
    },
    supported_events: ['file.uploaded'],
    is_official: true
  },
  {
    id: 'zoom',
    name: 'Zoom',
    description: 'Start meetings and get notifications',
    category: 'communication',
    icon_url: 'https://st1.zoom.us/zoom.ico',
    config_schema: {
      api_key: { type: 'string', required: true },
      api_secret: { type: 'string', required: true }
    },
    supported_events: ['message.posted'],
    is_official: true
  }
];

// Validation schemas
const createWebhookSchema = z.object({
  name: z.string().min(1).max(100),
  url: z.string().url(),
  workspace_id: z.string(),
  channel_id: z.string().optional(),
  events: z.array(z.enum([
    'message.posted', 'message.updated', 'message.deleted',
    'channel.created', 'channel.updated',
    'member.joined', 'member.left',
    'file.uploaded',
    'reaction.added', 'reaction.removed'
  ])),
  headers: z.record(z.string()).optional()
});

export const getWebhooks: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { workspace_id } = req.query;

    let userWebhooks = webhooks.filter(w => w.created_by === user.id);
    
    if (workspace_id) {
      userWebhooks = userWebhooks.filter(w => w.workspace_id === workspace_id);
    }

    res.json({
      success: true,
      data: userWebhooks.map(webhook => ({
        ...webhook,
        secret: undefined // Don't expose secret in list
      }))
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const createWebhook: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = createWebhookSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid webhook data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const webhookData = validation.data;
    
    // Generate secure secret
    const secret = crypto.randomBytes(32).toString('hex');
    
    const webhook: Webhook = {
      id: Date.now().toString(),
      name: webhookData.name,
      url: webhookData.url,
      workspace_id: webhookData.workspace_id,
      channel_id: webhookData.channel_id,
      created_by: user.id,
      secret,
      is_active: true,
      events: webhookData.events,
      headers: webhookData.headers || {},
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      trigger_count: 0
    };

    webhooks.push(webhook);

    res.status(201).json({
      success: true,
      data: webhook
    } as ApiResponse<Webhook>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const updateWebhook: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { webhookId } = req.params;
    
    const webhookIndex = webhooks.findIndex(w => 
      w.id === webhookId && w.created_by === user.id
    );

    if (webhookIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Webhook not found"
      } as ApiResponse);
    }

    const updates = req.body;
    webhooks[webhookIndex] = {
      ...webhooks[webhookIndex],
      ...updates,
      updated_at: new Date().toISOString()
    };

    res.json({
      success: true,
      data: webhooks[webhookIndex]
    } as ApiResponse<Webhook>);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const deleteWebhook: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { webhookId } = req.params;
    
    const webhookIndex = webhooks.findIndex(w => 
      w.id === webhookId && w.created_by === user.id
    );

    if (webhookIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Webhook not found"
      } as ApiResponse);
    }

    webhooks.splice(webhookIndex, 1);

    res.json({
      success: true,
      message: "Webhook deleted successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const testWebhook: RequestHandler = async (req, res) => {
  try {
    const user = (req as any).user as User;
    const { webhookId } = req.params;
    
    const webhook = webhooks.find(w => 
      w.id === webhookId && w.created_by === user.id
    );

    if (!webhook) {
      return res.status(404).json({
        success: false,
        error: "Webhook not found"
      } as ApiResponse);
    }

    // Send test payload
    const testPayload = {
      event: 'webhook.test',
      data: {
        message: 'This is a test webhook delivery',
        webhook_id: webhook.id,
        timestamp: new Date().toISOString()
      }
    };

    const delivery = await deliverWebhook(webhook, 'message.posted', testPayload);

    res.json({
      success: true,
      data: delivery,
      message: "Test webhook sent successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Webhook test failed"
    } as ApiResponse);
  }
};

export const getWebhookDeliveries: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { webhookId } = req.params;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;

    // Verify webhook ownership
    const webhook = webhooks.find(w => 
      w.id === webhookId && w.created_by === user.id
    );

    if (!webhook) {
      return res.status(404).json({
        success: false,
        error: "Webhook not found"
      } as ApiResponse);
    }

    let deliveries = webhookDeliveries.filter(d => d.webhook_id === webhookId);
    deliveries.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedDeliveries = deliveries.slice(startIndex, endIndex);

    res.json({
      success: true,
      data: {
        data: paginatedDeliveries,
        page,
        limit,
        total: deliveries.length,
        has_more: endIndex < deliveries.length
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getIntegrations: RequestHandler = (req, res) => {
  try {
    const { category, search } = req.query;
    
    let filteredIntegrations = integrations;
    
    if (category) {
      filteredIntegrations = filteredIntegrations.filter(i => i.category === category);
    }
    
    if (search) {
      const searchTerm = (search as string).toLowerCase();
      filteredIntegrations = filteredIntegrations.filter(i =>
        i.name.toLowerCase().includes(searchTerm) ||
        i.description.toLowerCase().includes(searchTerm)
      );
    }

    res.json({
      success: true,
      data: filteredIntegrations
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const installIntegration: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { integrationId } = req.params;
    const { workspace_id, channel_id, config } = req.body;

    const integration = integrations.find(i => i.id === integrationId);
    if (!integration) {
      return res.status(404).json({
        success: false,
        error: "Integration not found"
      } as ApiResponse);
    }

    // Create webhook for the integration
    const webhook: Webhook = {
      id: Date.now().toString(),
      name: `${integration.name} Integration`,
      url: integration.webhook_url || `https://api.${integration.id}.com/webhooks`,
      workspace_id,
      channel_id,
      created_by: user.id,
      secret: crypto.randomBytes(32).toString('hex'),
      is_active: true,
      events: integration.supported_events,
      headers: {
        'User-Agent': 'WAVE-AI-Webhook/1.0',
        'X-Integration': integration.id
      },
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      trigger_count: 0
    };

    webhooks.push(webhook);

    res.status(201).json({
      success: true,
      data: {
        integration,
        webhook,
        config
      },
      message: `${integration.name} integration installed successfully`
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Integration installation failed"
    } as ApiResponse);
  }
};

export const receiveWebhook: RequestHandler = (req, res) => {
  try {
    const { webhookId } = req.params;
    const payload = req.body;
    const signature = req.headers['x-slack-signature'] as string;

    // Find webhook (in production, use webhook secret for verification)
    const webhook = webhooks.find(w => w.id === webhookId && w.is_active);
    if (!webhook) {
      return res.status(404).json({
        success: false,
        error: "Webhook not found or inactive"
      } as ApiResponse);
    }

    // Verify signature (in production)
    // const computedSignature = crypto
    //   .createHmac('sha256', webhook.secret)
    //   .update(JSON.stringify(payload))
    //   .digest('hex');

    // Process webhook payload based on source
    processIncomingWebhook(webhook, payload);

    res.json({
      success: true,
      message: "Webhook received successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Webhook processing failed"
    } as ApiResponse);
  }
};

// Webhook delivery engine
async function deliverWebhook(
  webhook: Webhook, 
  eventType: WebhookEvent, 
  payload: any
): Promise<WebhookDelivery> {
  const delivery: WebhookDelivery = {
    id: Date.now().toString(),
    webhook_id: webhook.id,
    event_type: eventType,
    payload,
    created_at: new Date().toISOString()
  };

  try {
    const startTime = Date.now();
    
    // Create signature
    const signature = crypto
      .createHmac('sha256', webhook.secret)
      .update(JSON.stringify(payload))
      .digest('hex');

    const headers = {
      'Content-Type': 'application/json',
      'X-Slack-Signature': `sha256=${signature}`,
      'X-Slack-Request-Timestamp': Math.floor(Date.now() / 1000).toString(),
      ...webhook.headers
    };

    // Simulate HTTP request (in production, use actual HTTP client)
    await new Promise(resolve => setTimeout(resolve, Math.random() * 1000 + 500));
    
    delivery.response_status = 200;
    delivery.response_body = '{"success": true}';
    delivery.response_time = Date.now() - startTime;
    delivery.delivered_at = new Date().toISOString();

    // Update webhook stats
    const webhookIndex = webhooks.findIndex(w => w.id === webhook.id);
    if (webhookIndex !== -1) {
      webhooks[webhookIndex].last_triggered = new Date().toISOString();
      webhooks[webhookIndex].trigger_count++;
    }

  } catch (error) {
    delivery.error = error instanceof Error ? error.message : 'Unknown error';
    delivery.response_status = 500;
  }

  webhookDeliveries.unshift(delivery);
  
  // Keep only latest 1000 deliveries
  if (webhookDeliveries.length > 1000) {
    webhookDeliveries = webhookDeliveries.slice(0, 1000);
  }

  return delivery;
}

// Process incoming webhook from external services
function processIncomingWebhook(webhook: Webhook, payload: any) {
  // Parse different webhook formats
  let message = '';
  let channelId = webhook.channel_id;

  // GitHub webhook
  if (payload.repository && payload.commits) {
    message = `🔔 New commits pushed to ${payload.repository.name}:\n`;
    payload.commits.forEach((commit: any) => {
      message += `• ${commit.message} (${commit.author.name})\n`;
    });
  }
  // Jira webhook
  else if (payload.issue && payload.issue.key) {
    message = `📋 Jira issue ${payload.issue.key} was ${payload.webhookEvent}:\n${payload.issue.fields.summary}`;
  }
  // Generic webhook
  else {
    message = `🔗 Webhook received: ${JSON.stringify(payload, null, 2)}`;
  }

  // In production, create actual message in the channel
  console.log(`Webhook message for channel ${channelId}: ${message}`);
}

// Function to trigger webhooks for events
export const triggerWebhooks = async (
  eventType: WebhookEvent, 
  data: any, 
  workspaceId: string, 
  channelId?: string
) => {
  const applicableWebhooks = webhooks.filter(w => 
    w.is_active && 
    w.workspace_id === workspaceId &&
    w.events.includes(eventType) &&
    (!w.channel_id || w.channel_id === channelId)
  );

  const payload = {
    event: eventType,
    data,
    workspace_id: workspaceId,
    channel_id: channelId,
    timestamp: new Date().toISOString()
  };

  // Deliver webhooks in parallel
  const deliveryPromises = applicableWebhooks.map(webhook => 
    deliverWebhook(webhook, eventType, payload)
  );

  await Promise.allSettled(deliveryPromises);
};
