import { RequestHandler } from "express";
import { z } from "zod";
import { UpdateUserStatusRequest, UserPresence, ApiResponse, User } from "@shared/api";

// Mock database for user statuses
let userStatuses: Map<string, {
  status: 'online' | 'away' | 'offline';
  status_text?: string;
  status_emoji?: string;
  expires_at?: Date;
  last_seen: Date;
}> = new Map();

// Predefined status options
const predefinedStatuses = [
  {
    emoji: '🟢',
    text: 'Available',
    status: 'online' as const
  },
  {
    emoji: '🔴',
    text: 'Busy',
    status: 'away' as const
  },
  {
    emoji: '🟡',
    text: 'Away',
    status: 'away' as const
  },
  {
    emoji: '🏠',
    text: 'Working from home',
    status: 'online' as const
  },
  {
    emoji: '🍽️',
    text: 'Out for lunch',
    status: 'away' as const
  },
  {
    emoji: '📞',
    text: 'In a call',
    status: 'away' as const
  },
  {
    emoji: '🏝️',
    text: 'Vacationing',
    status: 'away' as const
  },
  {
    emoji: '🤒',
    text: 'Out sick',
    status: 'offline' as const
  },
  {
    emoji: '🎯',
    text: 'Focusing',
    status: 'away' as const
  },
  {
    emoji: '🚌',
    text: 'Commuting',
    status: 'away' as const
  }
];

// Validation schemas
const updateStatusSchema = z.object({
  status: z.enum(['online', 'away', 'offline']),
  status_text: z.string().max(100).optional(),
  status_emoji: z.string().optional(),
  expires_at: z.string().optional()
});

export const updateUserStatus: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = updateStatusSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid input",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const { status, status_text, status_emoji, expires_at } = validation.data as UpdateUserStatusRequest;

    const userStatus = {
      status,
      status_text,
      status_emoji,
      expires_at: expires_at ? new Date(expires_at) : undefined,
      last_seen: new Date()
    };

    userStatuses.set(user.id, userStatus);

    // Broadcast status update via WebSocket
    const wsManager = (req as any).app?.wsManager;
    if (wsManager) {
      wsManager.broadcastToAll({
        type: 'user_status_update',
        data: {
          user_id: user.id,
          user: user,
          status: userStatus
        }
      });
    }

    res.json({
      success: true,
      data: userStatus,
      message: "Status updated successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getUserStatus: RequestHandler = (req, res) => {
  try {
    const { userId } = req.params;
    
    const userStatus = userStatuses.get(userId) || {
      status: 'offline' as const,
      last_seen: new Date()
    };

    // Check if status has expired
    if (userStatus.expires_at && new Date() > userStatus.expires_at) {
      userStatus.status = 'online';
      userStatus.status_text = undefined;
      userStatus.status_emoji = undefined;
      userStatus.expires_at = undefined;
      userStatuses.set(userId, userStatus);
    }

    res.json({
      success: true,
      data: userStatus
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const clearUserStatus: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    
    const userStatus = {
      status: 'online' as const,
      status_text: undefined,
      status_emoji: undefined,
      expires_at: undefined,
      last_seen: new Date()
    };

    userStatuses.set(user.id, userStatus);

    // Broadcast status update via WebSocket
    const wsManager = (req as any).app?.wsManager;
    if (wsManager) {
      wsManager.broadcastToAll({
        type: 'user_status_update',
        data: {
          user_id: user.id,
          user: user,
          status: userStatus
        }
      });
    }

    res.json({
      success: true,
      message: "Status cleared successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getPredefinedStatuses: RequestHandler = (req, res) => {
  try {
    res.json({
      success: true,
      data: predefinedStatuses
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getOnlineUsers: RequestHandler = (req, res) => {
  try {
    const onlineUsers: Array<{
      user_id: string;
      status: string;
      status_text?: string;
      status_emoji?: string;
      last_seen: string;
    }> = [];

    userStatuses.forEach((status, userId) => {
      if (status.status === 'online' || status.status === 'away') {
        onlineUsers.push({
          user_id: userId,
          status: status.status,
          status_text: status.status_text,
          status_emoji: status.status_emoji,
          last_seen: status.last_seen.toISOString()
        });
      }
    });

    // Sort by last seen (most recent first)
    onlineUsers.sort((a, b) => new Date(b.last_seen).getTime() - new Date(a.last_seen).getTime());

    res.json({
      success: true,
      data: onlineUsers
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const setDoNotDisturb: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { duration_minutes } = req.body;

    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + (duration_minutes || 60));

    const userStatus = {
      status: 'away' as const,
      status_text: 'Do not disturb',
      status_emoji: '🔕',
      expires_at: expiresAt,
      last_seen: new Date()
    };

    userStatuses.set(user.id, userStatus);

    // Broadcast status update via WebSocket
    const wsManager = (req as any).app?.wsManager;
    if (wsManager) {
      wsManager.broadcastToAll({
        type: 'user_status_update',
        data: {
          user_id: user.id,
          user: user,
          status: userStatus
        }
      });
    }

    res.json({
      success: true,
      data: userStatus,
      message: `Do not disturb set for ${duration_minutes || 60} minutes`
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const updatePresence: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { activity } = req.body; // 'active', 'idle', 'offline'

    const currentStatus = userStatuses.get(user.id) || {
      status: 'online' as const,
      last_seen: new Date()
    };

    // Update based on activity
    if (activity === 'active') {
      currentStatus.status = 'online';
    } else if (activity === 'idle') {
      currentStatus.status = 'away';
    } else if (activity === 'offline') {
      currentStatus.status = 'offline';
    }

    currentStatus.last_seen = new Date();
    userStatuses.set(user.id, currentStatus);

    // Broadcast presence update via WebSocket
    const wsManager = (req as any).app?.wsManager;
    if (wsManager) {
      wsManager.broadcastToAll({
        type: 'presence_update',
        data: {
          user_id: user.id,
          status: currentStatus.status,
          last_seen: currentStatus.last_seen.toISOString()
        }
      });
    }

    res.json({
      success: true,
      data: {
        user_id: user.id,
        status: currentStatus.status,
        activity,
        last_seen: currentStatus.last_seen.toISOString()
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};
