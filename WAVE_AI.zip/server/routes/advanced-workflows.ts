import { RequestHandler } from "express";
import { z } from "zod";
import { ApiResponse, User } from "@shared/api";
import crypto from 'crypto';

// Advanced workflow interfaces
interface WorkflowNode {
  id: string;
  type: 'trigger' | 'action' | 'condition' | 'delay' | 'webhook' | 'integration';
  name: string;
  description?: string;
  config: Record<string, any>;
  position: { x: number; y: number };
  connections: {
    input?: string[];
    output?: string[];
  };
}

interface WorkflowEdge {
  id: string;
  source: string;
  target: string;
  sourceHandle?: string;
  targetHandle?: string;
  condition?: {
    field: string;
    operator: 'equals' | 'contains' | 'greater_than' | 'less_than' | 'exists';
    value: any;
  };
}

interface AdvancedWorkflow {
  id: string;
  workspace_id: string;
  name: string;
  description: string;
  version: number;
  status: 'draft' | 'active' | 'paused' | 'archived';
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
  variables: {
    name: string;
    type: 'string' | 'number' | 'boolean' | 'object';
    default_value?: any;
    description?: string;
  }[];
  settings: {
    timeout_minutes: number;
    retry_attempts: number;
    error_handling: 'stop' | 'continue' | 'retry';
    concurrent_executions: number;
  };
  created_by: string;
  created_at: string;
  updated_at: string;
  last_run: string;
  total_runs: number;
  success_rate: number;
}

interface WorkflowExecution {
  id: string;
  workflow_id: string;
  trigger_data: any;
  status: 'running' | 'completed' | 'failed' | 'cancelled';
  started_at: string;
  completed_at?: string;
  error_message?: string;
  execution_log: {
    node_id: string;
    timestamp: string;
    status: 'pending' | 'running' | 'completed' | 'failed' | 'skipped';
    input_data?: any;
    output_data?: any;
    error?: string;
    duration_ms?: number;
  }[];
  metrics: {
    total_duration_ms: number;
    nodes_executed: number;
    data_transferred_bytes: number;
  };
}

interface OAuthApp {
  id: string;
  workspace_id: string;
  name: string;
  description: string;
  provider: string;
  category: 'productivity' | 'development' | 'marketing' | 'hr' | 'finance' | 'communication' | 'analytics';
  logo_url: string;
  website_url: string;
  support_url?: string;
  client_id: string;
  client_secret: string;
  scopes: string[];
  redirect_uris: string[];
  webhook_endpoints: {
    url: string;
    events: string[];
    secret: string;
  }[];
  is_verified: boolean;
  is_public: boolean;
  install_count: number;
  rating: number;
  reviews_count: number;
  created_by: string;
  created_at: string;
  updated_at: string;
}

interface AppInstallation {
  id: string;
  app_id: string;
  workspace_id: string;
  user_id: string;
  access_token: string;
  refresh_token?: string;
  expires_at?: string;
  scopes: string[];
  config: Record<string, any>;
  status: 'active' | 'revoked' | 'expired';
  installed_at: string;
  last_used_at?: string;
}

interface IntegrationTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  apps: string[];
  workflow_template: {
    nodes: Omit<WorkflowNode, 'id'>[];
    edges: Omit<WorkflowEdge, 'id'>[];
  };
  setup_instructions: string;
  use_cases: string[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimated_setup_time: number;
  popularity_score: number;
}

// Mock databases
let advancedWorkflows: AdvancedWorkflow[] = [];
let workflowExecutions: WorkflowExecution[] = [];
let oauthApps: OAuthApp[] = [
  {
    id: "waveai-app",
    workspace_id: "default",
    name: "WAVE AI Internal",
    description: "Send messages and notifications to WAVE AI channels",
    provider: "waveai",
    category: "communication",
    logo_url: "/api/assets/waveai-logo.png",
    website_url: "https://waveai.com",
    support_url: "https://waveai.com/help",
    client_id: "waveai_client_id",
    client_secret: "waveai_client_secret",
    scopes: ["chat:write", "channels:read", "users:read"],
    redirect_uris: ["https://yourapp.com/oauth/waveai/callback"],
    webhook_endpoints: [
      {
        url: "https://yourapp.com/webhooks/waveai",
        events: ["message.channels"],
        secret: crypto.randomBytes(32).toString('hex')
      }
    ],
    is_verified: true,
    is_public: true,
    install_count: 1250,
    rating: 4.8,
    reviews_count: 89,
    created_by: "system",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "github-app",
    workspace_id: "default",
    name: "GitHub",
    description: "Manage repositories, issues, and pull requests",
    provider: "github",
    category: "development",
    logo_url: "https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png",
    website_url: "https://github.com",
    support_url: "https://support.github.com",
    client_id: "github_client_id",
    client_secret: "github_client_secret",
    scopes: ["repo", "issues", "pull_requests"],
    redirect_uris: ["https://yourapp.com/oauth/github/callback"],
    webhook_endpoints: [
      {
        url: "https://yourapp.com/webhooks/github",
        events: ["push", "pull_request", "issues"],
        secret: crypto.randomBytes(32).toString('hex')
      }
    ],
    is_verified: true,
    is_public: true,
    install_count: 890,
    rating: 4.7,
    reviews_count: 156,
    created_by: "system",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "zapier-app",
    workspace_id: "default",
    name: "Zapier",
    description: "Connect with 5000+ apps through Zapier automation",
    provider: "zapier",
    category: "productivity",
    logo_url: "https://cdn.zapier.com/zapier/images/logos/zapier-logo-color.png",
    website_url: "https://zapier.com",
    support_url: "https://help.zapier.com",
    client_id: "zapier_client_id",
    client_secret: "zapier_client_secret",
    scopes: ["read", "write"],
    redirect_uris: ["https://yourapp.com/oauth/zapier/callback"],
    webhook_endpoints: [
      {
        url: "https://yourapp.com/webhooks/zapier",
        events: ["zap.trigger"],
        secret: crypto.randomBytes(32).toString('hex')
      }
    ],
    is_verified: true,
    is_public: true,
    install_count: 2340,
    rating: 4.9,
    reviews_count: 342,
    created_by: "system",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

let appInstallations: AppInstallation[] = [];
let integrationTemplates: IntegrationTemplate[] = [
  {
    id: "waveai-github-notifications",
    name: "GitHub to WAVE AI Notifications",
    description: "Automatically send WAVE AI notifications when GitHub issues are created or updated",
    category: "development",
    apps: ["github-app", "waveai-app"],
    workflow_template: {
      nodes: [
        {
          type: "trigger",
          name: "GitHub Issue Created",
          config: { event: "issues.opened", repository: "" },
          position: { x: 100, y: 100 },
          connections: { output: ["condition-1"] }
        },
        {
          type: "condition",
          name: "Check Priority",
          config: { field: "issue.labels", operator: "contains", value: "high-priority" },
          position: { x: 300, y: 100 },
          connections: { input: ["trigger-1"], output: ["action-1"] }
        },
        {
          type: "action",
          name: "Send WAVE AI Message",
          config: { 
            channel: "#dev-alerts", 
            message: "🚨 High priority issue created: {{issue.title}}\n{{issue.html_url}}"
          },
          position: { x: 500, y: 100 },
          connections: { input: ["condition-1"] }
        }
      ],
      edges: [
        { source: "trigger-1", target: "condition-1" },
        { source: "condition-1", target: "action-1", condition: { field: "result", operator: "equals", value: true } }
      ]
    },
    setup_instructions: "1. Connect your GitHub account\n2. Connect your WAVE AI account\n3. Configure the repository and WAVE AI channel\n4. Set up priority labels",
    use_cases: [
      "Get notified of critical bugs immediately",
      "Track high-priority feature requests",
      "Monitor security vulnerabilities"
    ],
    difficulty: "beginner",
    estimated_setup_time: 5,
    popularity_score: 95
  },
  {
    id: "meeting-room-booking",
    name: "Automated Meeting Room Booking",
    description: "Automatically book meeting rooms when calendar events are created",
    category: "productivity",
    apps: ["calendar-app", "room-booking-app"],
    workflow_template: {
      nodes: [
        {
          type: "trigger",
          name: "Calendar Event Created",
          config: { calendar: "primary", event_type: "meeting" },
          position: { x: 100, y: 100 },
          connections: { output: ["condition-1"] }
        },
        {
          type: "condition",
          name: "Check Attendee Count",
          config: { field: "attendees.length", operator: "greater_than", value: 2 },
          position: { x: 300, y: 100 },
          connections: { input: ["trigger-1"], output: ["action-1"] }
        },
        {
          type: "action",
          name: "Book Meeting Room",
          config: { 
            building: "main", 
            preferred_floor: "2",
            capacity_buffer: 2
          },
          position: { x: 500, y: 100 },
          connections: { input: ["condition-1"], output: ["action-2"] }
        },
        {
          type: "action",
          name: "Update Calendar Event",
          config: { 
            add_location: true,
            send_update: true
          },
          position: { x: 700, y: 100 },
          connections: { input: ["action-1"] }
        }
      ],
      edges: [
        { source: "trigger-1", target: "condition-1" },
        { source: "condition-1", target: "action-1" },
        { source: "action-1", target: "action-2" }
      ]
    },
    setup_instructions: "1. Connect your calendar\n2. Connect room booking system\n3. Configure building and floor preferences\n4. Set capacity requirements",
    use_cases: [
      "Automatically reserve rooms for team meetings",
      "Ensure adequate space for all attendees",
      "Reduce booking conflicts and manual coordination"
    ],
    difficulty: "intermediate",
    estimated_setup_time: 15,
    popularity_score: 78
  }
];

// Validation schemas
const advancedWorkflowSchema = z.object({
  name: z.string().min(1).max(100),
  description: z.string().max(500),
  nodes: z.array(z.object({
    id: z.string(),
    type: z.enum(['trigger', 'action', 'condition', 'delay', 'webhook', 'integration']),
    name: z.string(),
    description: z.string().optional(),
    config: z.record(z.any()),
    position: z.object({
      x: z.number(),
      y: z.number()
    }),
    connections: z.object({
      input: z.array(z.string()).optional(),
      output: z.array(z.string()).optional()
    })
  })),
  edges: z.array(z.object({
    id: z.string(),
    source: z.string(),
    target: z.string(),
    sourceHandle: z.string().optional(),
    targetHandle: z.string().optional(),
    condition: z.object({
      field: z.string(),
      operator: z.enum(['equals', 'contains', 'greater_than', 'less_than', 'exists']),
      value: z.any()
    }).optional()
  })),
  variables: z.array(z.object({
    name: z.string(),
    type: z.enum(['string', 'number', 'boolean', 'object']),
    default_value: z.any().optional(),
    description: z.string().optional()
  })).default([]),
  settings: z.object({
    timeout_minutes: z.number().min(1).max(1440).default(30),
    retry_attempts: z.number().min(0).max(10).default(3),
    error_handling: z.enum(['stop', 'continue', 'retry']).default('stop'),
    concurrent_executions: z.number().min(1).max(100).default(1)
  }).default({
    timeout_minutes: 30,
    retry_attempts: 3,
    error_handling: 'stop',
    concurrent_executions: 1
  })
});

const oauthAppSchema = z.object({
  name: z.string().min(1).max(100),
  description: z.string().max(500),
  provider: z.string(),
  category: z.enum(['productivity', 'development', 'marketing', 'hr', 'finance', 'communication', 'analytics']),
  logo_url: z.string().url(),
  website_url: z.string().url(),
  support_url: z.string().url().optional(),
  scopes: z.array(z.string()),
  redirect_uris: z.array(z.string().url()),
  webhook_endpoints: z.array(z.object({
    url: z.string().url(),
    events: z.array(z.string()),
    secret: z.string()
  })).default([]),
  is_public: z.boolean().default(false)
});

const installAppSchema = z.object({
  app_id: z.string(),
  config: z.record(z.any()).default({})
});

// Helper functions
function generateWorkflowId(): string {
  return `wf_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
}

function generateExecutionId(): string {
  return `exec_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
}

// API endpoints
export const getAdvancedWorkflows: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { status, category } = req.query;
    
    let filteredWorkflows = advancedWorkflows.filter(w => 
      w.workspace_id === "default" // In production, get from context
    );
    
    if (status) {
      filteredWorkflows = filteredWorkflows.filter(w => w.status === status);
    }
    
    res.json({
      success: true,
      data: filteredWorkflows
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get workflows"
    } as ApiResponse);
  }
};

export const createAdvancedWorkflow: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = advancedWorkflowSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid workflow data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const workflow: AdvancedWorkflow = {
      id: generateWorkflowId(),
      workspace_id: "default",
      ...validation.data,
      version: 1,
      status: 'draft',
      created_by: user.id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      last_run: "",
      total_runs: 0,
      success_rate: 0
    };

    advancedWorkflows.push(workflow);

    res.status(201).json({
      success: true,
      data: workflow
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create workflow"
    } as ApiResponse);
  }
};

export const updateAdvancedWorkflow: RequestHandler = (req, res) => {
  try {
    const { workflowId } = req.params;
    const user = (req as any).user as User;
    
    const workflowIndex = advancedWorkflows.findIndex(w => w.id === workflowId);
    if (workflowIndex === -1) {
      return res.status(404).json({
        success: false,
        error: "Workflow not found"
      } as ApiResponse);
    }

    const workflow = advancedWorkflows[workflowIndex];
    
    // Create new version for significant changes
    const isSignificantChange = req.body.nodes || req.body.edges;
    const newVersion = isSignificantChange ? workflow.version + 1 : workflow.version;

    advancedWorkflows[workflowIndex] = {
      ...workflow,
      ...req.body,
      version: newVersion,
      updated_at: new Date().toISOString()
    };

    res.json({
      success: true,
      data: advancedWorkflows[workflowIndex]
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to update workflow"
    } as ApiResponse);
  }
};

export const executeWorkflow: RequestHandler = async (req, res) => {
  try {
    const { workflowId } = req.params;
    const triggerData = req.body;
    
    const workflow = advancedWorkflows.find(w => w.id === workflowId);
    if (!workflow) {
      return res.status(404).json({
        success: false,
        error: "Workflow not found"
      } as ApiResponse);
    }

    if (workflow.status !== 'active') {
      return res.status(400).json({
        success: false,
        error: "Workflow is not active"
      } as ApiResponse);
    }

    const execution: WorkflowExecution = {
      id: generateExecutionId(),
      workflow_id: workflowId,
      trigger_data: triggerData,
      status: 'running',
      started_at: new Date().toISOString(),
      execution_log: [],
      metrics: {
        total_duration_ms: 0,
        nodes_executed: 0,
        data_transferred_bytes: 0
      }
    };

    workflowExecutions.push(execution);

    // Simulate workflow execution
    setTimeout(async () => {
      const executionIndex = workflowExecutions.findIndex(e => e.id === execution.id);
      if (executionIndex !== -1) {
        // Simulate node execution
        const startTime = Date.now();
        
        for (const node of workflow.nodes) {
          const nodeStartTime = Date.now();
          
          // Simulate processing time
          await new Promise(resolve => setTimeout(resolve, Math.random() * 1000));
          
          const logEntry = {
            node_id: node.id,
            timestamp: new Date().toISOString(),
            status: 'completed' as const,
            input_data: triggerData,
            output_data: { result: `Node ${node.name} executed successfully` },
            duration_ms: Date.now() - nodeStartTime
          };
          
          workflowExecutions[executionIndex].execution_log.push(logEntry);
          workflowExecutions[executionIndex].metrics.nodes_executed++;
        }
        
        workflowExecutions[executionIndex].status = 'completed';
        workflowExecutions[executionIndex].completed_at = new Date().toISOString();
        workflowExecutions[executionIndex].metrics.total_duration_ms = Date.now() - startTime;
        
        // Update workflow stats
        const workflowIndex = advancedWorkflows.findIndex(w => w.id === workflowId);
        if (workflowIndex !== -1) {
          advancedWorkflows[workflowIndex].total_runs++;
          advancedWorkflows[workflowIndex].last_run = new Date().toISOString();
          advancedWorkflows[workflowIndex].success_rate = 
            (advancedWorkflows[workflowIndex].success_rate * (advancedWorkflows[workflowIndex].total_runs - 1) + 100) / 
            advancedWorkflows[workflowIndex].total_runs;
        }
      }
    }, 100);

    res.status(202).json({
      success: true,
      data: execution,
      message: "Workflow execution started"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to execute workflow"
    } as ApiResponse);
  }
};

export const getWorkflowExecutions: RequestHandler = (req, res) => {
  try {
    const { workflowId } = req.params;
    const { status, limit = 50, offset = 0 } = req.query;
    
    let filteredExecutions = workflowExecutions.filter(e => e.workflow_id === workflowId);
    
    if (status) {
      filteredExecutions = filteredExecutions.filter(e => e.status === status);
    }
    
    // Sort by start time descending
    filteredExecutions.sort((a, b) => 
      new Date(b.started_at).getTime() - new Date(a.started_at).getTime()
    );
    
    const paginatedExecutions = filteredExecutions.slice(
      Number(offset), 
      Number(offset) + Number(limit)
    );
    
    res.json({
      success: true,
      data: {
        executions: paginatedExecutions,
        total: filteredExecutions.length,
        offset: Number(offset),
        limit: Number(limit)
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get workflow executions"
    } as ApiResponse);
  }
};

// OAuth App Directory endpoints
export const getOAuthApps: RequestHandler = (req, res) => {
  try {
    const { category, search, verified_only = 'false' } = req.query;
    
    let filteredApps = [...oauthApps];
    
    if (category) {
      filteredApps = filteredApps.filter(app => app.category === category);
    }
    
    if (search) {
      const searchLower = (search as string).toLowerCase();
      filteredApps = filteredApps.filter(app => 
        app.name.toLowerCase().includes(searchLower) ||
        app.description.toLowerCase().includes(searchLower)
      );
    }
    
    if (verified_only === 'true') {
      filteredApps = filteredApps.filter(app => app.is_verified);
    }
    
    // Sort by popularity
    filteredApps.sort((a, b) => b.install_count - a.install_count);
    
    res.json({
      success: true,
      data: filteredApps
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get OAuth apps"
    } as ApiResponse);
  }
};

export const createOAuthApp: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = oauthAppSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid app data",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const app: OAuthApp = {
      id: `app_${Date.now()}`,
      workspace_id: "default",
      ...validation.data,
      client_id: crypto.randomBytes(16).toString('hex'),
      client_secret: crypto.randomBytes(32).toString('hex'),
      is_verified: false,
      install_count: 0,
      rating: 0,
      reviews_count: 0,
      created_by: user.id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    oauthApps.push(app);

    res.status(201).json({
      success: true,
      data: app
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create OAuth app"
    } as ApiResponse);
  }
};

export const installApp: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = installAppSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid installation data"
      } as ApiResponse);
    }

    const { app_id, config } = validation.data;
    
    const app = oauthApps.find(a => a.id === app_id);
    if (!app) {
      return res.status(404).json({
        success: false,
        error: "App not found"
      } as ApiResponse);
    }

    // Check if already installed
    const existingInstallation = appInstallations.find(i => 
      i.app_id === app_id && 
      i.workspace_id === "default" && 
      i.status === 'active'
    );

    if (existingInstallation) {
      return res.status(400).json({
        success: false,
        error: "App is already installed"
      } as ApiResponse);
    }

    const installation: AppInstallation = {
      id: `install_${Date.now()}`,
      app_id,
      workspace_id: "default",
      user_id: user.id,
      access_token: crypto.randomBytes(32).toString('hex'),
      refresh_token: crypto.randomBytes(32).toString('hex'),
      expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      scopes: app.scopes,
      config,
      status: 'active',
      installed_at: new Date().toISOString()
    };

    appInstallations.push(installation);

    // Update app install count
    const appIndex = oauthApps.findIndex(a => a.id === app_id);
    if (appIndex !== -1) {
      oauthApps[appIndex].install_count++;
    }

    res.status(201).json({
      success: true,
      data: installation,
      message: "App installed successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to install app"
    } as ApiResponse);
  }
};

export const getIntegrationTemplates: RequestHandler = (req, res) => {
  try {
    const { category, difficulty, apps } = req.query;
    
    let filteredTemplates = [...integrationTemplates];
    
    if (category) {
      filteredTemplates = filteredTemplates.filter(t => t.category === category);
    }
    
    if (difficulty) {
      filteredTemplates = filteredTemplates.filter(t => t.difficulty === difficulty);
    }
    
    if (apps) {
      const requiredApps = (apps as string).split(',');
      filteredTemplates = filteredTemplates.filter(t => 
        requiredApps.every(app => t.apps.includes(app))
      );
    }
    
    // Sort by popularity
    filteredTemplates.sort((a, b) => b.popularity_score - a.popularity_score);
    
    res.json({
      success: true,
      data: filteredTemplates
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get integration templates"
    } as ApiResponse);
  }
};

export const createWorkflowFromTemplate: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { templateId } = req.params;
    const { name, config } = req.body;
    
    const template = integrationTemplates.find(t => t.id === templateId);
    if (!template) {
      return res.status(404).json({
        success: false,
        error: "Template not found"
      } as ApiResponse);
    }

    // Generate unique IDs for nodes and edges
    const nodes = template.workflow_template.nodes.map((node, index) => ({
      ...node,
      id: `node_${Date.now()}_${index}`,
      config: { ...node.config, ...config }
    }));

    const edges = template.workflow_template.edges.map((edge, index) => ({
      ...edge,
      id: `edge_${Date.now()}_${index}`,
      source: nodes.find((_, i) => i === template.workflow_template.nodes.findIndex(n => n.name === edge.source))?.id || edge.source,
      target: nodes.find((_, i) => i === template.workflow_template.nodes.findIndex(n => n.name === edge.target))?.id || edge.target
    }));

    const workflow: AdvancedWorkflow = {
      id: generateWorkflowId(),
      workspace_id: "default",
      name: name || `${template.name} - ${new Date().toLocaleDateString()}`,
      description: template.description,
      version: 1,
      status: 'draft',
      nodes,
      edges,
      variables: [],
      settings: {
        timeout_minutes: 30,
        retry_attempts: 3,
        error_handling: 'stop',
        concurrent_executions: 1
      },
      created_by: user.id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      last_run: "",
      total_runs: 0,
      success_rate: 0
    };

    advancedWorkflows.push(workflow);

    res.status(201).json({
      success: true,
      data: workflow,
      message: "Workflow created from template successfully"
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to create workflow from template"
    } as ApiResponse);
  }
};

export const getWorkflowAnalytics: RequestHandler = (req, res) => {
  try {
    const { workflowId } = req.params;
    const { period = '7d' } = req.query;
    
    const workflow = advancedWorkflows.find(w => w.id === workflowId);
    if (!workflow) {
      return res.status(404).json({
        success: false,
        error: "Workflow not found"
      } as ApiResponse);
    }

    const executions = workflowExecutions.filter(e => e.workflow_id === workflowId);
    
    // Calculate metrics
    const totalExecutions = executions.length;
    const successfulExecutions = executions.filter(e => e.status === 'completed').length;
    const failedExecutions = executions.filter(e => e.status === 'failed').length;
    const avgExecutionTime = executions.reduce((sum, e) => 
      sum + (e.metrics?.total_duration_ms || 0), 0) / totalExecutions;

    // Generate time series data (mock)
    const timeSeriesData = Array.from({ length: 7 }, (_, i) => ({
      date: new Date(Date.now() - (6 - i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      executions: Math.floor(Math.random() * 20),
      success_rate: 85 + Math.random() * 15,
      avg_duration_ms: avgExecutionTime + Math.random() * 1000
    }));

    const analytics = {
      workflow_id: workflowId,
      period,
      total_executions: totalExecutions,
      successful_executions: successfulExecutions,
      failed_executions: failedExecutions,
      success_rate: totalExecutions > 0 ? (successfulExecutions / totalExecutions) * 100 : 0,
      avg_execution_time_ms: avgExecutionTime,
      time_series: timeSeriesData,
      node_performance: workflow.nodes.map(node => ({
        node_id: node.id,
        node_name: node.name,
        executions: Math.floor(Math.random() * totalExecutions),
        avg_duration_ms: Math.random() * 5000,
        error_rate: Math.random() * 10
      }))
    };

    res.json({
      success: true,
      data: analytics
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to get workflow analytics"
    } as ApiResponse);
  }
};
