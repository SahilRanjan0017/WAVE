import { RequestHandler } from "express";
import { z } from "zod";
import { ApiResponse, User, Message } from "@shared/api";

interface SlashCommand {
  command: string;
  description: string;
  usage: string;
  handler: (user: User, args: string[], channelId: string) => Promise<any>;
}

// Mock database for reminders and polls
let reminders: Array<{
  id: string;
  user_id: string;
  channel_id: string;
  message: string;
  remind_at: Date;
  created_at: Date;
}> = [];

let polls: Array<{
  id: string;
  user_id: string;
  channel_id: string;
  question: string;
  options: string[];
  votes: Map<string, string>; // user_id -> option
  created_at: Date;
  expires_at?: Date;
}> = [];

// Command handlers
const helpCommand = async (user: User, args: string[], channelId: string) => {
  const helpText = `
**Available Slash Commands:**

\`/help\` - Show this help message
\`/remind\` - Set a reminder
  Usage: \`/remind me in 30 minutes to check the server\`
  Usage: \`/remind @user tomorrow at 9am about the meeting\`

\`/poll\` - Create a poll
  Usage: \`/poll "What should we have for lunch?" "Pizza" "Sushi" "Burgers"\`

\`/status\` - Update your status
  Usage: \`/status away\` or \`/status "In a meeting" :meeting:\`

\`/weather\` - Get weather information
  Usage: \`/weather San Francisco\`

\`/giphy\` - Search for GIFs
  Usage: \`/giphy excited\`

\`/shrug\` - Add a shrug emoticon
  Usage: \`/shrug\`

\`/tableflip\` - Add a table flip emoticon
  Usage: \`/tableflip\`
`;

  return {
    type: 'ephemeral',
    content: helpText
  };
};

const remindCommand = async (user: User, args: string[], channelId: string) => {
  const text = args.join(' ');
  
  // Parse reminder format: "me in 30 minutes to check the server"
  const patterns = [
    /^me in (\d+) (minutes?|hours?|days?) to (.+)$/i,
    /^me tomorrow at (\d+)(am|pm) to (.+)$/i,
    /^me at (\d+)(am|pm) to (.+)$/i
  ];

  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) {
      let remindAt = new Date();
      let message = '';

      if (pattern.toString().includes('minutes?|hours?|days?')) {
        const amount = parseInt(match[1]);
        const unit = match[2].toLowerCase();
        message = match[3];

        if (unit.startsWith('minute')) {
          remindAt.setMinutes(remindAt.getMinutes() + amount);
        } else if (unit.startsWith('hour')) {
          remindAt.setHours(remindAt.getHours() + amount);
        } else if (unit.startsWith('day')) {
          remindAt.setDate(remindAt.getDate() + amount);
        }
      }

      const reminder = {
        id: Date.now().toString(),
        user_id: user.id,
        channel_id: channelId,
        message,
        remind_at: remindAt,
        created_at: new Date()
      };

      reminders.push(reminder);

      // In a real app, set up actual reminder scheduling
      setTimeout(() => {
        // Send reminder message
        console.log(`Reminder for ${user.full_name}: ${message}`);
      }, remindAt.getTime() - Date.now());

      return {
        type: 'in_channel',
        content: `⏰ Reminder set for ${remindAt.toLocaleString()}: "${message}"`
      };
    }
  }

  return {
    type: 'ephemeral',
    content: 'Invalid reminder format. Try: `/remind me in 30 minutes to check the server`'
  };
};

const pollCommand = async (user: User, args: string[], channelId: string) => {
  const text = args.join(' ');
  
  // Parse poll format: "What should we have for lunch?" "Pizza" "Sushi" "Burgers"
  const matches = text.match(/"([^"]+)"/g);
  
  if (!matches || matches.length < 3) {
    return {
      type: 'ephemeral',
      content: 'Invalid poll format. Try: `/poll "Question?" "Option 1" "Option 2" "Option 3"`'
    };
  }

  const question = matches[0].slice(1, -1); // Remove quotes
  const options = matches.slice(1).map(opt => opt.slice(1, -1)); // Remove quotes

  const poll = {
    id: Date.now().toString(),
    user_id: user.id,
    channel_id: channelId,
    question,
    options,
    votes: new Map(),
    created_at: new Date()
  };

  polls.push(poll);

  let pollText = `📊 **${question}**\n\n`;
  options.forEach((option, index) => {
    const emoji = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'][index];
    pollText += `${emoji} ${option} (0 votes)\n`;
  });
  pollText += `\nReact with the number emoji to vote!`;

  return {
    type: 'in_channel',
    content: pollText,
    poll_id: poll.id
  };
};

const statusCommand = async (user: User, args: string[], channelId: string) => {
  const statusText = args.join(' ');
  
  // Parse status updates
  const emojiMatch = statusText.match(/:([^:]+):/);
  const emoji = emojiMatch ? emojiMatch[1] : '';
  const text = statusText.replace(/:([^:]+):/, '').trim();

  // In a real app, update user status in database
  return {
    type: 'in_channel',
    content: `${user.full_name} updated their status: ${emoji} ${text}`
  };
};

const weatherCommand = async (user: User, args: string[], channelId: string) => {
  const location = args.join(' ') || 'New York';
  
  // Mock weather data (in real app, call weather API)
  const weatherData = {
    location,
    temperature: Math.floor(Math.random() * 30) + 50,
    condition: ['Sunny', 'Cloudy', 'Rainy', 'Snowy'][Math.floor(Math.random() * 4)]
  };

  return {
    type: 'in_channel',
    content: `🌤️ Weather in ${weatherData.location}: ${weatherData.temperature}°F, ${weatherData.condition}`
  };
};

const giphyCommand = async (user: User, args: string[], channelId: string) => {
  const query = args.join(' ') || 'excited';
  
  // Mock Giphy response (in real app, call Giphy API)
  const mockGifUrl = `https://media.giphy.com/media/example/giphy.gif`;
  
  return {
    type: 'in_channel',
    content: `🎬 ${query}`,
    image_url: mockGifUrl
  };
};

const shrugCommand = async (user: User, args: string[], channelId: string) => {
  const text = args.length > 0 ? args.join(' ') + ' ' : '';
  return {
    type: 'in_channel',
    content: `${text}¯\\_(ツ)_/¯`
  };
};

const tableflipCommand = async (user: User, args: string[], channelId: string) => {
  return {
    type: 'in_channel',
    content: `(╯°□°)╯︵ ┻━┻`
  };
};

// Available slash commands
const commands: { [key: string]: SlashCommand } = {
  'help': {
    command: 'help',
    description: 'Show available commands',
    usage: '/help',
    handler: helpCommand
  },
  'remind': {
    command: 'remind',
    description: 'Set a reminder',
    usage: '/remind me in 30 minutes to check the server',
    handler: remindCommand
  },
  'poll': {
    command: 'poll',
    description: 'Create a poll',
    usage: '/poll "Question?" "Option 1" "Option 2"',
    handler: pollCommand
  },
  'status': {
    command: 'status',
    description: 'Update your status',
    usage: '/status away',
    handler: statusCommand
  },
  'weather': {
    command: 'weather',
    description: 'Get weather information',
    usage: '/weather San Francisco',
    handler: weatherCommand
  },
  'giphy': {
    command: 'giphy',
    description: 'Search for GIFs',
    usage: '/giphy excited',
    handler: giphyCommand
  },
  'shrug': {
    command: 'shrug',
    description: 'Add a shrug emoticon',
    usage: '/shrug',
    handler: shrugCommand
  },
  'tableflip': {
    command: 'tableflip',
    description: 'Add a table flip emoticon',
    usage: '/tableflip',
    handler: tableflipCommand
  }
};

// Validation schema
const executeCommandSchema = z.object({
  command: z.string(),
  args: z.array(z.string()),
  channel_id: z.string()
});

export const executeSlashCommand: RequestHandler = async (req, res) => {
  try {
    const user = (req as any).user as User;
    const validation = executeCommandSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid input",
        message: validation.error.errors[0].message
      } as ApiResponse);
    }

    const { command, args, channel_id } = validation.data;

    const slashCommand = commands[command.toLowerCase()];
    if (!slashCommand) {
      return res.status(404).json({
        success: false,
        error: `Unknown command: /${command}. Type /help for available commands.`
      } as ApiResponse);
    }

    const result = await slashCommand.handler(user, args, channel_id);

    // If it's an in_channel response, create a message
    if (result.type === 'in_channel') {
      const message: Message = {
        id: Date.now().toString(),
        sender_id: user.id,
        channel_id: channel_id,
        content: result.content,
        type: result.image_url ? 'image' : 'text',
        file_url: result.image_url,
        is_edited: false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        sender: user,
        reactions: []
      };

      // Broadcast message via WebSocket
      const wsManager = (req as any).app?.wsManager;
      if (wsManager) {
        wsManager.broadcastNewMessage(message);
      }

      return res.json({
        success: true,
        data: {
          type: 'message',
          message
        }
      } as ApiResponse);
    }

    // Ephemeral response (only visible to user)
    res.json({
      success: true,
      data: {
        type: 'ephemeral',
        content: result.content
      }
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const getAvailableCommands: RequestHandler = (req, res) => {
  try {
    const commandList = Object.values(commands).map(cmd => ({
      command: cmd.command,
      description: cmd.description,
      usage: cmd.usage
    }));

    res.json({
      success: true,
      data: commandList
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};

export const votePoll: RequestHandler = (req, res) => {
  try {
    const user = (req as any).user as User;
    const { pollId, option } = req.body;

    const poll = polls.find(p => p.id === pollId);
    if (!poll) {
      return res.status(404).json({
        success: false,
        error: "Poll not found"
      } as ApiResponse);
    }

    // Update vote
    poll.votes.set(user.id, option);

    // Calculate results
    const results = poll.options.map((opt, index) => {
      const votes = Array.from(poll.votes.values()).filter(vote => vote === opt).length;
      return { option: opt, votes, emoji: ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣'][index] };
    });

    // Broadcast poll update
    const wsManager = (req as any).app?.wsManager;
    if (wsManager) {
      wsManager.broadcastToChannel(poll.channel_id, {
        type: 'poll_update',
        data: {
          poll_id: pollId,
          results
        }
      });
    }

    res.json({
      success: true,
      data: results
    } as ApiResponse);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Internal server error"
    } as ApiResponse);
  }
};
