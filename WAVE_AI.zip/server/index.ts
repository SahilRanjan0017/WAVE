import express from "express";
import cors from "cors";
import path from "path";
import { handleDemo } from "./routes/demo";
import { login, signup, logout, getProfile, authenticateToken } from "./routes/auth";
import { sendMessage, getChannelMessages, getDirectMessages, editMessage, deleteMessage } from "./routes/messages";
import { getTodos, createTodo, updateTodo, deleteTodo } from "./routes/todos";
import { search, getSearchSuggestions } from "./routes/search";
import { addReaction, removeReaction, getMessageReactions } from "./routes/reactions";
import { getChannels, createChannel, joinChannel, leaveChannel, getChannelMembers, updateChannelTopic } from "./routes/channels";
import { uploadFile, downloadFile, getFileInfo, deleteFile, getUserFiles, serveFile } from "./routes/files";
import { createThreadReply, getThreadReplies, getMessageThread, getActiveThreads } from "./routes/threads";
import { executeSlashCommand, getAvailableCommands, votePoll } from "./routes/commands";
import { pinMessage, unpinMessage, getPinnedMessages, getPinnedCount, getUserBookmarks, addBookmark, removeBookmark } from "./routes/pins";
import { updateUserStatus, getUserStatus, clearUserStatus, getPredefinedStatuses, getOnlineUsers, setDoNotDisturb, updatePresence } from "./routes/status";
import { getUserNotifications, markNotificationRead, markAllNotificationsRead, getNotificationSettings, updateNotificationSettings, deleteNotification } from "./routes/notifications";
import { performAISearch, getSearchSuggestions as getAISearchSuggestions, getRecentSearches, saveSearch } from "./routes/ai-search";
import { getWorkflows, createWorkflow, updateWorkflow, deleteWorkflow, executeWorkflow, getWorkflowRuns, getWorkflowTemplates, toggleWorkflow } from "./routes/workflows";
import { getWorkspaceAnalytics, getSystemMetrics, getAllUsers, updateUserRole, suspendUser, getSecurityEvents, getAuditLog, exportData, getWorkspaceSettings, updateWorkspaceSettings, requireAdmin } from "./routes/admin";
import { getUserWorkspaces, createWorkspace, getWorkspaceDetails, updateWorkspace, deleteWorkspace, inviteMember, acceptInvitation, leaveWorkspace, updateMemberRole, removeMember, getWorkspaceInvitations, createInviteLink, joinWorkspaceByLink, requestToJoin, getJoinRequests, reviewJoinRequest, updateWorkspaceBranding, getWorkspaceBranding, getWorkspacePublicInfo } from "./routes/workspaces";
import { getWebhooks, createWebhook, updateWebhook, deleteWebhook, testWebhook, getWebhookDeliveries, getIntegrations, installIntegration, receiveWebhook } from "./routes/webhooks";
import { getCanvases, getCanvas, createCanvas, updateCanvas, deleteCanvas, addBlock, updateBlock, deleteBlock, getCanvasTemplates, addComment, getCanvasComments, getCanvasVersions } from "./routes/canvases";
import { getSSOProviders, createSSOProvider, updateSSOProvider, deleteSSOProvider, getSCIMConfiguration, createSCIMConfiguration, getRetentionPolicies, createRetentionPolicy, getSecurityPolicies, createSecurityPolicy, getAuditLogs, getComplianceReports, createComplianceReport, encryptWorkspaceData, requireAdminOrOwner } from "./routes/enterprise-security";
import { performFacetedSearch, getSearchFacets, getKnowledgeArticles, getKnowledgeArticle, createKnowledgeArticle, getKnowledgeCategories, createKnowledgeCategory, voteOnArticle } from "./routes/knowledge-management";
import { getAdvancedWorkflows, createAdvancedWorkflow, updateAdvancedWorkflow, executeWorkflow, getWorkflowExecutions, getOAuthApps, createOAuthApp, installApp, getIntegrationTemplates, createWorkflowFromTemplate, getWorkflowAnalytics } from "./routes/advanced-workflows";
import { getMeetingRooms, createMeetingRoom, startMeeting, endMeeting, getMeetingSessions, getVoiceClips, createVoiceClip, getMeetingTemplates, createMeetingTemplate, getMeetingAnalytics } from "./routes/media-meetings";
import { getNotificationRules, createNotificationRule, updateNotificationRule, getEnhancedNotifications, createEnhancedNotification, markNotificationRead, subscribeToPush, generateNotificationDigest, getNotificationDigests, getNotificationAnalytics } from "./routes/advanced-notifications";
import { getAccessibilitySettings, updateAccessibilitySettings, getLanguages, createLanguage, getTranslations, createTranslation, getThemes, createTheme, runAccessibilityAudit, getAccessibilityAudits } from "./routes/accessibility-i18n";
import { getStarredMessages, starMessage, unstarMessage, getSavedSearches, createSavedSearch, createBulkAction, getBulkActions, syncOfflineData, getOfflineData, getQuickActions, createQuickAction, getKeyboardShortcuts, createDataExport, getDataExports, getSmartFolders, createSmartFolder, getUXAnalytics } from "./routes/ux-power-features";
import { createDataSubjectRequest, getDataSubjectRequests, recordConsent, getConsentRecords, getBillingPlans, createSubscription, getSubscription, getInvoices, getComplianceFrameworks, exportUserData, deleteUserData } from "./routes/legal-privacy-billing";
import notesRouter from "./routes/notes";
import whiteboardsRouter from "./routes/whiteboards";
import supabaseApiRouter from "./supabase-api";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // Serve static files
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

  // Health check
  app.get("/api/ping", (_req, res) => {
    res.json({ message: "WAVE AI server running!" });
  });

  // Legacy demo route
  app.get("/api/demo", handleDemo);

  // Authentication routes
  app.post("/api/auth/login", login);
  app.post("/api/auth/signup", signup);
  app.post("/api/auth/logout", logout);
  app.get("/api/auth/profile", authenticateToken, getProfile);

  // Channel routes
  app.get("/api/channels", authenticateToken, getChannels);
  app.post("/api/channels", authenticateToken, createChannel);
  app.post("/api/channels/join", authenticateToken, joinChannel);
  app.delete("/api/channels/:channelId/leave", authenticateToken, leaveChannel);
  app.get("/api/channels/:channelId/members", authenticateToken, getChannelMembers);
  app.put("/api/channels/:channelId/topic", authenticateToken, updateChannelTopic);

  // Message routes
  app.post("/api/messages", authenticateToken, sendMessage);
  app.get("/api/messages/channel/:channelId", authenticateToken, getChannelMessages);
  app.get("/api/messages/direct/:userId", authenticateToken, getDirectMessages);
  app.put("/api/messages/:messageId", authenticateToken, editMessage);
  app.delete("/api/messages/:messageId", authenticateToken, deleteMessage);

  // Reaction routes
  app.post("/api/reactions", authenticateToken, addReaction);
  app.delete("/api/reactions", authenticateToken, removeReaction);
  app.get("/api/messages/:messageId/reactions", authenticateToken, getMessageReactions);

  // File routes
  app.post("/api/files/upload", authenticateToken, uploadFile);
  app.get("/api/files/download/:filename", downloadFile);
  app.get("/api/files/serve/:filename", serveFile);
  app.get("/api/files/:fileId", authenticateToken, getFileInfo);
  app.delete("/api/files/:fileId", authenticateToken, deleteFile);
  app.get("/api/files", authenticateToken, getUserFiles);

  // Todo routes
  app.get("/api/todos", authenticateToken, getTodos);
  app.post("/api/todos", authenticateToken, createTodo);
  app.put("/api/todos/:todoId", authenticateToken, updateTodo);
  app.delete("/api/todos/:todoId", authenticateToken, deleteTodo);

  // Search routes
  app.get("/api/search", authenticateToken, search);
  app.get("/api/search/suggestions", authenticateToken, getSearchSuggestions);

  // Thread routes
  app.post("/api/threads", authenticateToken, createThreadReply);
  app.get("/api/threads/:threadId/replies", authenticateToken, getThreadReplies);
  app.get("/api/messages/:messageId/thread", authenticateToken, getMessageThread);
  app.get("/api/channels/:channelId/threads", authenticateToken, getActiveThreads);

  // Slash command routes
  app.post("/api/commands/execute", authenticateToken, executeSlashCommand);
  app.get("/api/commands", authenticateToken, getAvailableCommands);
  app.post("/api/polls/vote", authenticateToken, votePoll);

  // Pin and bookmark routes
  app.post("/api/pins", authenticateToken, pinMessage);
  app.delete("/api/pins/:messageId", authenticateToken, unpinMessage);
  app.get("/api/channels/:channelId/pins", authenticateToken, getPinnedMessages);
  app.get("/api/channels/:channelId/pins/count", authenticateToken, getPinnedCount);
  app.get("/api/bookmarks", authenticateToken, getUserBookmarks);
  app.post("/api/bookmarks", authenticateToken, addBookmark);
  app.delete("/api/bookmarks/:bookmarkId", authenticateToken, removeBookmark);

  // User status and presence routes
  app.put("/api/status", authenticateToken, updateUserStatus);
  app.get("/api/status/:userId", authenticateToken, getUserStatus);
  app.delete("/api/status", authenticateToken, clearUserStatus);
  app.get("/api/status/predefined", authenticateToken, getPredefinedStatuses);
  app.get("/api/users/online", authenticateToken, getOnlineUsers);
  app.post("/api/status/dnd", authenticateToken, setDoNotDisturb);
  app.post("/api/presence", authenticateToken, updatePresence);

  // Notification routes
  app.get("/api/notifications", authenticateToken, getUserNotifications);
  app.put("/api/notifications/:notificationId/read", authenticateToken, markNotificationRead);
  app.put("/api/notifications/read-all", authenticateToken, markAllNotificationsRead);
  app.get("/api/notifications/settings", authenticateToken, getNotificationSettings);
  app.put("/api/notifications/settings", authenticateToken, updateNotificationSettings);
  app.delete("/api/notifications/:notificationId", authenticateToken, deleteNotification);

  // AI Search routes
  app.get("/api/ai-search", authenticateToken, performAISearch);
  app.get("/api/ai-search/suggestions", authenticateToken, getAISearchSuggestions);
  app.get("/api/ai-search/recent", authenticateToken, getRecentSearches);
  app.post("/api/ai-search/save", authenticateToken, saveSearch);

  // Workflow routes
  app.get("/api/workflows", authenticateToken, getWorkflows);
  app.post("/api/workflows", authenticateToken, createWorkflow);
  app.put("/api/workflows/:workflowId", authenticateToken, updateWorkflow);
  app.delete("/api/workflows/:workflowId", authenticateToken, deleteWorkflow);
  app.post("/api/workflows/:workflowId/execute", authenticateToken, executeWorkflow);
  app.get("/api/workflows/:workflowId/runs", authenticateToken, getWorkflowRuns);
  app.get("/api/workflows/templates", authenticateToken, getWorkflowTemplates);
  app.post("/api/workflows/:workflowId/toggle", authenticateToken, toggleWorkflow);

  // Admin routes (require admin permissions)
  app.get("/api/admin/analytics", authenticateToken, requireAdmin, getWorkspaceAnalytics);
  app.get("/api/admin/metrics", authenticateToken, requireAdmin, getSystemMetrics);
  app.get("/api/admin/users", authenticateToken, requireAdmin, getAllUsers);
  app.put("/api/admin/users/:userId/role", authenticateToken, requireAdmin, updateUserRole);
  app.post("/api/admin/users/:userId/suspend", authenticateToken, requireAdmin, suspendUser);
  app.get("/api/admin/security", authenticateToken, requireAdmin, getSecurityEvents);
  app.get("/api/admin/audit", authenticateToken, requireAdmin, getAuditLog);
  app.post("/api/admin/export", authenticateToken, requireAdmin, exportData);
  app.get("/api/admin/workspaces/:workspace_id/settings", authenticateToken, requireAdmin, getWorkspaceSettings);
  app.put("/api/admin/workspaces/:workspace_id/settings", authenticateToken, requireAdmin, updateWorkspaceSettings);

  // Multi-workspace routes
  app.get("/api/workspaces", authenticateToken, getUserWorkspaces);
  app.post("/api/workspaces", authenticateToken, createWorkspace);
  app.get("/api/workspaces/:workspaceId", authenticateToken, getWorkspaceDetails);
  app.put("/api/workspaces/:workspaceId", authenticateToken, updateWorkspace);
  app.delete("/api/workspaces/:workspaceId", authenticateToken, deleteWorkspace);
  app.post("/api/workspaces/:workspaceId/invite", authenticateToken, inviteMember);
  app.post("/api/workspaces/invitations/:invitationId/accept", authenticateToken, acceptInvitation);
  app.delete("/api/workspaces/:workspaceId/leave", authenticateToken, leaveWorkspace);

  // Enhanced workspace features
  app.post("/api/workspaces/:workspaceId/invite-link", authenticateToken, createInviteLink);
  app.post("/api/join/:linkToken", authenticateToken, joinWorkspaceByLink);
  app.post("/api/workspaces/join-request", authenticateToken, requestToJoin);
  app.get("/api/workspaces/:workspaceId/join-requests", authenticateToken, getJoinRequests);
  app.post("/api/workspaces/:workspaceId/join-requests/:requestId/review", authenticateToken, reviewJoinRequest);
  app.put("/api/workspaces/:workspaceId/branding", authenticateToken, updateWorkspaceBranding);
  app.get("/api/workspaces/:workspaceId/branding", getWorkspaceBranding);
  app.get("/api/workspaces/:workspaceId/public", getWorkspacePublicInfo);
  app.put("/api/workspaces/:workspaceId/members/:memberId/role", authenticateToken, updateMemberRole);
  app.delete("/api/workspaces/:workspaceId/members/:memberId", authenticateToken, removeMember);
  app.get("/api/workspaces/:workspaceId/invitations", authenticateToken, getWorkspaceInvitations);

  // Webhook and integration routes
  app.get("/api/webhooks", authenticateToken, getWebhooks);
  app.post("/api/webhooks", authenticateToken, createWebhook);
  app.put("/api/webhooks/:webhookId", authenticateToken, updateWebhook);
  app.delete("/api/webhooks/:webhookId", authenticateToken, deleteWebhook);
  app.post("/api/webhooks/:webhookId/test", authenticateToken, testWebhook);
  app.get("/api/webhooks/:webhookId/deliveries", authenticateToken, getWebhookDeliveries);
  app.get("/api/integrations", authenticateToken, getIntegrations);
  app.post("/api/integrations/:integrationId/install", authenticateToken, installIntegration);
  app.post("/api/webhooks/:webhookId/receive", receiveWebhook); // No auth required for incoming webhooks

  // Canvas and collaborative documents routes
  app.get("/api/canvases", authenticateToken, getCanvases);
  app.post("/api/canvases", authenticateToken, createCanvas);
  app.get("/api/canvases/templates", authenticateToken, getCanvasTemplates);
  app.get("/api/canvases/:canvasId", authenticateToken, getCanvas);
  app.put("/api/canvases/:canvasId", authenticateToken, updateCanvas);
  app.delete("/api/canvases/:canvasId", authenticateToken, deleteCanvas);
  app.post("/api/canvases/:canvasId/blocks", authenticateToken, addBlock);
  app.put("/api/canvases/:canvasId/blocks/:blockId", authenticateToken, updateBlock);
  app.delete("/api/canvases/:canvasId/blocks/:blockId", authenticateToken, deleteBlock);
  app.post("/api/canvases/:canvasId/comments", authenticateToken, addComment);
  app.get("/api/canvases/:canvasId/comments", authenticateToken, getCanvasComments);
  app.get("/api/canvases/:canvasId/versions", authenticateToken, getCanvasVersions);

  // Enterprise Security & Compliance routes (require admin access)
  app.get("/api/workspaces/:workspaceId/sso-providers", authenticateToken, requireAdminOrOwner, getSSOProviders);
  app.post("/api/workspaces/:workspaceId/sso-providers", authenticateToken, requireAdminOrOwner, createSSOProvider);
  app.put("/api/workspaces/:workspaceId/sso-providers/:providerId", authenticateToken, requireAdminOrOwner, updateSSOProvider);
  app.delete("/api/workspaces/:workspaceId/sso-providers/:providerId", authenticateToken, requireAdminOrOwner, deleteSSOProvider);

  app.get("/api/workspaces/:workspaceId/scim-config", authenticateToken, requireAdminOrOwner, getSCIMConfiguration);
  app.post("/api/workspaces/:workspaceId/scim-config", authenticateToken, requireAdminOrOwner, createSCIMConfiguration);

  app.get("/api/workspaces/:workspaceId/retention-policies", authenticateToken, requireAdminOrOwner, getRetentionPolicies);
  app.post("/api/workspaces/:workspaceId/retention-policies", authenticateToken, requireAdminOrOwner, createRetentionPolicy);

  app.get("/api/workspaces/:workspaceId/security-policies", authenticateToken, requireAdminOrOwner, getSecurityPolicies);
  app.post("/api/workspaces/:workspaceId/security-policies", authenticateToken, requireAdminOrOwner, createSecurityPolicy);

  app.get("/api/workspaces/:workspaceId/audit-logs", authenticateToken, requireAdminOrOwner, getAuditLogs);

  app.get("/api/workspaces/:workspaceId/compliance-reports", authenticateToken, requireAdminOrOwner, getComplianceReports);
  app.post("/api/workspaces/:workspaceId/compliance-reports", authenticateToken, requireAdminOrOwner, createComplianceReport);

  app.post("/api/workspaces/:workspaceId/encryption", authenticateToken, requireAdminOrOwner, encryptWorkspaceData);

  // Enhanced Search & Knowledge Management routes
  app.post("/api/search/faceted", authenticateToken, performFacetedSearch);
  app.get("/api/search/facets", authenticateToken, getSearchFacets);

  // Knowledge Base routes
  app.get("/api/knowledge/articles", authenticateToken, getKnowledgeArticles);
  app.post("/api/knowledge/articles", authenticateToken, createKnowledgeArticle);
  app.get("/api/knowledge/articles/:articleId", authenticateToken, getKnowledgeArticle);
  app.post("/api/knowledge/articles/:articleId/vote", authenticateToken, voteOnArticle);

  app.get("/api/knowledge/categories", authenticateToken, getKnowledgeCategories);
  app.post("/api/knowledge/categories", authenticateToken, createKnowledgeCategory);

  // Advanced Workflow & Automation routes
  app.get("/api/workflows/advanced", authenticateToken, getAdvancedWorkflows);
  app.post("/api/workflows/advanced", authenticateToken, createAdvancedWorkflow);
  app.put("/api/workflows/advanced/:workflowId", authenticateToken, updateAdvancedWorkflow);
  app.post("/api/workflows/advanced/:workflowId/execute", authenticateToken, executeWorkflow);
  app.get("/api/workflows/advanced/:workflowId/executions", authenticateToken, getWorkflowExecutions);
  app.get("/api/workflows/advanced/:workflowId/analytics", authenticateToken, getWorkflowAnalytics);

  // OAuth App Directory routes
  app.get("/api/oauth/apps", authenticateToken, getOAuthApps);
  app.post("/api/oauth/apps", authenticateToken, createOAuthApp);
  app.post("/api/oauth/apps/install", authenticateToken, installApp);

  // Integration Templates routes
  app.get("/api/integrations/templates", authenticateToken, getIntegrationTemplates);
  app.post("/api/integrations/templates/:templateId/create-workflow", authenticateToken, createWorkflowFromTemplate);

  // Enhanced Media & Meeting routes
  app.get("/api/meetings/rooms", authenticateToken, getMeetingRooms);
  app.post("/api/meetings/rooms", authenticateToken, createMeetingRoom);
  app.post("/api/meetings/rooms/:roomId/start", authenticateToken, startMeeting);
  app.post("/api/meetings/sessions/:sessionId/end", authenticateToken, endMeeting);
  app.get("/api/meetings/sessions", authenticateToken, getMeetingSessions);
  app.get("/api/meetings/rooms/:roomId/sessions", authenticateToken, getMeetingSessions);

  app.get("/api/voice-clips", authenticateToken, getVoiceClips);
  app.post("/api/voice-clips", authenticateToken, createVoiceClip);

  app.get("/api/meetings/templates", authenticateToken, getMeetingTemplates);
  app.post("/api/meetings/templates", authenticateToken, createMeetingTemplate);

  app.get("/api/meetings/analytics", authenticateToken, getMeetingAnalytics);

  // Advanced Notification Suite routes
  app.get("/api/notifications/rules", authenticateToken, getNotificationRules);
  app.post("/api/notifications/rules", authenticateToken, createNotificationRule);
  app.put("/api/notifications/rules/:ruleId", authenticateToken, updateNotificationRule);

  app.get("/api/notifications/enhanced", authenticateToken, getEnhancedNotifications);
  app.post("/api/notifications/enhanced", authenticateToken, createEnhancedNotification);
  app.put("/api/notifications/enhanced/:notificationId/read", authenticateToken, markNotificationRead);

  app.post("/api/notifications/push/subscribe", authenticateToken, subscribeToPush);

  app.post("/api/notifications/digest/generate", authenticateToken, generateNotificationDigest);
  app.get("/api/notifications/digest", authenticateToken, getNotificationDigests);

  app.get("/api/notifications/analytics", authenticateToken, getNotificationAnalytics);

  // Accessibility & Internationalization routes
  app.get("/api/accessibility/settings", authenticateToken, getAccessibilitySettings);
  app.put("/api/accessibility/settings", authenticateToken, updateAccessibilitySettings);

  app.get("/api/i18n/languages", authenticateToken, getLanguages);
  app.post("/api/i18n/languages", authenticateToken, createLanguage);

  app.get("/api/i18n/translations", authenticateToken, getTranslations);
  app.post("/api/i18n/translations", authenticateToken, createTranslation);

  app.get("/api/themes", authenticateToken, getThemes);
  app.post("/api/themes", authenticateToken, createTheme);

  app.post("/api/accessibility/audit", authenticateToken, runAccessibilityAudit);
  app.get("/api/accessibility/audits", authenticateToken, getAccessibilityAudits);

  // UX Polishing & Power-User Features routes
  app.get("/api/starred-messages", authenticateToken, getStarredMessages);
  app.post("/api/starred-messages", authenticateToken, starMessage);
  app.delete("/api/starred-messages/:messageId", authenticateToken, unstarMessage);

  app.get("/api/saved-searches", authenticateToken, getSavedSearches);
  app.post("/api/saved-searches", authenticateToken, createSavedSearch);

  app.post("/api/bulk-actions", authenticateToken, createBulkAction);
  app.get("/api/bulk-actions", authenticateToken, getBulkActions);

  app.post("/api/offline/sync", authenticateToken, syncOfflineData);
  app.get("/api/offline/data", authenticateToken, getOfflineData);

  app.get("/api/quick-actions", authenticateToken, getQuickActions);
  app.post("/api/quick-actions", authenticateToken, createQuickAction);

  app.get("/api/keyboard-shortcuts", authenticateToken, getKeyboardShortcuts);

  app.post("/api/data-exports", authenticateToken, createDataExport);
  app.get("/api/data-exports", authenticateToken, getDataExports);

  app.get("/api/smart-folders", authenticateToken, getSmartFolders);
  app.post("/api/smart-folders", authenticateToken, createSmartFolder);

  app.get("/api/ux-analytics", authenticateToken, getUXAnalytics);

  // Legal, Privacy & Billing routes
  app.post("/api/privacy/data-subject-request", authenticateToken, createDataSubjectRequest);
  app.get("/api/privacy/data-subject-requests", authenticateToken, getDataSubjectRequests);

  app.post("/api/privacy/consent", authenticateToken, recordConsent);
  app.get("/api/privacy/consent", authenticateToken, getConsentRecords);

  app.get("/api/billing/plans", getBillingPlans);
  app.post("/api/billing/subscription", authenticateToken, createSubscription);
  app.get("/api/billing/subscription", authenticateToken, getSubscription);
  app.get("/api/billing/invoices", authenticateToken, getInvoices);

  app.get("/api/compliance/frameworks", authenticateToken, getComplianceFrameworks);

  app.post("/api/privacy/export-data", authenticateToken, exportUserData);
  app.post("/api/privacy/delete-data", authenticateToken, deleteUserData);

  // Notes routes
  app.use("/api/notes", authenticateToken, notesRouter);

  // Whiteboards routes
  app.use("/api/whiteboards", authenticateToken, whiteboardsRouter);

  // Supabase API routes (with authentication middleware)
  app.use("/", authenticateToken, supabaseApiRouter);

  return app;
}
