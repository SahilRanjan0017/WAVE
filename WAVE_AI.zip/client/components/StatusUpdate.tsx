import React, { useState, useEffect } from 'react';
import { 
  Smile, 
  Clock, 
  Phone, 
  Home, 
  Coffee, 
  Car, 
  Plane,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useAuth } from '../contexts/AuthContext';

interface StatusOption {
  emoji: string;
  text: string;
  status: 'online' | 'away' | 'offline';
  duration?: number; // minutes
}

const predefinedStatuses: StatusOption[] = [
  { emoji: '🟢', text: 'Available', status: 'online' },
  { emoji: '🔴', text: 'Busy', status: 'away' },
  { emoji: '🟡', text: 'Away', status: 'away' },
  { emoji: '🏠', text: 'Working from home', status: 'online' },
  { emoji: '🍽️', text: 'Out for lunch', status: 'away', duration: 60 },
  { emoji: '📞', text: 'In a call', status: 'away' },
  { emoji: '🎯', text: 'Focusing', status: 'away', duration: 120 },
  { emoji: '🚌', text: 'Commuting', status: 'away', duration: 30 },
  { emoji: '🏝️', text: 'Vacationing', status: 'away' },
  { emoji: '🤒', text: 'Out sick', status: 'offline' },
];

const durationOptions = [
  { label: 'Don\'t clear', value: 0 },
  { label: '30 minutes', value: 30 },
  { label: '1 hour', value: 60 },
  { label: '4 hours', value: 240 },
  { label: 'Today', value: 24 * 60 },
  { label: 'This week', value: 7 * 24 * 60 },
];

interface StatusUpdateProps {
  currentStatus?: {
    status: 'online' | 'away' | 'offline';
    status_text?: string;
    status_emoji?: string;
    expires_at?: string;
  };
  onStatusUpdate?: (status: any) => void;
}

export default function StatusUpdate({ currentStatus, onStatusUpdate }: StatusUpdateProps) {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [customText, setCustomText] = useState('');
  const [customEmoji, setCustomEmoji] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<'online' | 'away' | 'offline'>('online');
  const [duration, setDuration] = useState(0);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  const commonEmojis = [
    '😀', '😃', '😄', '😁', '😊', '😍', '🤔', '😎', '🤯', '🥳',
    '🏠', '💼', '📞', '🍽️', '☕', '🚗', '✈️', '🏖️', '🎮', '📚',
    '💪', '🎯', '🔥', '⚡', '🌟', '🎉', '🚀', '💡', '🎵', '🎨'
  ];

  useEffect(() => {
    if (currentStatus) {
      setCustomText(currentStatus.status_text || '');
      setCustomEmoji(currentStatus.status_emoji || '');
      setSelectedStatus(currentStatus.status);
    }
  }, [currentStatus]);

  const updateStatus = async (statusData: any) => {
    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/status', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(statusData)
      });

      const data = await response.json();
      if (data.success) {
        onStatusUpdate?.(data.data);
        setIsOpen(false);
      }
    } catch (error) {
      console.error('Failed to update status:', error);
    }
  };

  const handlePredefinedStatus = (statusOption: StatusOption) => {
    const expiresAt = statusOption.duration 
      ? new Date(Date.now() + statusOption.duration * 60000).toISOString()
      : undefined;

    updateStatus({
      status: statusOption.status,
      status_text: statusOption.text,
      status_emoji: statusOption.emoji,
      expires_at: expiresAt
    });
  };

  const handleCustomStatus = () => {
    const expiresAt = duration > 0 
      ? new Date(Date.now() + duration * 60000).toISOString()
      : undefined;

    updateStatus({
      status: selectedStatus,
      status_text: customText,
      status_emoji: customEmoji,
      expires_at: expiresAt
    });
  };

  const clearStatus = async () => {
    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/status', {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      const data = await response.json();
      if (data.success) {
        onStatusUpdate?.(null);
        setIsOpen(false);
      }
    } catch (error) {
      console.error('Failed to clear status:', error);
    }
  };

  const setDoNotDisturb = async (minutes: number = 60) => {
    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/status/dnd', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ duration_minutes: minutes })
      });

      const data = await response.json();
      if (data.success) {
        onStatusUpdate?.(data.data);
        setIsOpen(false);
      }
    } catch (error) {
      console.error('Failed to set do not disturb:', error);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <button className="flex items-center space-x-2 px-2 py-1 rounded hover:bg-sidebar-accent/50 transition-colors">
          <div className="relative">
            <div className="w-3 h-3 rounded-full bg-status-online border border-sidebar-background" />
            {currentStatus?.status_emoji && (
              <span className="absolute -top-1 -right-1 text-xs">
                {currentStatus.status_emoji}
              </span>
            )}
          </div>
          <span className="text-sm text-sidebar-foreground">
            {currentStatus?.status_text || 'Set a status'}
          </span>
        </button>
      </DialogTrigger>
      
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Update your status</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Quick Status Options */}
          <div>
            <Label className="text-sm font-medium">Quick options</Label>
            <div className="grid grid-cols-1 gap-2 mt-2">
              {predefinedStatuses.slice(0, 6).map((status, index) => (
                <button
                  key={index}
                  onClick={() => handlePredefinedStatus(status)}
                  className="flex items-center space-x-3 p-3 rounded-lg border hover:bg-gray-50 transition-colors text-left"
                >
                  <span className="text-lg">{status.emoji}</span>
                  <div className="flex-1">
                    <span className="text-sm font-medium">{status.text}</span>
                    {status.duration && (
                      <span className="text-xs text-gray-500 ml-2">
                        ({status.duration}m)
                      </span>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Custom Status */}
          <div>
            <Label className="text-sm font-medium">Custom status</Label>
            <div className="flex items-center space-x-2 mt-2">
              <Popover open={showEmojiPicker} onOpenChange={setShowEmojiPicker}>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-12 h-10">
                    {customEmoji || '😀'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-64 p-2">
                  <div className="grid grid-cols-8 gap-1 max-h-48 overflow-y-auto">
                    {commonEmojis.map((emoji) => (
                      <button
                        key={emoji}
                        onClick={() => {
                          setCustomEmoji(emoji);
                          setShowEmojiPicker(false);
                        }}
                        className="p-1 hover:bg-gray-100 rounded text-lg"
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>
              
              <Input
                placeholder="What's your status?"
                value={customText}
                onChange={(e) => setCustomText(e.target.value)}
                className="flex-1"
              />
            </div>
          </div>

          {/* Status Type */}
          <div>
            <Label className="text-sm font-medium">Status</Label>
            <Select value={selectedStatus} onValueChange={(value: any) => setSelectedStatus(value)}>
              <SelectTrigger className="mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="online">🟢 Available</SelectItem>
                <SelectItem value="away">🟡 Away</SelectItem>
                <SelectItem value="offline">⚫ Offline</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Duration */}
          <div>
            <Label className="text-sm font-medium">Clear after</Label>
            <Select value={duration.toString()} onValueChange={(value) => setDuration(parseInt(value))}>
              <SelectTrigger className="mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {durationOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value.toString()}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Do Not Disturb */}
          <div className="border-t pt-4">
            <Label className="text-sm font-medium">Focus time</Label>
            <div className="flex space-x-2 mt-2">
              <Button
                variant="outline"
                onClick={() => setDoNotDisturb(30)}
                className="flex-1"
              >
                🔕 30m DND
              </Button>
              <Button
                variant="outline"
                onClick={() => setDoNotDisturb(60)}
                className="flex-1"
              >
                🔕 1h DND
              </Button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-2 pt-4">
            <Button
              onClick={handleCustomStatus}
              disabled={!customText.trim()}
              className="flex-1"
            >
              Update Status
            </Button>
            <Button
              variant="outline"
              onClick={clearStatus}
            >
              Clear
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
