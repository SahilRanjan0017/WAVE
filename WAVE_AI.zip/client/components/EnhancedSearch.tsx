import React, { useState, useEffect } from 'react';
import { Search, Filter, FileText, Users, Calendar, Tag, Zap, Brain, BookOpen, TrendingUp } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Label } from './ui/label';
import { Separator } from './ui/separator';

interface SearchResult {
  id: string;
  type: 'message' | 'file' | 'knowledge';
  title: string;
  content: string;
  author: string;
  channel: string;
  timestamp: string;
  relevance_score: number;
  highlights: string[];
}

interface SearchFacet {
  type: string;
  label: string;
  options: {
    value: string;
    label: string;
    count: number;
  }[];
}

interface SearchInsight {
  type: 'summary' | 'answer' | 'trend' | 'recommendation';
  title: string;
  content: string;
  confidence: number;
  sources: {
    id: string;
    type: string;
    title: string;
    url: string;
  }[];
}

interface SearchFilters {
  file_types?: string[];
  senders?: string[];
  channels?: string[];
  date_range?: {
    start: string;
    end: string;
  };
  message_types?: string[];
  has_attachments?: boolean;
  categories?: string[];
  tags?: string[];
}

export const EnhancedSearch: React.FC = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [facets, setFacets] = useState<SearchFacet[]>([]);
  const [insights, setInsights] = useState<SearchInsight[]>([]);
  const [filters, setFilters] = useState<SearchFilters>({});
  const [isLoading, setIsLoading] = useState(false);
  const [sortBy, setSortBy] = useState('relevance');
  const [showFilters, setShowFilters] = useState(false);
  const [total, setTotal] = useState(0);
  const [tookMs, setTookMs] = useState(0);

  const performSearch = async () => {
    if (!query.trim()) return;
    
    setIsLoading(true);
    try {
      const response = await fetch('/api/search/faceted', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({
          query,
          filters,
          sort_by: sortBy,
          limit: 20,
          offset: 0
        })
      });

      const data = await response.json();
      if (data.success) {
        setResults(data.data.results);
        setFacets(data.data.facets);
        setInsights(data.data.insights);
        setTotal(data.data.total);
        setTookMs(data.data.took_ms);
      }
    } catch (error) {
      console.error('Search failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFilterChange = (facetType: string, value: string, checked: boolean) => {
    setFilters(prev => {
      const newFilters = { ...prev };
      const key = facetType as keyof SearchFilters;
      
      if (!newFilters[key]) {
        newFilters[key] = [] as any;
      }
      
      if (checked) {
        (newFilters[key] as string[]).push(value);
      } else {
        newFilters[key] = (newFilters[key] as string[]).filter(v => v !== value);
      }
      
      return newFilters;
    });
  };

  const clearFilters = () => {
    setFilters({});
  };

  const getResultIcon = (type: string) => {
    switch (type) {
      case 'message':
        return <Users className="w-4 h-4" />;
      case 'file':
        return <FileText className="w-4 h-4" />;
      case 'knowledge':
        return <BookOpen className="w-4 h-4" />;
      default:
        return <Search className="w-4 h-4" />;
    }
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'summary':
        return <FileText className="w-4 h-4" />;
      case 'answer':
        return <Brain className="w-4 h-4" />;
      case 'trend':
        return <TrendingUp className="w-4 h-4" />;
      case 'recommendation':
        return <Zap className="w-4 h-4" />;
      default:
        return <Search className="w-4 h-4" />;
    }
  };

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (query.trim()) {
        performSearch();
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [query, filters, sortBy]);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Search Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Enhanced Search</h1>
          
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Search messages, files, and knowledge base..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-10 pr-4 py-3 text-lg"
            />
          </div>

          {/* Search Controls */}
          <div className="flex items-center justify-between mt-4">
            <div className="flex items-center gap-4">
              <Button
                variant={showFilters ? "default" : "outline"}
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center gap-2"
              >
                <Filter className="w-4 h-4" />
                Filters
                {Object.keys(filters).length > 0 && (
                  <Badge variant="secondary">{Object.keys(filters).length}</Badge>
                )}
              </Button>
              
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="relevance">Sort by Relevance</SelectItem>
                  <SelectItem value="date">Sort by Date</SelectItem>
                  <SelectItem value="popularity">Sort by Popularity</SelectItem>
                  <SelectItem value="views">Sort by Views</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {total > 0 && (
              <div className="text-sm text-gray-600">
                {total} results ({tookMs}ms)
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Filters Sidebar */}
          {showFilters && (
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Search Filters
                    <Button variant="ghost" size="sm" onClick={clearFilters}>
                      Clear
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {facets.map((facet) => (
                    <div key={facet.type}>
                      <Label className="text-sm font-medium">{facet.label}</Label>
                      <div className="mt-2 space-y-2">
                        {facet.options.slice(0, 8).map((option) => (
                          <div key={option.value} className="flex items-center space-x-2">
                            <Checkbox
                              id={`${facet.type}-${option.value}`}
                              checked={(filters[facet.type as keyof SearchFilters] as string[] || []).includes(option.value)}
                              onCheckedChange={(checked) => 
                                handleFilterChange(facet.type, option.value, checked as boolean)
                              }
                            />
                            <Label 
                              htmlFor={`${facet.type}-${option.value}`}
                              className="text-sm flex items-center justify-between w-full cursor-pointer"
                            >
                              <span>{option.label}</span>
                              <Badge variant="outline" className="text-xs">
                                {option.count}
                              </Badge>
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          )}

          {/* Main Content */}
          <div className={showFilters ? "lg:col-span-3" : "lg:col-span-4"}>
            {/* AI Insights */}
            {insights.length > 0 && (
              <div className="mb-6">
                <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Brain className="w-5 h-5" />
                  AI Insights
                </h2>
                <div className="grid gap-4">
                  {insights.map((insight, index) => (
                    <Card key={index} className="border-l-4 border-l-blue-500">
                      <CardHeader className="pb-2">
                        <CardTitle className="flex items-center gap-2 text-sm">
                          {getInsightIcon(insight.type)}
                          {insight.title}
                          <Badge variant="outline" className="text-xs">
                            {Math.round(insight.confidence * 100)}% confidence
                          </Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-700 mb-3">{insight.content}</p>
                        {insight.sources.length > 0 && (
                          <div className="flex flex-wrap gap-2">
                            {insight.sources.map((source, idx) => (
                              <Badge key={idx} variant="secondary" className="text-xs">
                                {source.title}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
                <Separator className="my-6" />
              </div>
            )}

            {/* Search Results */}
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
            ) : results.length > 0 ? (
              <div className="space-y-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <Search className="w-5 h-5" />
                  Search Results
                </h2>
                
                {results.map((result) => (
                  <Card key={result.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="flex-shrink-0 mt-1">
                          {getResultIcon(result.type)}
                        </div>
                        <div className="flex-grow min-w-0">
                          <h3 className="font-medium text-gray-900 mb-1">
                            {result.title}
                          </h3>
                          <p className="text-sm text-gray-600 mb-2 line-clamp-2">
                            {result.content}
                          </p>
                          
                          {result.highlights.length > 0 && (
                            <div className="mb-2">
                              {result.highlights.slice(0, 2).map((highlight, idx) => (
                                <p key={idx} className="text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded mb-1">
                                  ...{highlight}...
                                </p>
                              ))}
                            </div>
                          )}
                          
                          <div className="flex items-center gap-4 text-xs text-gray-500">
                            <span className="flex items-center gap-1">
                              <Users className="w-3 h-3" />
                              {result.author}
                            </span>
                            <span className="flex items-center gap-1">
                              <Tag className="w-3 h-3" />
                              #{result.channel}
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {new Date(result.timestamp).toLocaleDateString()}
                            </span>
                            <Badge variant="outline" className="text-xs">
                              {Math.round(result.relevance_score * 100)}% match
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : query.trim() ? (
              <div className="text-center py-12">
                <Search className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No results found</h3>
                <p className="text-gray-600">Try adjusting your search terms or filters</p>
              </div>
            ) : (
              <div className="text-center py-12">
                <Brain className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Enhanced Search</h3>
                <p className="text-gray-600">
                  Search across messages, files, and knowledge base with AI-powered insights
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnhancedSearch;
