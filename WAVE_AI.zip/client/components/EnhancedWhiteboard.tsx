import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  PenTool, 
  Save, 
  Undo, 
  Redo, 
  Trash2, 
  Circle, 
  Square, 
  MousePointer, 
  Type,
  Palette,
  Download,
  Upload,
  Users,
  Eye
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Slider } from '@/components/ui/slider';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

interface WhiteboardProps {
  channelId?: string;
  workspaceId: string;
  userId: string;
  onClose?: () => void;
}

interface DrawingPath {
  id: string;
  points: { x: number; y: number }[];
  color: string;
  width: number;
  tool: 'pen' | 'eraser';
}

interface WhiteboardData {
  paths: DrawingPath[];
  shapes: any[];
  texts: any[];
  version: number;
}

const TOOLS = [
  { id: 'select', icon: MousePointer, label: 'Select' },
  { id: 'pen', icon: PenTool, label: 'Pen' },
  { id: 'circle', icon: Circle, label: 'Circle' },
  { id: 'square', icon: Square, label: 'Rectangle' },
  { id: 'text', icon: Type, label: 'Text' }
];

const COLORS = [
  '#000000', '#FF0000', '#00FF00', '#0000FF', '#FFFF00', 
  '#FF00FF', '#00FFFF', '#FFA500', '#800080', '#008000'
];

export default function EnhancedWhiteboard({ channelId, workspaceId, userId, onClose }: WhiteboardProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [activeTool, setActiveTool] = useState('pen');
  const [strokeColor, setStrokeColor] = useState('#000000');
  const [strokeWidth, setStrokeWidth] = useState([3]);
  const [whiteboardData, setWhiteboardData] = useState<WhiteboardData>({
    paths: [],
    shapes: [],
    texts: [],
    version: 1
  });
  const [history, setHistory] = useState<WhiteboardData[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [whiteboardName, setWhiteboardName] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [savedWhiteboards, setSavedWhiteboards] = useState<any[]>([]);
  const [showLoadDialog, setShowLoadDialog] = useState(false);

  // Initialize canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    // Set default styles
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = strokeWidth[0];

    // Clear canvas with white background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Load saved whiteboards
    loadWhiteboards();
  }, []);

  // Redraw canvas when data changes
  useEffect(() => {
    redrawCanvas();
  }, [whiteboardData]);

  const loadWhiteboards = async () => {
    try {
      const params = new URLSearchParams();
      params.append('workspace_id', workspaceId);
      if (channelId) params.append('channel_id', channelId);

      const response = await fetch(`/api/whiteboards?${params}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });

      const data = await response.json();
      if (data.success) {
        setSavedWhiteboards(data.data || []);
      }
    } catch (error) {
      console.error('Failed to load whiteboards:', error);
    }
  };

  const redrawCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw all paths
    whiteboardData.paths.forEach(path => {
      if (path.points.length < 2) return;

      ctx.beginPath();
      ctx.strokeStyle = path.color;
      ctx.lineWidth = path.width;
      ctx.globalCompositeOperation = path.tool === 'eraser' ? 'destination-out' : 'source-over';

      ctx.moveTo(path.points[0].x, path.points[0].y);
      for (let i = 1; i < path.points.length; i++) {
        ctx.lineTo(path.points[i].x, path.points[i].y);
      }
      ctx.stroke();
    });

    // Reset composite operation
    ctx.globalCompositeOperation = 'source-over';
  };

  const getMousePos = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };

    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (activeTool !== 'pen') return;

    setIsDrawing(true);
    const pos = getMousePos(e);

    const newPath: DrawingPath = {
      id: `path-${Date.now()}`,
      points: [pos],
      color: strokeColor,
      width: strokeWidth[0],
      tool: 'pen'
    };

    setWhiteboardData(prev => ({
      ...prev,
      paths: [...prev.paths, newPath]
    }));
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || activeTool !== 'pen') return;

    const pos = getMousePos(e);
    
    setWhiteboardData(prev => {
      const newPaths = [...prev.paths];
      const currentPath = newPaths[newPaths.length - 1];
      if (currentPath) {
        currentPath.points.push(pos);
      }
      return {
        ...prev,
        paths: newPaths
      };
    });
  };

  const stopDrawing = () => {
    if (isDrawing) {
      setIsDrawing(false);
      saveToHistory();
    }
  };

  const saveToHistory = () => {
    setHistory(prev => {
      const newHistory = prev.slice(0, historyIndex + 1);
      newHistory.push({ ...whiteboardData });
      return newHistory.slice(-50); // Keep last 50 states
    });
    setHistoryIndex(prev => prev + 1);
  };

  const undo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(prev => prev - 1);
      setWhiteboardData(history[historyIndex - 1]);
    }
  };

  const redo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(prev => prev + 1);
      setWhiteboardData(history[historyIndex + 1]);
    }
  };

  const clearCanvas = () => {
    setWhiteboardData({
      paths: [],
      shapes: [],
      texts: [],
      version: whiteboardData.version + 1
    });
    saveToHistory();
  };

  const saveWhiteboard = async () => {
    if (!whiteboardName.trim()) {
      alert('Please enter a name for the whiteboard');
      return;
    }

    setIsSaving(true);
    try {
      // Convert canvas to thumbnail
      const canvas = canvasRef.current;
      const thumbnailUrl = canvas?.toDataURL('image/png');

      const payload = {
        workspace_id: workspaceId,
        channel_id: channelId,
        name: whiteboardName,
        description: `Whiteboard created on ${new Date().toLocaleDateString()}`,
        board_data: whiteboardData,
        thumbnail_url: thumbnailUrl,
        created_by: userId
      };

      const response = await fetch('/api/whiteboards', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify(payload)
      });

      const data = await response.json();
      if (data.success) {
        setShowSaveDialog(false);
        setWhiteboardName('');
        loadWhiteboards(); // Refresh the list
        alert('Whiteboard saved successfully!');
      } else {
        throw new Error(data.error || 'Failed to save whiteboard');
      }
    } catch (error) {
      console.error('Error saving whiteboard:', error);
      alert('Failed to save whiteboard. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const loadWhiteboard = (boardData: WhiteboardData) => {
    setWhiteboardData(boardData);
    saveToHistory();
    setShowLoadDialog(false);
  };

  const exportAsImage = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const link = document.createElement('a');
    link.download = `whiteboard-${Date.now()}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Toolbar */}
      <div className="flex items-center justify-between p-4 bg-white border-b">
        <div className="flex items-center space-x-2">
          {/* Tools */}
          <div className="flex items-center space-x-1 mr-4">
            {TOOLS.map(tool => (
              <Button
                key={tool.id}
                variant={activeTool === tool.id ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveTool(tool.id)}
                title={tool.label}
              >
                <tool.icon className="h-4 w-4" />
              </Button>
            ))}
          </div>

          {/* Colors */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="flex items-center gap-2">
                <Palette className="h-4 w-4" />
                <div 
                  className="w-4 h-4 rounded border"
                  style={{ backgroundColor: strokeColor }}
                />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-48">
              <div className="grid grid-cols-5 gap-2">
                {COLORS.map(color => (
                  <button
                    key={color}
                    className={`w-8 h-8 rounded border-2 ${strokeColor === color ? 'border-gray-600' : 'border-gray-300'}`}
                    style={{ backgroundColor: color }}
                    onClick={() => setStrokeColor(color)}
                  />
                ))}
              </div>
            </PopoverContent>
          </Popover>

          {/* Brush Size */}
          <div className="flex items-center space-x-2">
            <span className="text-sm">Size:</span>
            <div className="w-24">
              <Slider
                value={strokeWidth}
                onValueChange={setStrokeWidth}
                max={20}
                min={1}
                step={1}
              />
            </div>
            <span className="text-sm w-6">{strokeWidth[0]}</span>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {/* History */}
          <Button
            variant="outline"
            size="sm"
            onClick={undo}
            disabled={historyIndex <= 0}
            title="Undo"
          >
            <Undo className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={redo}
            disabled={historyIndex >= history.length - 1}
            title="Redo"
          >
            <Redo className="h-4 w-4" />
          </Button>

          {/* Actions */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowLoadDialog(true)}
            title="Load Whiteboard"
          >
            <Upload className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={exportAsImage}
            title="Export as Image"
          >
            <Download className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={clearCanvas}
            title="Clear Canvas"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            onClick={() => setShowSaveDialog(true)}
            title="Save to Database"
          >
            <Save className="h-4 w-4 mr-2" />
            Save to DB
          </Button>
        </div>
      </div>

      {/* Canvas */}
      <div className="flex-1 p-4">
        <div className="w-full h-full border-2 border-gray-300 rounded-lg overflow-hidden bg-white shadow-lg">
          <canvas
            ref={canvasRef}
            className="w-full h-full cursor-crosshair"
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
          />
        </div>
      </div>

      {/* Save Dialog */}
      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save Whiteboard to Database</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Whiteboard Name</label>
              <Input
                placeholder="Enter whiteboard name"
                value={whiteboardName}
                onChange={(e) => setWhiteboardName(e.target.value)}
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowSaveDialog(false)}>
                Cancel
              </Button>
              <Button onClick={saveWhiteboard} disabled={isSaving}>
                {isSaving ? 'Saving...' : 'Save to Database'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Load Dialog */}
      <Dialog open={showLoadDialog} onOpenChange={setShowLoadDialog}>
        <DialogContent className="max-w-4xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>Load Saved Whiteboards</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-96 overflow-y-auto">
            {savedWhiteboards.map((board) => (
              <Card key={board.id} className="cursor-pointer hover:shadow-lg transition-shadow">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">{board.name}</CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">v{board.version}</Badge>
                    <span className="text-xs text-muted-foreground">
                      {new Date(board.updated_at).toLocaleDateString()}
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  {board.thumbnail_url && (
                    <img 
                      src={board.thumbnail_url} 
                      alt={board.name}
                      className="w-full h-24 object-cover rounded border mb-2"
                    />
                  )}
                  <Button 
                    size="sm" 
                    className="w-full"
                    onClick={() => loadWhiteboard(board.board_data)}
                  >
                    <Eye className="h-4 w-4 mr-2" />
                    Load
                  </Button>
                </CardContent>
              </Card>
            ))}
            {savedWhiteboards.length === 0 && (
              <div className="col-span-full text-center py-8 text-muted-foreground">
                No saved whiteboards found. Create and save your first whiteboard!
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
