import React, { useState, useRef, useCallback } from 'react';
import { 
  Bold, 
  Italic, 
  Strikethrough, 
  Link, 
  List, 
  ListOrdered, 
  Code, 
  Quote,
  Smile,
  Paperclip,
  Send,
  AtSign,
  Hash
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
  placeholder?: string;
  disabled?: boolean;
  onTyping?: () => void;
  onStopTyping?: () => void;
  onFileUpload?: (file: File) => void;
}

const emojiList = [
  '😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇',
  '🙂', '🙃', '��', '😌', '😍', '🥰', '😘', '😗', '😙', '😚',
  '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🤩',
  '🥳', '😏', '😒', '😞', '😔', '😟', '😕', '🙁', '☹️', '😣',
  '😖', '😫', '😩', '🥺', '😢', '😭', '😤', '😠', '😡', '🤬',
  '👍', '👎', '👏', '🙌', '👐', '🤝', '🙏', '✨', '🎉', '🎊',
  '❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔',
  '💕', '💖', '💗', '💘', '💝', '💟', '❣️', '💯', '🔥', '⭐'
];

export default function RichTextEditor({
  value,
  onChange,
  onSend,
  placeholder = "Type a message...",
  disabled = false,
  onTyping,
  onStopTyping,
  onFileUpload
}: RichTextEditorProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [lastTypingTime, setLastTypingTime] = useState(0);

  const insertFormatting = useCallback((before: string, after: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = value.substring(start, end);
    
    const newText = value.substring(0, start) + before + selectedText + after + value.substring(end);
    onChange(newText);

    // Set cursor position after formatting
    setTimeout(() => {
      textarea.focus();
      const newCursorPos = start + before.length + selectedText.length;
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  }, [value, onChange]);

  const handleFormatClick = (format: string) => {
    switch (format) {
      case 'bold':
        insertFormatting('**', '**');
        break;
      case 'italic':
        insertFormatting('*', '*');
        break;
      case 'strikethrough':
        insertFormatting('~~', '~~');
        break;
      case 'code':
        insertFormatting('`', '`');
        break;
      case 'codeblock':
        insertFormatting('```\n', '\n```');
        break;
      case 'quote':
        insertFormatting('> ', '');
        break;
      case 'bullet':
        insertFormatting('• ', '');
        break;
      case 'numbered':
        insertFormatting('1. ', '');
        break;
      case 'link':
        insertFormatting('[', '](url)');
        break;
    }
  };

  const handleEmojiClick = (emoji: string) => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const newText = value.substring(0, start) + emoji + value.substring(start);
    onChange(newText);
    setShowEmojiPicker(false);

    // Set cursor position after emoji
    setTimeout(() => {
      textarea.focus();
      const newCursorPos = start + emoji.length;
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newValue = e.target.value;
    onChange(newValue);

    // Handle typing indicators
    const now = Date.now();
    if (onTyping && now - lastTypingTime > 1000) {
      onTyping();
      setLastTypingTime(now);
    }

    // Auto-resize textarea
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 150) + 'px';
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (value.trim() && !disabled) {
        onSend();
      }
    }

    // Handle keyboard shortcuts
    if (e.ctrlKey || e.metaKey) {
      switch (e.key) {
        case 'b':
          e.preventDefault();
          handleFormatClick('bold');
          break;
        case 'i':
          e.preventDefault();
          handleFormatClick('italic');
          break;
        case 'k':
          e.preventDefault();
          handleFormatClick('link');
          break;
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0] && onFileUpload) {
      onFileUpload(files[0]);
    }
    // Reset input value so same file can be selected again
    e.target.value = '';
  };

  const formatButtons = [
    { icon: Bold, label: 'Bold (Ctrl+B)', action: () => handleFormatClick('bold') },
    { icon: Italic, label: 'Italic (Ctrl+I)', action: () => handleFormatClick('italic') },
    { icon: Strikethrough, label: 'Strikethrough', action: () => handleFormatClick('strikethrough') },
    { icon: Link, label: 'Link (Ctrl+K)', action: () => handleFormatClick('link') },
    { icon: List, label: 'Bullet list', action: () => handleFormatClick('bullet') },
    { icon: ListOrdered, label: 'Numbered list', action: () => handleFormatClick('numbered') },
    { icon: Code, label: 'Inline code', action: () => handleFormatClick('code') },
    { icon: Quote, label: 'Quote', action: () => handleFormatClick('quote') }
  ];

  return (
    <div className="border border-editor-border rounded-lg bg-editor overflow-hidden">
      {/* Formatting Toolbar */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-editor-border">
        <div className="flex items-center space-x-1">
          {formatButtons.map((button) => (
            <Button
              key={button.label}
              variant="ghost"
              size="sm"
              className="h-7 w-7 p-0 text-gray-600 hover:text-gray-900 hover:bg-gray-100"
              onClick={button.action}
              title={button.label}
              disabled={disabled}
            >
              <button.icon className="h-3.5 w-3.5" />
            </Button>
          ))}
        </div>
      </div>

      {/* Text Input */}
      <div className="p-4">
        <textarea
          ref={textareaRef}
          value={value}
          onChange={handleTextChange}
          onKeyDown={handleKeyDown}
          onBlur={onStopTyping}
          placeholder={placeholder}
          disabled={disabled}
          className="w-full min-h-[100px] max-h-[150px] resize-none border-0 outline-none text-gray-900 placeholder-gray-500 text-sm"
          style={{ background: 'transparent' }}
        />
      </div>

      {/* Bottom Toolbar */}
      <div className="flex items-center justify-between px-4 py-2 border-t border-editor-border">
        <div className="flex items-center space-x-1">
          {/* File Upload */}
          <Button
            variant="ghost"
            size="sm"
            className="h-7 w-7 p-0 text-gray-600 hover:text-gray-900 hover:bg-gray-100"
            onClick={() => fileInputRef.current?.click()}
            title="Attach file"
            disabled={disabled}
          >
            <Paperclip className="h-3.5 w-3.5" />
          </Button>

          {/* Emoji Picker */}
          <Popover open={showEmojiPicker} onOpenChange={setShowEmojiPicker}>
            <PopoverTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 w-7 p-0 text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                title="Add emoji"
                disabled={disabled}
              >
                <Smile className="h-3.5 w-3.5" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-64 p-2">
              <div className="grid grid-cols-8 gap-1 max-h-48 overflow-y-auto">
                {emojiList.map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => handleEmojiClick(emoji)}
                    className="p-1 hover:bg-gray-100 rounded text-lg"
                    title={emoji}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </PopoverContent>
          </Popover>

          {/* Mention */}
          <Button
            variant="ghost"
            size="sm"
            className="h-7 w-7 p-0 text-gray-600 hover:text-gray-900 hover:bg-gray-100"
            onClick={() => insertFormatting('@', '')}
            title="Mention someone"
            disabled={disabled}
          >
            <AtSign className="h-3.5 w-3.5" />
          </Button>

          {/* Channel Reference */}
          <Button
            variant="ghost"
            size="sm"
            className="h-7 w-7 p-0 text-gray-600 hover:text-gray-900 hover:bg-gray-100"
            onClick={() => insertFormatting('#', '')}
            title="Reference channel"
            disabled={disabled}
          >
            <Hash className="h-3.5 w-3.5" />
          </Button>
        </div>

        <Button
          onClick={onSend}
          disabled={!value.trim() || disabled}
          className={`h-8 w-8 p-0 rounded-md ${
            value.trim() && !disabled
              ? 'bg-green-600 hover:bg-green-700 text-white' 
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          <Send className="h-4 w-4" />
        </Button>
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        onChange={handleFileSelect}
        className="hidden"
        accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.txt"
      />
    </div>
  );
}
