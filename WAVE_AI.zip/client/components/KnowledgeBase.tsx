import React, { useState, useEffect } from 'react';
import { BookOpen, Plus, Search, Filter, Tag, User, Calendar, Eye, ThumbsUp, ThumbsDown, Edit, Archive, Star } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Separator } from './ui/separator';

interface KnowledgeArticle {
  id: string;
  workspace_id: string;
  title: string;
  content: string;
  summary: string;
  tags: string[];
  category: string;
  author_id: string;
  created_at: string;
  updated_at: string;
  version: number;
  status: 'draft' | 'published' | 'archived';
  views: number;
  helpful_votes: number;
  not_helpful_votes: number;
  related_articles: string[];
}

interface KnowledgeCategory {
  id: string;
  workspace_id: string;
  name: string;
  description: string;
  parent_id?: string;
  icon: string;
  color: string;
  article_count: number;
  created_at: string;
}

export const KnowledgeBase: React.FC = () => {
  const [articles, setArticles] = useState<KnowledgeArticle[]>([]);
  const [categories, setCategories] = useState<KnowledgeCategory[]>([]);
  const [selectedArticle, setSelectedArticle] = useState<KnowledgeArticle | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newArticle, setNewArticle] = useState({
    title: '',
    content: '',
    summary: '',
    tags: '',
    category: '',
    status: 'draft' as const
  });

  useEffect(() => {
    fetchArticles();
    fetchCategories();
  }, [selectedCategory]);

  const fetchArticles = async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedCategory !== 'all') {
        params.append('category', selectedCategory);
      }
      
      const response = await fetch(`/api/knowledge/articles?${params}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });
      
      const data = await response.json();
      if (data.success) {
        setArticles(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch articles:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await fetch('/api/knowledge/categories', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });
      
      const data = await response.json();
      if (data.success) {
        setCategories(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch categories:', error);
    }
  };

  const createArticle = async () => {
    try {
      const response = await fetch('/api/knowledge/articles', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({
          ...newArticle,
          tags: newArticle.tags.split(',').map(tag => tag.trim()).filter(Boolean)
        })
      });

      const data = await response.json();
      if (data.success) {
        setArticles(prev => [data.data, ...prev]);
        setShowCreateDialog(false);
        setNewArticle({
          title: '',
          content: '',
          summary: '',
          tags: '',
          category: '',
          status: 'draft'
        });
      }
    } catch (error) {
      console.error('Failed to create article:', error);
    }
  };

  const voteOnArticle = async (articleId: string, helpful: boolean) => {
    try {
      await fetch(`/api/knowledge/articles/${articleId}/vote`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({ helpful })
      });

      // Update local state
      setArticles(prev => prev.map(article => 
        article.id === articleId 
          ? {
              ...article,
              helpful_votes: helpful ? article.helpful_votes + 1 : article.helpful_votes,
              not_helpful_votes: !helpful ? article.not_helpful_votes + 1 : article.not_helpful_votes
            }
          : article
      ));
    } catch (error) {
      console.error('Failed to vote on article:', error);
    }
  };

  const filteredArticles = articles.filter(article =>
    article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    article.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
    article.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const popularArticles = [...articles]
    .sort((a, b) => b.views - a.views)
    .slice(0, 5);

  const recentArticles = [...articles]
    .sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime())
    .slice(0, 5);

  const getCategoryIcon = (icon: string) => {
    return <span className="text-lg">{icon}</span>;
  };

  const formatContent = (content: string) => {
    // Simple markdown-like formatting
    return content
      .replace(/^# (.*$)/gim, '<h1 class="text-2xl font-bold mb-4">$1</h1>')
      .replace(/^## (.*$)/gim, '<h2 class="text-xl font-semibold mb-3">$1</h2>')
      .replace(/^### (.*$)/gim, '<h3 class="text-lg font-medium mb-2">$1</h3>')
      .replace(/^\* (.*$)/gim, '<li class="ml-4">• $1</li>')
      .replace(/\n/g, '<br />');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <BookOpen className="w-8 h-8" />
                Knowledge Base
              </h1>
              <p className="text-gray-600 mt-1">
                Discover guides, documentation, and answers to common questions
              </p>
            </div>
            
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button className="flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  Create Article
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Create New Article</DialogTitle>
                  <DialogDescription>
                    Share knowledge with your team by creating a helpful article
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title">Title</Label>
                    <Input
                      id="title"
                      value={newArticle.title}
                      onChange={(e) => setNewArticle(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Enter article title..."
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="summary">Summary</Label>
                    <Textarea
                      id="summary"
                      value={newArticle.summary}
                      onChange={(e) => setNewArticle(prev => ({ ...prev, summary: e.target.value }))}
                      placeholder="Brief summary of the article..."
                      rows={2}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="category">Category</Label>
                      <Select
                        value={newArticle.category}
                        onValueChange={(value) => setNewArticle(prev => ({ ...prev, category: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map(category => (
                            <SelectItem key={category.id} value={category.id}>
                              {category.icon} {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="status">Status</Label>
                      <Select
                        value={newArticle.status}
                        onValueChange={(value: 'draft' | 'published') => 
                          setNewArticle(prev => ({ ...prev, status: value }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="draft">Draft</SelectItem>
                          <SelectItem value="published">Published</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="tags">Tags (comma-separated)</Label>
                    <Input
                      id="tags"
                      value={newArticle.tags}
                      onChange={(e) => setNewArticle(prev => ({ ...prev, tags: e.target.value }))}
                      placeholder="getting-started, guide, tutorial"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="content">Content</Label>
                    <Textarea
                      id="content"
                      value={newArticle.content}
                      onChange={(e) => setNewArticle(prev => ({ ...prev, content: e.target.value }))}
                      placeholder="Write your article content here... (Supports basic markdown)"
                      rows={10}
                    />
                  </div>
                  
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                      Cancel
                    </Button>
                    <Button onClick={createArticle}>
                      Create Article
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Search */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Search Articles</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search knowledge base..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Categories */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Categories</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant={selectedCategory === 'all' ? 'default' : 'ghost'}
                  onClick={() => setSelectedCategory('all')}
                  className="w-full justify-start"
                >
                  All Articles ({articles.length})
                </Button>
                {categories.map(category => (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? 'default' : 'ghost'}
                    onClick={() => setSelectedCategory(category.id)}
                    className="w-full justify-start"
                  >
                    {getCategoryIcon(category.icon)}
                    <span className="ml-2">{category.name}</span>
                    <Badge variant="outline" className="ml-auto">
                      {category.article_count}
                    </Badge>
                  </Button>
                ))}
              </CardContent>
            </Card>

            {/* Popular Articles */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <Star className="w-4 h-4" />
                  Popular Articles
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {popularArticles.map(article => (
                  <div
                    key={article.id}
                    className="cursor-pointer hover:bg-gray-50 p-2 rounded"
                    onClick={() => setSelectedArticle(article)}
                  >
                    <p className="text-sm font-medium line-clamp-2">{article.title}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-500 mt-1">
                      <Eye className="w-3 h-3" />
                      {article.views} views
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {selectedArticle ? (
              /* Article View */
              <Card>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-grow">
                      <CardTitle className="text-2xl mb-2">{selectedArticle.title}</CardTitle>
                      <CardDescription className="text-base mb-4">
                        {selectedArticle.summary}
                      </CardDescription>
                      
                      <div className="flex items-center gap-4 text-sm text-gray-600 mb-4">
                        <span className="flex items-center gap-1">
                          <User className="w-4 h-4" />
                          Author ID: {selectedArticle.author_id}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {new Date(selectedArticle.updated_at).toLocaleDateString()}
                        </span>
                        <span className="flex items-center gap-1">
                          <Eye className="w-4 h-4" />
                          {selectedArticle.views} views
                        </span>
                      </div>
                      
                      <div className="flex flex-wrap gap-2 mb-4">
                        {selectedArticle.tags.map(tag => (
                          <Badge key={tag} variant="secondary">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <Button variant="outline" onClick={() => setSelectedArticle(null)}>
                      Back to Articles
                    </Button>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <div 
                    className="prose max-w-none mb-6"
                    dangerouslySetInnerHTML={{ 
                      __html: formatContent(selectedArticle.content) 
                    }}
                  />
                  
                  <Separator className="my-6" />
                  
                  {/* Article Feedback */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <span className="text-sm text-gray-600">Was this helpful?</span>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => voteOnArticle(selectedArticle.id, true)}
                          className="flex items-center gap-1"
                        >
                          <ThumbsUp className="w-4 h-4" />
                          {selectedArticle.helpful_votes}
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => voteOnArticle(selectedArticle.id, false)}
                          className="flex items-center gap-1"
                        >
                          <ThumbsDown className="w-4 h-4" />
                          {selectedArticle.not_helpful_votes}
                        </Button>
                      </div>
                    </div>
                    
                    <Badge variant="outline">
                      Version {selectedArticle.version}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ) : (
              /* Articles List */
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold">
                    {selectedCategory === 'all' ? 'All Articles' : 
                     categories.find(c => c.id === selectedCategory)?.name || 'Articles'}
                  </h2>
                  <div className="text-sm text-gray-600">
                    {filteredArticles.length} articles
                  </div>
                </div>

                {isLoading ? (
                  <div className="flex justify-center py-12">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                  </div>
                ) : filteredArticles.length > 0 ? (
                  <div className="grid gap-4">
                    {filteredArticles.map(article => (
                      <Card
                        key={article.id}
                        className="hover:shadow-md transition-shadow cursor-pointer"
                        onClick={() => setSelectedArticle(article)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-grow">
                              <h3 className="font-semibold text-lg mb-2">{article.title}</h3>
                              <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                                {article.summary}
                              </p>
                              
                              <div className="flex flex-wrap gap-2 mb-3">
                                {article.tags.slice(0, 3).map(tag => (
                                  <Badge key={tag} variant="outline" className="text-xs">
                                    {tag}
                                  </Badge>
                                ))}
                                {article.tags.length > 3 && (
                                  <Badge variant="outline" className="text-xs">
                                    +{article.tags.length - 3} more
                                  </Badge>
                                )}
                              </div>
                              
                              <div className="flex items-center gap-4 text-xs text-gray-500">
                                <span className="flex items-center gap-1">
                                  <Calendar className="w-3 h-3" />
                                  {new Date(article.updated_at).toLocaleDateString()}
                                </span>
                                <span className="flex items-center gap-1">
                                  <Eye className="w-3 h-3" />
                                  {article.views} views
                                </span>
                                <span className="flex items-center gap-1">
                                  <ThumbsUp className="w-3 h-3" />
                                  {article.helpful_votes}
                                </span>
                              </div>
                            </div>
                            
                            <Badge
                              variant={article.status === 'published' ? 'default' : 'secondary'}
                              className="ml-4"
                            >
                              {article.status}
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <BookOpen className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No articles found</h3>
                    <p className="text-gray-600 mb-4">
                      {searchQuery ? 'Try adjusting your search terms' : 'Be the first to create an article in this category'}
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default KnowledgeBase;
