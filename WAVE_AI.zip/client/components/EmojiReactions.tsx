import React, { useState } from 'react';
import { Plus, Smile } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { EmojiReactionSummary } from '@shared/api';

interface EmojiReactionsProps {
  messageId: string;
  reactions: EmojiReactionSummary[];
  onAddReaction: (emoji: string, emojiName: string) => void;
  onRemoveReaction: (emoji: string) => void;
  disabled?: boolean;
}

const quickReactions = [
  { emoji: '👍', name: 'thumbs_up' },
  { emoji: '❤️', name: 'heart' },
  { emoji: '😂', name: 'laughing' },
  { emoji: '😮', name: 'surprised' },
  { emoji: '😢', name: 'cry' },
  { emoji: '😡', name: 'angry' },
  { emoji: '👏', name: 'clap' },
  { emoji: '🎉', name: 'party' }
];

const allEmojis = [
  // Smileys & Emotion
  { emoji: '😀', name: 'grinning' },
  { emoji: '😃', name: 'smiley' },
  { emoji: '😄', name: 'smile' },
  { emoji: '😁', name: 'grin' },
  { emoji: '😆', name: 'laughing' },
  { emoji: '😅', name: 'sweat_smile' },
  { emoji: '😂', name: 'joy' },
  { emoji: '🤣', name: 'rofl' },
  { emoji: '😊', name: 'blush' },
  { emoji: '😇', name: 'innocent' },
  { emoji: '🙂', name: 'slightly_smiling_face' },
  { emoji: '🙃', name: 'upside_down_face' },
  { emoji: '😉', name: 'wink' },
  { emoji: '😌', name: 'relieved' },
  { emoji: '😍', name: 'heart_eyes' },
  { emoji: '🥰', name: 'smiling_face_with_hearts' },
  { emoji: '😘', name: 'kissing_heart' },
  { emoji: '😗', name: 'kissing' },
  { emoji: '☺️', name: 'relaxed' },
  { emoji: '😚', name: 'kissing_closed_eyes' },
  { emoji: '😙', name: 'kissing_smiling_eyes' },
  { emoji: '😋', name: 'yum' },
  { emoji: '😛', name: 'stuck_out_tongue' },
  { emoji: '😜', name: 'stuck_out_tongue_winking_eye' },
  { emoji: '🤪', name: 'zany_face' },
  { emoji: '😝', name: 'stuck_out_tongue_closed_eyes' },
  { emoji: '🤑', name: 'money_mouth_face' },
  { emoji: '���', name: 'hugs' },
  { emoji: '🤭', name: 'hand_over_mouth' },
  { emoji: '🤫', name: 'shushing_face' },
  { emoji: '🤔', name: 'thinking' },
  { emoji: '🤐', name: 'zipper_mouth_face' },
  { emoji: '🤨', name: 'raised_eyebrow' },
  { emoji: '😐', name: 'neutral_face' },
  { emoji: '😑', name: 'expressionless' },
  { emoji: '😶', name: 'no_mouth' },
  { emoji: '😏', name: 'smirk' },
  { emoji: '😒', name: 'unamused' },
  { emoji: '🙄', name: 'roll_eyes' },
  { emoji: '😬', name: 'grimacing' },
  { emoji: '🤥', name: 'lying_face' },
  
  // Gestures & Body Parts
  { emoji: '👍', name: 'thumbs_up' },
  { emoji: '👎', name: 'thumbs_down' },
  { emoji: '👌', name: 'ok_hand' },
  { emoji: '✌️', name: 'victory_hand' },
  { emoji: '🤞', name: 'crossed_fingers' },
  { emoji: '🤟', name: 'love_you_gesture' },
  { emoji: '🤘', name: 'sign_of_horns' },
  { emoji: '🤙', name: 'call_me_hand' },
  { emoji: '👈', name: 'point_left' },
  { emoji: '👉', name: 'point_right' },
  { emoji: '👆', name: 'point_up_2' },
  { emoji: '🖕', name: 'middle_finger' },
  { emoji: '👇', name: 'point_down' },
  { emoji: '☝️', name: 'point_up' },
  { emoji: '👏', name: 'clap' },
  { emoji: '🙌', name: 'raised_hands' },
  { emoji: '👐', name: 'open_hands' },
  { emoji: '🤲', name: 'palms_up_together' },
  { emoji: '🤝', name: 'handshake' },
  { emoji: '🙏', name: 'pray' },
  
  // Hearts & Symbols
  { emoji: '❤️', name: 'heart' },
  { emoji: '🧡', name: 'orange_heart' },
  { emoji: '💛', name: 'yellow_heart' },
  { emoji: '💚', name: 'green_heart' },
  { emoji: '💙', name: 'blue_heart' },
  { emoji: '💜', name: 'purple_heart' },
  { emoji: '🖤', name: 'black_heart' },
  { emoji: '🤍', name: 'white_heart' },
  { emoji: '🤎', name: 'brown_heart' },
  { emoji: '💔', name: 'broken_heart' },
  { emoji: '❣️', name: 'heavy_heart_exclamation' },
  { emoji: '💕', name: 'two_hearts' },
  { emoji: '💞', name: 'revolving_hearts' },
  { emoji: '💓', name: 'heartbeat' },
  { emoji: '💗', name: 'heartpulse' },
  { emoji: '💖', name: 'sparkling_heart' },
  { emoji: '💘', name: 'cupid' },
  { emoji: '💝', name: 'gift_heart' },
  
  // Celebration & Objects
  { emoji: '🎉', name: 'party' },
  { emoji: '🎊', name: 'confetti_ball' },
  { emoji: '🎈', name: 'balloon' },
  { emoji: '🎁', name: 'gift' },
  { emoji: '🎀', name: 'ribbon' },
  { emoji: '🎂', name: 'birthday' },
  { emoji: '🍰', name: 'cake' },
  { emoji: '🧁', name: 'cupcake' },
  { emoji: '🔥', name: 'fire' },
  { emoji: '⭐', name: 'star' },
  { emoji: '✨', name: 'sparkles' },
  { emoji: '💫', name: 'dizzy' },
  { emoji: '⚡', name: 'zap' },
  { emoji: '☀️', name: 'sunny' },
  { emoji: '🌟', name: 'star2' },
  { emoji: '💯', name: 'hundred' },
  { emoji: '💢', name: 'anger' },
  { emoji: '💥', name: 'boom' },
  { emoji: '💦', name: 'sweat_drops' },
  { emoji: '💨', name: 'dash' }
];

export default function EmojiReactions({
  messageId,
  reactions,
  onAddReaction,
  onRemoveReaction,
  disabled = false
}: EmojiReactionsProps) {
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  const handleReactionClick = (reaction: EmojiReactionSummary) => {
    if (reaction.user_reacted) {
      onRemoveReaction(reaction.emoji);
    } else {
      onAddReaction(reaction.emoji, reaction.emoji_name);
    }
  };

  const handleEmojiSelect = (emoji: string, emojiName: string) => {
    onAddReaction(emoji, emojiName);
    setShowEmojiPicker(false);
  };

  const formatUserList = (users: any[]) => {
    if (users.length === 0) return '';
    if (users.length === 1) return users[0].full_name;
    if (users.length === 2) return `${users[0].full_name} and ${users[1].full_name}`;
    if (users.length <= 5) {
      const names = users.slice(0, -1).map(u => u.full_name).join(', ');
      return `${names}, and ${users[users.length - 1].full_name}`;
    }
    const remaining = users.length - 3;
    const names = users.slice(0, 3).map(u => u.full_name).join(', ');
    return `${names}, and ${remaining} other${remaining > 1 ? 's' : ''}`;
  };

  if (reactions.length === 0 && disabled) {
    return null;
  }

  return (
    <div className="flex items-center gap-1 mt-1 flex-wrap">
      {/* Existing Reactions */}
      {reactions.map((reaction) => (
        <Tooltip key={reaction.emoji}>
          <TooltipTrigger asChild>
            <button
              onClick={() => !disabled && handleReactionClick(reaction)}
              disabled={disabled}
              className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs border transition-colors ${
                reaction.user_reacted
                  ? 'bg-blue-100 border-blue-300 text-blue-700 hover:bg-blue-200'
                  : 'bg-gray-100 border-gray-300 text-gray-700 hover:bg-gray-200'
              } ${disabled ? 'cursor-default' : 'cursor-pointer'}`}
            >
              <span className="text-sm">{reaction.emoji}</span>
              <span className="font-medium">{reaction.count}</span>
            </button>
          </TooltipTrigger>
          <TooltipContent>
            <p>{formatUserList(reaction.users)} reacted with {reaction.emoji_name}</p>
          </TooltipContent>
        </Tooltip>
      ))}

      {/* Add Reaction Button */}
      {!disabled && (
        <Popover open={showEmojiPicker} onOpenChange={setShowEmojiPicker}>
          <PopoverTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 w-7 p-0 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-full border border-transparent hover:border-gray-300"
            >
              <Plus className="h-3 w-3" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80 p-3" align="start">
            <div className="space-y-3">
              {/* Quick Reactions */}
              <div>
                <h4 className="text-sm font-medium text-gray-900 mb-2">Quick reactions</h4>
                <div className="flex gap-1 flex-wrap">
                  {quickReactions.map((emoji) => (
                    <button
                      key={emoji.emoji}
                      onClick={() => handleEmojiSelect(emoji.emoji, emoji.name)}
                      className="p-2 hover:bg-gray-100 rounded text-lg transition-colors"
                      title={emoji.name}
                    >
                      {emoji.emoji}
                    </button>
                  ))}
                </div>
              </div>

              {/* All Emojis */}
              <div>
                <h4 className="text-sm font-medium text-gray-900 mb-2">All emojis</h4>
                <div className="grid grid-cols-8 gap-1 max-h-48 overflow-y-auto">
                  {allEmojis.map((emoji) => (
                    <button
                      key={emoji.emoji}
                      onClick={() => handleEmojiSelect(emoji.emoji, emoji.name)}
                      className="p-1 hover:bg-gray-100 rounded text-lg transition-colors"
                      title={emoji.name}
                    >
                      {emoji.emoji}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </PopoverContent>
        </Popover>
      )}
    </div>
  );
}
