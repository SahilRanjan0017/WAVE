import React, { useState, useEffect, useRef } from 'react';
import { Video, VideoOff, Mic, MicOff, Monitor, Phone, PhoneOff, Users, Settings, Clock, Play, Pause, Download, FileText, MessageSquare, Volume2, AudioLines, Calendar, BarChart3 } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Separator } from './ui/separator';
import { Switch } from './ui/switch';
import { Progress } from './ui/progress';

interface MeetingRoom {
  id: string;
  workspace_id: string;
  name: string;
  description?: string;
  type: 'persistent' | 'scheduled' | 'instant';
  status: 'active' | 'inactive' | 'in_meeting';
  capacity: number;
  is_public: boolean;
  settings: {
    recording_enabled: boolean;
    transcription_enabled: boolean;
    auto_join_audio: boolean;
    screen_sharing_enabled: boolean;
    chat_enabled: boolean;
    waiting_room: boolean;
    require_auth: boolean;
    allow_breakout_rooms: boolean;
  };
  participants: {
    user_id: string;
    role: 'host' | 'co-host' | 'participant' | 'observer';
    joined_at: string;
    status: 'connected' | 'disconnected' | 'muted' | 'speaking';
    permissions: string[];
  }[];
  created_by: string;
  created_at: string;
  updated_at: string;
  last_meeting_at?: string;
  total_meetings: number;
  total_duration_minutes: number;
}

interface MeetingSession {
  id: string;
  room_id: string;
  title: string;
  started_at: string;
  ended_at?: string;
  duration_minutes?: number;
  host_id: string;
  participants: {
    user_id: string;
    joined_at: string;
    left_at?: string;
    duration_minutes: number;
    role: string;
  }[];
  recording?: {
    id: string;
    file_url: string;
    thumbnail_url?: string;
    size_bytes: number;
    duration_seconds: number;
    format: 'mp4' | 'webm';
    quality: '720p' | '1080p' | '4k';
    status: 'processing' | 'ready' | 'failed';
  };
  transcription?: {
    id: string;
    text: string;
    speakers: {
      speaker_id: string;
      name: string;
      segments: {
        start_time: number;
        end_time: number;
        text: string;
        confidence: number;
      }[];
    }[];
    language: string;
    accuracy: number;
    status: 'processing' | 'ready' | 'failed';
  };
  summary?: {
    key_points: string[];
    action_items: string[];
    decisions: string[];
    next_meeting_date?: string;
    generated_at: string;
  };
}

interface VoiceClip {
  id: string;
  workspace_id: string;
  created_by: string;
  title: string;
  description?: string;
  file_url: string;
  duration_seconds: number;
  file_size_bytes: number;
  waveform_data: number[];
  transcription?: {
    text: string;
    confidence: number;
    language: string;
  };
  tags: string[];
  is_public: boolean;
  created_at: string;
  play_count: number;
  liked_by: string[];
}

export const MeetingRooms: React.FC = () => {
  const [rooms, setRooms] = useState<MeetingRoom[]>([]);
  const [sessions, setSessions] = useState<MeetingSession[]>([]);
  const [voiceClips, setVoiceClips] = useState<VoiceClip[]>([]);
  const [selectedRoom, setSelectedRoom] = useState<MeetingRoom | null>(null);
  const [activeSession, setActiveSession] = useState<MeetingSession | null>(null);
  const [isInMeeting, setIsInMeeting] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showVoiceRecorder, setShowVoiceRecorder] = useState(false);
  const [meetingDuration, setMeetingDuration] = useState(0);
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [newRoom, setNewRoom] = useState({
    name: '',
    description: '',
    type: 'persistent' as const,
    capacity: 50,
    is_public: false
  });
  const [newVoiceClip, setNewVoiceClip] = useState({
    title: '',
    description: '',
    tags: ''
  });

  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const meetingTimerRef = useRef<NodeJS.Timeout | null>(null);
  const voiceTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    fetchRooms();
    fetchSessions();
    fetchVoiceClips();
  }, []);

  const fetchRooms = async () => {
    try {
      const response = await fetch('/api/meetings/rooms', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });
      
      const data = await response.json();
      if (data.success) {
        setRooms(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch rooms:', error);
    }
  };

  const fetchSessions = async () => {
    try {
      const response = await fetch('/api/meetings/sessions', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });
      
      const data = await response.json();
      if (data.success) {
        setSessions(data.data.sessions);
      }
    } catch (error) {
      console.error('Failed to fetch sessions:', error);
    }
  };

  const fetchVoiceClips = async () => {
    try {
      const response = await fetch('/api/voice-clips', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });
      
      const data = await response.json();
      if (data.success) {
        setVoiceClips(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch voice clips:', error);
    }
  };

  const createRoom = async () => {
    try {
      const response = await fetch('/api/meetings/rooms', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify(newRoom)
      });

      const data = await response.json();
      if (data.success) {
        setRooms(prev => [data.data, ...prev]);
        setShowCreateDialog(false);
        setNewRoom({
          name: '',
          description: '',
          type: 'persistent',
          capacity: 50,
          is_public: false
        });
      }
    } catch (error) {
      console.error('Failed to create room:', error);
    }
  };

  const startMeeting = async (room: MeetingRoom) => {
    try {
      const response = await fetch(`/api/meetings/rooms/${room.id}/start`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({
          title: `Meeting in ${room.name}`
        })
      });

      const data = await response.json();
      if (data.success) {
        setActiveSession(data.data);
        setIsInMeeting(true);
        setMeetingDuration(0);
        
        // Start meeting timer
        meetingTimerRef.current = setInterval(() => {
          setMeetingDuration(prev => prev + 1);
        }, 1000);

        // Initialize video
        initializeVideo();
      }
    } catch (error) {
      console.error('Failed to start meeting:', error);
    }
  };

  const endMeeting = async () => {
    if (!activeSession) return;

    try {
      const response = await fetch(`/api/meetings/sessions/${activeSession.id}/end`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({
          save_recording: isRecording,
          save_transcription: true
        })
      });

      const data = await response.json();
      if (data.success) {
        setIsInMeeting(false);
        setActiveSession(null);
        setIsRecording(false);
        
        if (meetingTimerRef.current) {
          clearInterval(meetingTimerRef.current);
        }

        // Stop video stream
        if (videoRef.current?.srcObject) {
          const stream = videoRef.current.srcObject as MediaStream;
          stream.getTracks().forEach(track => track.stop());
        }

        fetchSessions();
        fetchRooms();
      }
    } catch (error) {
      console.error('Failed to end meeting:', error);
    }
  };

  const initializeVideo = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (error) {
      console.error('Failed to access camera/microphone:', error);
    }
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    // In a real implementation, this would start/stop the recording service
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    // In a real implementation, this would mute/unmute the microphone
  };

  const toggleVideo = () => {
    setIsVideoOn(!isVideoOn);
    // In a real implementation, this would turn video on/off
  };

  const startScreenShare = async () => {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true
      });
      setIsScreenSharing(true);
      
      stream.getVideoTracks()[0].addEventListener('ended', () => {
        setIsScreenSharing(false);
      });
    } catch (error) {
      console.error('Failed to start screen share:', error);
    }
  };

  const startVoiceRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      
      mediaRecorder.start();
      setIsRecordingVoice(true);
      setRecordingTime(0);
      
      voiceTimerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
      
      mediaRecorder.addEventListener('dataavailable', (event) => {
        // In a real implementation, handle the recorded data
        console.log('Voice recording data:', event.data);
      });
    } catch (error) {
      console.error('Failed to start voice recording:', error);
    }
  };

  const stopVoiceRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecordingVoice(false);
      
      if (voiceTimerRef.current) {
        clearInterval(voiceTimerRef.current);
      }
    }
  };

  const saveVoiceClip = async () => {
    try {
      const response = await fetch('/api/voice-clips', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({
          ...newVoiceClip,
          duration_seconds: recordingTime,
          file_size_bytes: Math.random() * 1000000, // Mock file size
          tags: newVoiceClip.tags.split(',').map(tag => tag.trim()).filter(Boolean)
        })
      });

      const data = await response.json();
      if (data.success) {
        setVoiceClips(prev => [data.data, ...prev]);
        setShowVoiceRecorder(false);
        setNewVoiceClip({ title: '', description: '', tags: '' });
        setRecordingTime(0);
      }
    } catch (error) {
      console.error('Failed to save voice clip:', error);
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatFileSize = (bytes: number) => {
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'in_meeting':
        return <Video className="w-4 h-4 text-red-500" />;
      case 'active':
        return <Users className="w-4 h-4 text-green-500" />;
      default:
        return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const renderWaveform = (waveformData: number[]) => {
    return (
      <div className="flex items-center gap-0.5 h-8">
        {waveformData.slice(0, 50).map((height, index) => (
          <div
            key={index}
            className="bg-blue-500 w-1 rounded-full"
            style={{ height: `${Math.max(2, height / 4)}px` }}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <Video className="w-8 h-8" />
                Meeting Rooms
              </h1>
              <p className="text-gray-600 mt-1">
                Persistent meeting rooms with recording and transcription
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              <Dialog open={showVoiceRecorder} onOpenChange={setShowVoiceRecorder}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2">
                    <AudioLines className="w-4 h-4" />
                    Voice Clip
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Record Voice Clip</DialogTitle>
                    <DialogDescription>
                      Record a quick voice message for your team
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="mb-4">
                        <div className="text-2xl font-mono">
                          {formatDuration(recordingTime)}
                        </div>
                      </div>
                      
                      <div className="flex justify-center gap-4">
                        {!isRecordingVoice ? (
                          <Button onClick={startVoiceRecording} className="flex items-center gap-2">
                            <Mic className="w-4 h-4" />
                            Start Recording
                          </Button>
                        ) : (
                          <Button onClick={stopVoiceRecording} variant="destructive" className="flex items-center gap-2">
                            <MicOff className="w-4 h-4" />
                            Stop Recording
                          </Button>
                        )}
                      </div>
                    </div>
                    
                    {recordingTime > 0 && !isRecordingVoice && (
                      <>
                        <Separator />
                        <div className="space-y-3">
                          <div>
                            <Label htmlFor="clipTitle">Title</Label>
                            <Input
                              id="clipTitle"
                              value={newVoiceClip.title}
                              onChange={(e) => setNewVoiceClip(prev => ({ ...prev, title: e.target.value }))}
                              placeholder="Enter clip title..."
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="clipDescription">Description</Label>
                            <Textarea
                              id="clipDescription"
                              value={newVoiceClip.description}
                              onChange={(e) => setNewVoiceClip(prev => ({ ...prev, description: e.target.value }))}
                              placeholder="Optional description..."
                              rows={2}
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="clipTags">Tags (comma-separated)</Label>
                            <Input
                              id="clipTags"
                              value={newVoiceClip.tags}
                              onChange={(e) => setNewVoiceClip(prev => ({ ...prev, tags: e.target.value }))}
                              placeholder="meeting, update, announcement"
                            />
                          </div>
                          
                          <Button onClick={saveVoiceClip} className="w-full">
                            Save Voice Clip
                          </Button>
                        </div>
                      </>
                    )}
                  </div>
                </DialogContent>
              </Dialog>

              <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
                <DialogTrigger asChild>
                  <Button className="flex items-center gap-2">
                    <Video className="w-4 h-4" />
                    Create Room
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create Meeting Room</DialogTitle>
                    <DialogDescription>
                      Set up a new meeting room for your team
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="roomName">Room Name</Label>
                      <Input
                        id="roomName"
                        value={newRoom.name}
                        onChange={(e) => setNewRoom(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Enter room name..."
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="roomDescription">Description</Label>
                      <Textarea
                        id="roomDescription"
                        value={newRoom.description}
                        onChange={(e) => setNewRoom(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Room description..."
                        rows={2}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="roomType">Type</Label>
                        <Select
                          value={newRoom.type}
                          onValueChange={(value: 'persistent' | 'scheduled' | 'instant') => 
                            setNewRoom(prev => ({ ...prev, type: value }))
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="persistent">Persistent</SelectItem>
                            <SelectItem value="scheduled">Scheduled</SelectItem>
                            <SelectItem value="instant">Instant</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label htmlFor="roomCapacity">Capacity</Label>
                        <Input
                          id="roomCapacity"
                          type="number"
                          value={newRoom.capacity}
                          onChange={(e) => setNewRoom(prev => ({ ...prev, capacity: parseInt(e.target.value) }))}
                        />
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="public"
                        checked={newRoom.is_public}
                        onCheckedChange={(checked) => setNewRoom(prev => ({ ...prev, is_public: checked }))}
                      />
                      <Label htmlFor="public">Make room public</Label>
                    </div>
                    
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                        Cancel
                      </Button>
                      <Button onClick={createRoom}>
                        Create Room
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>

        {isInMeeting && activeSession ? (
          /* Meeting Interface */
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Video className="w-5 h-5 text-red-500" />
                    {activeSession.title}
                    <Badge variant="destructive">LIVE</Badge>
                  </CardTitle>
                  <CardDescription>
                    Meeting duration: {formatDuration(meetingDuration)}
                  </CardDescription>
                </div>
                
                <div className="flex items-center gap-2">
                  {isRecording && (
                    <Badge variant="destructive" className="animate-pulse">
                      REC {formatDuration(meetingDuration)}
                    </Badge>
                  )}
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={toggleRecording}
                    className={isRecording ? 'bg-red-50' : ''}
                  >
                    {isRecording ? 'Stop Recording' : 'Start Recording'}
                  </Button>
                </div>
              </div>
            </CardHeader>
            
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                {/* Video Area */}
                <div className="lg:col-span-3">
                  <div className="bg-black rounded-lg aspect-video relative overflow-hidden">
                    <video
                      ref={videoRef}
                      autoPlay
                      muted
                      className="w-full h-full object-cover"
                    />
                    
                    {!isVideoOn && (
                      <div className="absolute inset-0 bg-gray-900 flex items-center justify-center">
                        <VideoOff className="w-16 h-16 text-gray-400" />
                      </div>
                    )}
                    
                    {isScreenSharing && (
                      <div className="absolute top-4 left-4">
                        <Badge variant="secondary">
                          <Monitor className="w-3 h-3 mr-1" />
                          Screen Sharing
                        </Badge>
                      </div>
                    )}
                    
                    {/* Meeting Controls */}
                    <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
                      <div className="flex items-center gap-3 bg-black/70 rounded-full px-4 py-2">
                        <Button
                          size="sm"
                          variant={isMuted ? "destructive" : "secondary"}
                          onClick={toggleMute}
                          className="rounded-full w-10 h-10 p-0"
                        >
                          {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                        </Button>
                        
                        <Button
                          size="sm"
                          variant={isVideoOn ? "secondary" : "destructive"}
                          onClick={toggleVideo}
                          className="rounded-full w-10 h-10 p-0"
                        >
                          {isVideoOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
                        </Button>
                        
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={startScreenShare}
                          className="rounded-full w-10 h-10 p-0"
                        >
                          <Monitor className="w-4 h-4" />
                        </Button>
                        
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={endMeeting}
                          className="rounded-full w-10 h-10 p-0"
                        >
                          <PhoneOff className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Participants & Chat */}
                <div className="lg:col-span-1">
                  <Tabs defaultValue="participants" className="h-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="participants">
                        <Users className="w-4 h-4 mr-1" />
                        Participants
                      </TabsTrigger>
                      <TabsTrigger value="chat">
                        <MessageSquare className="w-4 h-4 mr-1" />
                        Chat
                      </TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="participants" className="space-y-2 mt-4">
                      {activeSession.participants.map(participant => (
                        <div key={participant.user_id} className="flex items-center gap-2 p-2 rounded">
                          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm">
                            {participant.user_id.charAt(0).toUpperCase()}
                          </div>
                          <div className="flex-grow">
                            <p className="text-sm font-medium">User {participant.user_id}</p>
                            <p className="text-xs text-gray-500">{participant.role}</p>
                          </div>
                          {participant.role === 'host' && (
                            <Badge variant="outline" className="text-xs">Host</Badge>
                          )}
                        </div>
                      ))}
                    </TabsContent>
                    
                    <TabsContent value="chat" className="mt-4">
                      <div className="space-y-2 h-64 overflow-y-auto">
                        <div className="text-sm text-gray-500 text-center">
                          Chat functionality would be implemented here
                        </div>
                      </div>
                      <div className="mt-4">
                        <Input placeholder="Type a message..." />
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue="rooms" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="rooms">Meeting Rooms</TabsTrigger>
              <TabsTrigger value="recordings">Recordings</TabsTrigger>
              <TabsTrigger value="voice-clips">Voice Clips</TabsTrigger>
            </TabsList>
            
            <TabsContent value="rooms" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {rooms.map(room => (
                  <Card key={room.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="flex items-center gap-2">
                            {getStatusIcon(room.status)}
                            {room.name}
                          </CardTitle>
                          <CardDescription className="mt-1">
                            {room.description}
                          </CardDescription>
                        </div>
                        <Badge variant={room.type === 'persistent' ? 'default' : 'secondary'}>
                          {room.type}
                        </Badge>
                      </div>
                    </CardHeader>
                    
                    <CardContent>
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-gray-600">Capacity:</span>
                            <p className="font-medium">{room.capacity} people</p>
                          </div>
                          <div>
                            <span className="text-gray-600">Meetings:</span>
                            <p className="font-medium">{room.total_meetings}</p>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-1">
                          {room.settings.recording_enabled && (
                            <Badge variant="outline" className="text-xs">Recording</Badge>
                          )}
                          {room.settings.transcription_enabled && (
                            <Badge variant="outline" className="text-xs">Transcription</Badge>
                          )}
                          {room.settings.screen_sharing_enabled && (
                            <Badge variant="outline" className="text-xs">Screen Share</Badge>
                          )}
                        </div>
                        
                        <div className="flex gap-2">
                          <Button
                            onClick={() => startMeeting(room)}
                            disabled={room.status === 'in_meeting'}
                            className="flex-1"
                          >
                            {room.status === 'in_meeting' ? (
                              <>
                                <Users className="w-4 h-4 mr-2" />
                                Join Meeting
                              </>
                            ) : (
                              <>
                                <Video className="w-4 h-4 mr-2" />
                                Start Meeting
                              </>
                            )}
                          </Button>
                          <Button variant="outline" size="sm">
                            <Settings className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="recordings" className="space-y-4">
              <div className="grid gap-4">
                {sessions.filter(s => s.recording).map(session => (
                  <Card key={session.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 bg-gray-200 rounded-lg flex items-center justify-center">
                          <Play className="w-6 h-6 text-gray-600" />
                        </div>
                        
                        <div className="flex-grow">
                          <h3 className="font-medium">{session.title}</h3>
                          <p className="text-sm text-gray-600">
                            {new Date(session.started_at).toLocaleDateString()} • 
                            {session.duration_minutes} minutes • 
                            {session.participants.length} participants
                          </p>
                          {session.recording && (
                            <p className="text-xs text-gray-500">
                              {formatFileSize(session.recording.size_bytes)} • {session.recording.quality}
                            </p>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-2">
                          {session.transcription && (
                            <Button variant="outline" size="sm">
                              <FileText className="w-4 h-4 mr-1" />
                              Transcript
                            </Button>
                          )}
                          <Button variant="outline" size="sm">
                            <Download className="w-4 h-4 mr-1" />
                            Download
                          </Button>
                          <Button size="sm">
                            <Play className="w-4 h-4 mr-1" />
                            Play
                          </Button>
                        </div>
                      </div>
                      
                      {session.summary && (
                        <div className="mt-4 pt-4 border-t">
                          <h4 className="font-medium text-sm mb-2">Meeting Summary</h4>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="font-medium">Key Points:</span>
                              <ul className="text-gray-600 mt-1">
                                {session.summary.key_points.slice(0, 2).map((point, idx) => (
                                  <li key={idx}>• {point}</li>
                                ))}
                              </ul>
                            </div>
                            <div>
                              <span className="font-medium">Action Items:</span>
                              <ul className="text-gray-600 mt-1">
                                {session.summary.action_items.slice(0, 2).map((item, idx) => (
                                  <li key={idx}>• {item}</li>
                                ))}
                              </ul>
                            </div>
                            <div>
                              <span className="font-medium">Decisions:</span>
                              <ul className="text-gray-600 mt-1">
                                {session.summary.decisions.slice(0, 2).map((decision, idx) => (
                                  <li key={idx}>• {decision}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="voice-clips" className="space-y-4">
              <div className="grid gap-4">
                {voiceClips.map(clip => (
                  <Card key={clip.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                          <Volume2 className="w-6 h-6 text-blue-600" />
                        </div>
                        
                        <div className="flex-grow">
                          <h3 className="font-medium">{clip.title}</h3>
                          <p className="text-sm text-gray-600">{clip.description}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-xs text-gray-500">
                              {formatDuration(clip.duration_seconds)} • 
                              {new Date(clip.created_at).toLocaleDateString()}
                            </span>
                            {clip.tags.length > 0 && (
                              <div className="flex gap-1">
                                {clip.tags.slice(0, 3).map(tag => (
                                  <Badge key={tag} variant="outline" className="text-xs">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex-shrink-0 w-48">
                          {renderWaveform(clip.waveform_data)}
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm">
                            <Play className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      
                      {clip.transcription && (
                        <div className="mt-3 pt-3 border-t">
                          <div className="flex items-center gap-2 mb-2">
                            <FileText className="w-4 h-4 text-gray-500" />
                            <span className="text-sm font-medium">Transcription</span>
                            <Badge variant="outline" className="text-xs">
                              {Math.round(clip.transcription.confidence * 100)}% accuracy
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-700">{clip.transcription.text}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
};

export default MeetingRooms;
