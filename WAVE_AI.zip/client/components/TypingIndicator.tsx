import React, { useState, useEffect } from 'react';
import { useWebSocket } from '../contexts/WebSocketContext';
import { TypingIndicator as TypingIndicatorType } from '@shared/api';

interface TypingIndicatorProps {
  channelId: string;
  currentUserId: string;
}

export default function TypingIndicator({ channelId, currentUserId }: TypingIndicatorProps) {
  const [typingUsers, setTypingUsers] = useState<TypingIndicatorType[]>([]);
  const { onTyping } = useWebSocket();

  useEffect(() => {
    const unsubscribe = onTyping((data: TypingIndicatorType) => {
      if (data.channel_id === channelId && data.user_id !== currentUserId) {
        setTypingUsers(prev => {
          const filtered = prev.filter(u => u.user_id !== data.user_id);
          if (data.is_typing) {
            return [...filtered, data];
          }
          return filtered;
        });

        // Auto-remove typing indicator after 5 seconds
        if (data.is_typing) {
          setTimeout(() => {
            setTypingUsers(prev => prev.filter(u => u.user_id !== data.user_id));
          }, 5000);
        }
      }
    });

    return unsubscribe;
  }, [channelId, currentUserId, onTyping]);

  if (typingUsers.length === 0) {
    return null;
  }

  const formatTypingText = () => {
    const names = typingUsers.map(u => u.user.full_name || u.user.username);
    
    if (names.length === 1) {
      return `${names[0]} is typing...`;
    } else if (names.length === 2) {
      return `${names[0]} and ${names[1]} are typing...`;
    } else if (names.length === 3) {
      return `${names[0]}, ${names[1]}, and ${names[2]} are typing...`;
    } else {
      return `${names[0]}, ${names[1]}, and ${names.length - 2} others are typing...`;
    }
  };

  return (
    <div className="px-6 py-2 text-sm text-gray-500 italic">
      <div className="flex items-center space-x-2">
        <div className="flex space-x-1">
          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
        </div>
        <span>{formatTypingText()}</span>
      </div>
    </div>
  );
}

// Hook for managing typing state
export function useTypingIndicator(channelId: string) {
  const { startTyping, stopTyping } = useWebSocket();
  const [isTyping, setIsTyping] = useState(false);
  const [typingTimeout, setTypingTimeout] = useState<NodeJS.Timeout | null>(null);

  const handleStartTyping = () => {
    if (!isTyping) {
      startTyping(channelId);
      setIsTyping(true);
    }

    // Clear existing timeout
    if (typingTimeout) {
      clearTimeout(typingTimeout);
    }

    // Set new timeout to stop typing after 3 seconds of inactivity
    const timeout = setTimeout(() => {
      handleStopTyping();
    }, 3000);

    setTypingTimeout(timeout);
  };

  const handleStopTyping = () => {
    if (isTyping) {
      stopTyping(channelId);
      setIsTyping(false);
    }

    if (typingTimeout) {
      clearTimeout(typingTimeout);
      setTypingTimeout(null);
    }
  };

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (typingTimeout) {
        clearTimeout(typingTimeout);
      }
      if (isTyping) {
        stopTyping(channelId);
      }
    };
  }, []);

  return {
    handleStartTyping,
    handleStopTyping,
    isTyping
  };
}
