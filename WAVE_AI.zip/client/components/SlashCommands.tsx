import React, { useState, useEffect, useRef } from 'react';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

interface SlashCommand {
  command: string;
  description: string;
  usage: string;
}

interface SlashCommandsProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (command: string) => void;
  triggerRef?: React.RefObject<HTMLElement>;
}

const defaultCommands: SlashCommand[] = [
  {
    command: 'help',
    description: 'Show available commands',
    usage: '/help'
  },
  {
    command: 'remind',
    description: 'Set a reminder',
    usage: '/remind me in 30 minutes to check the server'
  },
  {
    command: 'poll',
    description: 'Create a poll',
    usage: '/poll "Question?" "Option 1" "Option 2"'
  },
  {
    command: 'status',
    description: 'Update your status',
    usage: '/status away'
  },
  {
    command: 'weather',
    description: 'Get weather information',
    usage: '/weather San Francisco'
  },
  {
    command: 'giphy',
    description: 'Search for GIFs',
    usage: '/giphy excited'
  },
  {
    command: 'shrug',
    description: 'Add a shrug emoticon',
    usage: '/shrug'
  },
  {
    command: 'tableflip',
    description: 'Add a table flip emoticon',
    usage: '/tableflip'
  }
];

export default function SlashCommands({ isOpen, onClose, onSelect, triggerRef }: SlashCommandsProps) {
  const [commands, setCommands] = useState<SlashCommand[]>(defaultCommands);
  const [search, setSearch] = useState('');

  useEffect(() => {
    if (isOpen) {
      // Fetch available commands from API
      fetchCommands();
    }
  }, [isOpen]);

  const fetchCommands = async () => {
    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/commands', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success) {
          setCommands(data.data);
        }
      }
    } catch (error) {
      console.error('Failed to fetch commands:', error);
    }
  };

  const handleSelect = (command: string) => {
    onSelect(command);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <Popover open={isOpen} onOpenChange={onClose}>
      <PopoverTrigger asChild>
        <div ref={triggerRef as any} />
      </PopoverTrigger>
      <PopoverContent 
        className="w-80 p-0" 
        align="start"
        side="top"
        sideOffset={4}
      >
        <Command>
          <CommandInput 
            placeholder="Search commands..." 
            value={search}
            onValueChange={setSearch}
          />
          <CommandList>
            <CommandEmpty>No commands found.</CommandEmpty>
            <CommandGroup heading="Available Commands">
              {commands
                .filter(cmd => 
                  cmd.command.toLowerCase().includes(search.toLowerCase()) ||
                  cmd.description.toLowerCase().includes(search.toLowerCase())
                )
                .map((cmd) => (
                  <CommandItem
                    key={cmd.command}
                    onSelect={() => handleSelect(cmd.command)}
                    className="flex flex-col items-start p-3 cursor-pointer"
                  >
                    <div className="flex items-center space-x-2 w-full">
                      <span className="font-mono text-sm text-blue-600">/{cmd.command}</span>
                      <span className="text-sm text-gray-600 flex-1">{cmd.description}</span>
                    </div>
                    <span className="text-xs text-gray-500 mt-1 font-mono">{cmd.usage}</span>
                  </CommandItem>
                ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

// Hook to detect slash commands in text input
export function useSlashCommands(text: string, onCommandDetected: (command: string, args: string[]) => void) {
  const [showCommands, setShowCommands] = useState(false);
  const [commandPosition, setCommandPosition] = useState(0);

  useEffect(() => {
    // Check if text starts with '/' and detect command
    if (text.startsWith('/')) {
      const parts = text.slice(1).split(' ');
      const command = parts[0];
      const args = parts.slice(1);

      if (text === '/') {
        // Just typed slash, show command picker
        setShowCommands(true);
        setCommandPosition(0);
      } else if (text.includes(' ')) {
        // Command with arguments, execute
        setShowCommands(false);
        if (command && args.length > 0) {
          onCommandDetected(command, args);
        }
      } else {
        // Typing command name
        setShowCommands(true);
        setCommandPosition(0);
      }
    } else {
      setShowCommands(false);
    }
  }, [text, onCommandDetected]);

  const executeCommand = async (command: string, args: string[], channelId: string) => {
    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/commands/execute', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          command,
          args,
          channel_id: channelId
        })
      });

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Failed to execute command:', error);
      return { success: false, error: 'Command execution failed' };
    }
  };

  return {
    showCommands,
    setShowCommands,
    commandPosition,
    executeCommand
  };
}
