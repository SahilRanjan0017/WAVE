import React, { useState, useEffect } from 'react';
import { Search, Filter, Star, Download, Settings, Globe, Shield, Zap, TrendingUp, Users, Code, MessageSquare, BarChart3, DollarSign, Briefcase } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Separator } from './ui/separator';
import { Checkbox } from './ui/checkbox';

interface OAuthApp {
  id: string;
  workspace_id: string;
  name: string;
  description: string;
  provider: string;
  category: 'productivity' | 'development' | 'marketing' | 'hr' | 'finance' | 'communication' | 'analytics';
  logo_url: string;
  website_url: string;
  support_url?: string;
  client_id: string;
  client_secret: string;
  scopes: string[];
  redirect_uris: string[];
  webhook_endpoints: {
    url: string;
    events: string[];
    secret: string;
  }[];
  is_verified: boolean;
  is_public: boolean;
  install_count: number;
  rating: number;
  reviews_count: number;
  created_by: string;
  created_at: string;
  updated_at: string;
}

interface IntegrationTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  apps: string[];
  workflow_template: any;
  setup_instructions: string;
  use_cases: string[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimated_setup_time: number;
  popularity_score: number;
}

const categoryIcons = {
  productivity: <Zap className="w-5 h-5" />,
  development: <Code className="w-5 h-5" />,
  marketing: <TrendingUp className="w-5 h-5" />,
  hr: <Users className="w-5 h-5" />,
  finance: <DollarSign className="w-5 h-5" />,
  communication: <MessageSquare className="w-5 h-5" />,
  analytics: <BarChart3 className="w-5 h-5" />
};

const difficultyColors = {
  beginner: 'bg-green-100 text-green-800',
  intermediate: 'bg-yellow-100 text-yellow-800',
  advanced: 'bg-red-100 text-red-800'
};

export const AppDirectory: React.FC = () => {
  const [apps, setApps] = useState<OAuthApp[]>([]);
  const [templates, setTemplates] = useState<IntegrationTemplate[]>([]);
  const [selectedApp, setSelectedApp] = useState<OAuthApp | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showVerifiedOnly, setShowVerifiedOnly] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showInstallDialog, setShowInstallDialog] = useState(false);
  const [installConfig, setInstallConfig] = useState<Record<string, any>>({});

  useEffect(() => {
    fetchApps();
    fetchTemplates();
  }, [selectedCategory, showVerifiedOnly]);

  const fetchApps = async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedCategory !== 'all') {
        params.append('category', selectedCategory);
      }
      if (searchQuery) {
        params.append('search', searchQuery);
      }
      if (showVerifiedOnly) {
        params.append('verified_only', 'true');
      }

      const response = await fetch(`/api/oauth/apps?${params}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });
      
      const data = await response.json();
      if (data.success) {
        setApps(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch apps:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchTemplates = async () => {
    try {
      const params = new URLSearchParams();
      if (selectedCategory !== 'all') {
        params.append('category', selectedCategory);
      }

      const response = await fetch(`/api/integrations/templates?${params}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });
      
      const data = await response.json();
      if (data.success) {
        setTemplates(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch templates:', error);
    }
  };

  const installApp = async (app: OAuthApp) => {
    try {
      const response = await fetch('/api/oauth/apps/install', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({
          app_id: app.id,
          config: installConfig
        })
      });

      const data = await response.json();
      if (data.success) {
        alert('App installed successfully!');
        setShowInstallDialog(false);
        setInstallConfig({});
      }
    } catch (error) {
      console.error('Failed to install app:', error);
    }
  };

  const createWorkflowFromTemplate = async (template: IntegrationTemplate) => {
    try {
      const response = await fetch(`/api/integrations/templates/${template.id}/create-workflow`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({
          name: `${template.name} - ${new Date().toLocaleDateString()}`,
          config: {}
        })
      });

      const data = await response.json();
      if (data.success) {
        alert('Workflow created successfully from template!');
      }
    } catch (error) {
      console.error('Failed to create workflow from template:', error);
    }
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map(star => (
          <Star
            key={star}
            className={`w-4 h-4 ${
              star <= rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
            }`}
          />
        ))}
        <span className="text-sm text-gray-600 ml-1">({rating.toFixed(1)})</span>
      </div>
    );
  };

  const getCategoryIcon = (category: string) => {
    return categoryIcons[category as keyof typeof categoryIcons] || <Briefcase className="w-5 h-5" />;
  };

  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'productivity', label: 'Productivity' },
    { value: 'development', label: 'Development' },
    { value: 'marketing', label: 'Marketing' },
    { value: 'hr', label: 'HR & People' },
    { value: 'finance', label: 'Finance' },
    { value: 'communication', label: 'Communication' },
    { value: 'analytics', label: 'Analytics' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Globe className="w-8 h-8" />
            App Directory
          </h1>
          <p className="text-gray-600 mt-1">
            Discover and install integrations to supercharge your workflows
          </p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow-sm border p-4 mb-6">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  placeholder="Search apps and integrations..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div className="flex gap-4">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(category => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="verified"
                  checked={showVerifiedOnly}
                  onCheckedChange={setShowVerifiedOnly}
                />
                <Label htmlFor="verified" className="text-sm">
                  Verified only
                </Label>
              </div>
              
              <Button variant="outline" onClick={fetchApps}>
                <Filter className="w-4 h-4 mr-2" />
                Apply Filters
              </Button>
            </div>
          </div>
        </div>

        <Tabs defaultValue="apps" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="apps">Available Apps</TabsTrigger>
            <TabsTrigger value="templates">Integration Templates</TabsTrigger>
          </TabsList>
          
          <TabsContent value="apps" className="space-y-4">
            {isLoading ? (
              <div className="flex justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {apps.map(app => (
                  <Card key={app.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <img
                            src={app.logo_url}
                            alt={app.name}
                            className="w-12 h-12 rounded-lg object-contain"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = '/placeholder.svg';
                            }}
                          />
                          <div>
                            <CardTitle className="flex items-center gap-2">
                              {app.name}
                              {app.is_verified && (
                                <Shield className="w-4 h-4 text-blue-500" />
                              )}
                            </CardTitle>
                            <div className="flex items-center gap-2 mt-1">
                              {getCategoryIcon(app.category)}
                              <Badge variant="outline" className="text-xs">
                                {app.category}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent>
                      <CardDescription className="mb-4">
                        {app.description}
                      </CardDescription>
                      
                      <div className="space-y-3">
                        {renderStars(app.rating)}
                        
                        <div className="flex items-center justify-between text-sm text-gray-600">
                          <span className="flex items-center gap-1">
                            <Download className="w-4 h-4" />
                            {app.install_count.toLocaleString()} installs
                          </span>
                          <span>{app.reviews_count} reviews</span>
                        </div>
                        
                        <div className="flex flex-wrap gap-1">
                          {app.scopes.slice(0, 3).map(scope => (
                            <Badge key={scope} variant="secondary" className="text-xs">
                              {scope}
                            </Badge>
                          ))}
                          {app.scopes.length > 3 && (
                            <Badge variant="secondary" className="text-xs">
                              +{app.scopes.length - 3} more
                            </Badge>
                          )}
                        </div>
                        
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedApp(app)}
                            className="flex-1"
                          >
                            Learn More
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => {
                              setSelectedApp(app);
                              setShowInstallDialog(true);
                            }}
                            className="flex-1"
                          >
                            Install
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="templates" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {templates.map(template => (
                <Card key={template.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          {template.name}
                          <Badge 
                            variant="outline" 
                            className={`text-xs ${difficultyColors[template.difficulty]}`}
                          >
                            {template.difficulty}
                          </Badge>
                        </CardTitle>
                        <CardDescription className="mt-1">
                          {template.description}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-600">Required apps:</span>
                        <div className="flex gap-1">
                          {template.apps.map(appId => {
                            const app = apps.find(a => a.id === appId);
                            return app ? (
                              <Badge key={appId} variant="secondary" className="text-xs">
                                {app.name}
                              </Badge>
                            ) : null;
                          })}
                        </div>
                      </div>
                      
                      <div className="text-sm">
                        <p className="font-medium text-gray-700 mb-2">Use Cases:</p>
                        <ul className="space-y-1">
                          {template.use_cases.slice(0, 3).map((useCase, index) => (
                            <li key={index} className="text-gray-600 text-xs">
                              • {useCase}
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div className="flex items-center justify-between text-sm text-gray-600">
                        <span className="flex items-center gap-1">
                          <TrendingUp className="w-4 h-4" />
                          {template.popularity_score}% popularity
                        </span>
                        <span>~{template.estimated_setup_time} min setup</span>
                      </div>
                      
                      <Button
                        onClick={() => createWorkflowFromTemplate(template)}
                        className="w-full"
                      >
                        <Zap className="w-4 h-4 mr-2" />
                        Use Template
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* App Details Dialog */}
        <Dialog open={!!selectedApp && !showInstallDialog} onOpenChange={() => setSelectedApp(null)}>
          <DialogContent className="max-w-2xl">
            {selectedApp && (
              <>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-3">
                    <img
                      src={selectedApp.logo_url}
                      alt={selectedApp.name}
                      className="w-8 h-8 rounded object-contain"
                    />
                    {selectedApp.name}
                    {selectedApp.is_verified && (
                      <Shield className="w-5 h-5 text-blue-500" />
                    )}
                  </DialogTitle>
                  <DialogDescription>
                    {selectedApp.description}
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Permissions & Scopes</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {selectedApp.scopes.map(scope => (
                        <Badge key={scope} variant="outline" className="text-xs">
                          {scope}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Category:</span>
                      <p className="text-gray-600 capitalize">{selectedApp.category}</p>
                    </div>
                    <div>
                      <span className="font-medium">Provider:</span>
                      <p className="text-gray-600">{selectedApp.provider}</p>
                    </div>
                    <div>
                      <span className="font-medium">Install Count:</span>
                      <p className="text-gray-600">{selectedApp.install_count.toLocaleString()}</p>
                    </div>
                    <div>
                      <span className="font-medium">Rating:</span>
                      <div className="flex items-center gap-1">
                        {renderStars(selectedApp.rating)}
                      </div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      onClick={() => window.open(selectedApp.website_url, '_blank')}
                      className="flex-1"
                    >
                      <Globe className="w-4 h-4 mr-2" />
                      Website
                    </Button>
                    {selectedApp.support_url && (
                      <Button
                        variant="outline"
                        onClick={() => window.open(selectedApp.support_url, '_blank')}
                        className="flex-1"
                      >
                        Support
                      </Button>
                    )}
                    <Button
                      onClick={() => setShowInstallDialog(true)}
                      className="flex-1"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Install
                    </Button>
                  </div>
                </div>
              </>
            )}
          </DialogContent>
        </Dialog>

        {/* Install App Dialog */}
        <Dialog open={showInstallDialog} onOpenChange={setShowInstallDialog}>
          <DialogContent>
            {selectedApp && (
              <>
                <DialogHeader>
                  <DialogTitle>Install {selectedApp.name}</DialogTitle>
                  <DialogDescription>
                    Configure the integration settings for your workspace
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="config">Configuration (JSON)</Label>
                    <textarea
                      id="config"
                      className="w-full p-3 border rounded-md text-sm font-mono"
                      rows={6}
                      value={JSON.stringify(installConfig, null, 2)}
                      onChange={(e) => {
                        try {
                          setInstallConfig(JSON.parse(e.target.value));
                        } catch {
                          // Invalid JSON, ignore
                        }
                      }}
                      placeholder='{"api_key": "your-api-key", "webhook_url": "https://yourapp.com/webhook"}'
                    />
                  </div>
                  
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                    <h4 className="font-medium text-yellow-800 mb-1">Permissions Required</h4>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      {selectedApp.scopes.map(scope => (
                        <li key={scope}>• {scope}</li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setShowInstallDialog(false)}>
                      Cancel
                    </Button>
                    <Button onClick={() => installApp(selectedApp)}>
                      Install App
                    </Button>
                  </div>
                </div>
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default AppDirectory;
