import React, { useState, useCallback, useEffect } from 'react';
import { Plus, Play, Save, Settings, Zap, Clock, AlertTriangle, CheckCircle, GitBranch, Globe, Cpu } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Separator } from './ui/separator';
import { Switch } from './ui/switch';

interface WorkflowNode {
  id: string;
  type: 'trigger' | 'action' | 'condition' | 'delay' | 'webhook' | 'integration';
  name: string;
  description?: string;
  config: Record<string, any>;
  position: { x: number; y: number };
  connections: {
    input?: string[];
    output?: string[];
  };
}

interface WorkflowEdge {
  id: string;
  source: string;
  target: string;
  sourceHandle?: string;
  targetHandle?: string;
  condition?: {
    field: string;
    operator: 'equals' | 'contains' | 'greater_than' | 'less_than' | 'exists';
    value: any;
  };
}

interface AdvancedWorkflow {
  id: string;
  workspace_id: string;
  name: string;
  description: string;
  version: number;
  status: 'draft' | 'active' | 'paused' | 'archived';
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
  variables: {
    name: string;
    type: 'string' | 'number' | 'boolean' | 'object';
    default_value?: any;
    description?: string;
  }[];
  settings: {
    timeout_minutes: number;
    retry_attempts: number;
    error_handling: 'stop' | 'continue' | 'retry';
    concurrent_executions: number;
  };
  created_by: string;
  created_at: string;
  updated_at: string;
  last_run: string;
  total_runs: number;
  success_rate: number;
}

const nodeTypes = [
  {
    type: 'trigger',
    label: 'Trigger',
    icon: <Zap className="w-4 h-4" />,
    color: 'bg-green-500',
    description: 'Start the workflow'
  },
  {
    type: 'action',
    label: 'Action',
    icon: <Cpu className="w-4 h-4" />,
    color: 'bg-blue-500',
    description: 'Perform an action'
  },
  {
    type: 'condition',
    label: 'Condition',
    icon: <GitBranch className="w-4 h-4" />,
    color: 'bg-yellow-500',
    description: 'Make a decision'
  },
  {
    type: 'delay',
    label: 'Delay',
    icon: <Clock className="w-4 h-4" />,
    color: 'bg-purple-500',
    description: 'Wait for a specified time'
  },
  {
    type: 'webhook',
    label: 'Webhook',
    icon: <Globe className="w-4 h-4" />,
    color: 'bg-orange-500',
    description: 'Send HTTP request'
  },
  {
    type: 'integration',
    label: 'Integration',
    icon: <Plus className="w-4 h-4" />,
    color: 'bg-indigo-500',
    description: 'Connect with external services'
  }
];

export const WorkflowBuilder: React.FC = () => {
  const [workflows, setWorkflows] = useState<AdvancedWorkflow[]>([]);
  const [selectedWorkflow, setSelectedWorkflow] = useState<AdvancedWorkflow | null>(null);
  const [nodes, setNodes] = useState<WorkflowNode[]>([]);
  const [edges, setEdges] = useState<WorkflowEdge[]>([]);
  const [selectedNode, setSelectedNode] = useState<WorkflowNode | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showNodeConfig, setShowNodeConfig] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [draggedNodeType, setDraggedNodeType] = useState<string | null>(null);
  const [newWorkflow, setNewWorkflow] = useState({
    name: '',
    description: ''
  });

  useEffect(() => {
    fetchWorkflows();
  }, []);

  const fetchWorkflows = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/workflows/advanced', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      if (data.success) {
        setWorkflows(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch workflows:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const createWorkflow = async () => {
    try {
      const response = await fetch('/api/workflows/advanced', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({
          name: newWorkflow.name,
          description: newWorkflow.description,
          nodes: [],
          edges: [],
          variables: [],
          settings: {
            timeout_minutes: 30,
            retry_attempts: 3,
            error_handling: 'stop',
            concurrent_executions: 1
          }
        })
      });

      const data = await response.json();
      if (data.success) {
        setWorkflows(prev => [data.data, ...prev]);
        setSelectedWorkflow(data.data);
        setNodes([]);
        setEdges([]);
        setShowCreateDialog(false);
        setNewWorkflow({ name: '', description: '' });
      }
    } catch (error) {
      console.error('Failed to create workflow:', error);
    }
  };

  const saveWorkflow = async () => {
    if (!selectedWorkflow) return;

    try {
      const response = await fetch(`/api/workflows/advanced/${selectedWorkflow.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({
          nodes,
          edges
        })
      });

      const data = await response.json();
      if (data.success) {
        setSelectedWorkflow(data.data);
        setWorkflows(prev => prev.map(w => w.id === selectedWorkflow.id ? data.data : w));
      }
    } catch (error) {
      console.error('Failed to save workflow:', error);
    }
  };

  const executeWorkflow = async () => {
    if (!selectedWorkflow) return;

    try {
      const response = await fetch(`/api/workflows/advanced/${selectedWorkflow.id}/execute`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({
          test_data: { message: 'Test execution' }
        })
      });

      const data = await response.json();
      if (data.success) {
        alert('Workflow execution started successfully!');
      }
    } catch (error) {
      console.error('Failed to execute workflow:', error);
    }
  };

  const addNode = (type: string, position: { x: number; y: number }) => {
    const nodeType = nodeTypes.find(nt => nt.type === type);
    if (!nodeType) return;

    const newNode: WorkflowNode = {
      id: `node_${Date.now()}`,
      type: type as any,
      name: `${nodeType.label} ${nodes.length + 1}`,
      config: {},
      position,
      connections: { input: [], output: [] }
    };

    setNodes(prev => [...prev, newNode]);
  };

  const updateNode = (nodeId: string, updates: Partial<WorkflowNode>) => {
    setNodes(prev => prev.map(node => 
      node.id === nodeId ? { ...node, ...updates } : node
    ));
  };

  const deleteNode = (nodeId: string) => {
    setNodes(prev => prev.filter(node => node.id !== nodeId));
    setEdges(prev => prev.filter(edge => 
      edge.source !== nodeId && edge.target !== nodeId
    ));
  };

  const addEdge = (source: string, target: string) => {
    const newEdge: WorkflowEdge = {
      id: `edge_${Date.now()}`,
      source,
      target
    };

    setEdges(prev => [...prev, newEdge]);
  };

  const handleCanvasClick = (event: React.MouseEvent) => {
    if (draggedNodeType) {
      const rect = event.currentTarget.getBoundingClientRect();
      const position = {
        x: event.clientX - rect.left - 100,
        y: event.clientY - rect.top - 50
      };
      addNode(draggedNodeType, position);
      setDraggedNodeType(null);
    }
  };

  const getNodeIcon = (type: string) => {
    const nodeType = nodeTypes.find(nt => nt.type === type);
    return nodeType?.icon || <Cpu className="w-4 h-4" />;
  };

  const getNodeColor = (type: string) => {
    const nodeType = nodeTypes.find(nt => nt.type === type);
    return nodeType?.color || 'bg-gray-500';
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'paused':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'draft':
        return <AlertTriangle className="w-4 h-4 text-gray-500" />;
      default:
        return <AlertTriangle className="w-4 h-4 text-gray-500" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <Zap className="w-8 h-8" />
                Workflow Builder
              </h1>
              <p className="text-gray-600 mt-1">
                Create powerful automation workflows with visual tools
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              {selectedWorkflow && (
                <>
                  <Button
                    variant="outline"
                    onClick={saveWorkflow}
                    className="flex items-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    Save
                  </Button>
                  <Button
                    variant="outline"
                    onClick={executeWorkflow}
                    className="flex items-center gap-2"
                  >
                    <Play className="w-4 h-4" />
                    Test Run
                  </Button>
                </>
              )}
              
              <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
                <DialogTrigger asChild>
                  <Button className="flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    New Workflow
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create New Workflow</DialogTitle>
                    <DialogDescription>
                      Start building your automation workflow
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="name">Workflow Name</Label>
                      <Input
                        id="name"
                        value={newWorkflow.name}
                        onChange={(e) => setNewWorkflow(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Enter workflow name..."
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        value={newWorkflow.description}
                        onChange={(e) => setNewWorkflow(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Describe what this workflow does..."
                        rows={3}
                      />
                    </div>
                    
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                        Cancel
                      </Button>
                      <Button onClick={createWorkflow}>
                        Create Workflow
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Workflows List */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Your Workflows</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {workflows.map(workflow => (
                  <div
                    key={workflow.id}
                    className={`p-3 rounded-lg cursor-pointer transition-colors ${
                      selectedWorkflow?.id === workflow.id 
                        ? 'bg-blue-50 border border-blue-200' 
                        : 'hover:bg-gray-50'
                    }`}
                    onClick={() => {
                      setSelectedWorkflow(workflow);
                      setNodes(workflow.nodes);
                      setEdges(workflow.edges);
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-sm">{workflow.name}</h4>
                      {getStatusIcon(workflow.status)}
                    </div>
                    <p className="text-xs text-gray-600 mt-1">{workflow.description}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="outline" className="text-xs">
                        {workflow.total_runs} runs
                      </Badge>
                      {workflow.success_rate > 0 && (
                        <Badge variant="outline" className="text-xs">
                          {Math.round(workflow.success_rate)}% success
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Node Palette */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Workflow Nodes</CardTitle>
                <CardDescription className="text-xs">
                  Drag and drop to add nodes to your workflow
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                {nodeTypes.map(nodeType => (
                  <div
                    key={nodeType.type}
                    draggable
                    onDragStart={() => setDraggedNodeType(nodeType.type)}
                    onDragEnd={() => setDraggedNodeType(null)}
                    className="p-3 rounded-lg border-2 border-dashed border-gray-200 hover:border-gray-300 cursor-grab active:cursor-grabbing transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <div className={`p-2 rounded ${nodeType.color} text-white`}>
                        {nodeType.icon}
                      </div>
                      <div>
                        <p className="font-medium text-sm">{nodeType.label}</p>
                        <p className="text-xs text-gray-600">{nodeType.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Main Canvas */}
          <div className="lg:col-span-3">
            {selectedWorkflow ? (
              <Card className="h-[600px]">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {selectedWorkflow.name}
                        <Badge variant={selectedWorkflow.status === 'active' ? 'default' : 'secondary'}>
                          {selectedWorkflow.status}
                        </Badge>
                      </CardTitle>
                      <CardDescription>{selectedWorkflow.description}</CardDescription>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">
                        v{selectedWorkflow.version}
                      </Badge>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowNodeConfig(true)}
                      >
                        <Settings className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="h-full">
                  <div
                    className="w-full h-full bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 relative overflow-hidden"
                    onClick={handleCanvasClick}
                  >
                    {/* Canvas Grid */}
                    <div 
                      className="absolute inset-0 opacity-20"
                      style={{
                        backgroundImage: 'radial-gradient(circle, #000 1px, transparent 1px)',
                        backgroundSize: '20px 20px'
                      }}
                    />
                    
                    {/* Workflow Nodes */}
                    {nodes.map(node => (
                      <div
                        key={node.id}
                        className="absolute bg-white rounded-lg shadow-md border p-4 cursor-pointer hover:shadow-lg transition-shadow"
                        style={{
                          left: node.position.x,
                          top: node.position.y,
                          width: '200px'
                        }}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedNode(node);
                        }}
                      >
                        <div className="flex items-center gap-2 mb-2">
                          <div className={`p-1 rounded ${getNodeColor(node.type)} text-white`}>
                            {getNodeIcon(node.type)}
                          </div>
                          <h4 className="font-medium text-sm">{node.name}</h4>
                        </div>
                        
                        {node.description && (
                          <p className="text-xs text-gray-600 mb-2">{node.description}</p>
                        )}
                        
                        <div className="flex justify-between">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedNode(node);
                              setShowNodeConfig(true);
                            }}
                          >
                            Config
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteNode(node.id);
                            }}
                          >
                            Delete
                          </Button>
                        </div>
                        
                        {/* Connection Points */}
                        <div className="absolute -left-2 top-1/2 w-4 h-4 bg-blue-500 rounded-full border-2 border-white transform -translate-y-1/2"></div>
                        <div className="absolute -right-2 top-1/2 w-4 h-4 bg-blue-500 rounded-full border-2 border-white transform -translate-y-1/2"></div>
                      </div>
                    ))}
                    
                    {/* Workflow Edges */}
                    <svg className="absolute inset-0 pointer-events-none">
                      {edges.map(edge => {
                        const sourceNode = nodes.find(n => n.id === edge.source);
                        const targetNode = nodes.find(n => n.id === edge.target);
                        
                        if (!sourceNode || !targetNode) return null;
                        
                        const x1 = sourceNode.position.x + 200;
                        const y1 = sourceNode.position.y + 50;
                        const x2 = targetNode.position.x;
                        const y2 = targetNode.position.y + 50;
                        
                        return (
                          <line
                            key={edge.id}
                            x1={x1}
                            y1={y1}
                            x2={x2}
                            y2={y2}
                            stroke="#3b82f6"
                            strokeWidth="2"
                            markerEnd="url(#arrowhead)"
                          />
                        );
                      })}
                      
                      {/* Arrow marker definition */}
                      <defs>
                        <marker
                          id="arrowhead"
                          markerWidth="10"
                          markerHeight="7"
                          refX="10"
                          refY="3.5"
                          orient="auto"
                        >
                          <polygon
                            points="0 0, 10 3.5, 0 7"
                            fill="#3b82f6"
                          />
                        </marker>
                      </defs>
                    </svg>
                    
                    {/* Empty State */}
                    {nodes.length === 0 && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center">
                          <Zap className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                          <h3 className="text-lg font-medium text-gray-900 mb-2">Start Building</h3>
                          <p className="text-gray-600">
                            Drag and drop nodes from the palette to create your workflow
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ) : (
              /* Workflow Selection */
              <div className="text-center py-12">
                <Zap className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Select a Workflow</h3>
                <p className="text-gray-600 mb-4">
                  Choose a workflow from the sidebar or create a new one to get started
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Node Configuration Dialog */}
        <Dialog open={showNodeConfig} onOpenChange={setShowNodeConfig}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                Configure {selectedNode?.name || 'Node'}
              </DialogTitle>
              <DialogDescription>
                Set up the parameters for this workflow node
              </DialogDescription>
            </DialogHeader>
            
            {selectedNode && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="nodeName">Node Name</Label>
                  <Input
                    id="nodeName"
                    value={selectedNode.name}
                    onChange={(e) => updateNode(selectedNode.id, { name: e.target.value })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="nodeDescription">Description</Label>
                  <Textarea
                    id="nodeDescription"
                    value={selectedNode.description || ''}
                    onChange={(e) => updateNode(selectedNode.id, { description: e.target.value })}
                    rows={2}
                  />
                </div>
                
                {/* Node-specific configuration */}
                {selectedNode.type === 'delay' && (
                  <div>
                    <Label htmlFor="delayDuration">Delay Duration (minutes)</Label>
                    <Input
                      id="delayDuration"
                      type="number"
                      value={selectedNode.config.duration || ''}
                      onChange={(e) => updateNode(selectedNode.id, {
                        config: { ...selectedNode.config, duration: parseInt(e.target.value) }
                      })}
                    />
                  </div>
                )}
                
                {selectedNode.type === 'webhook' && (
                  <>
                    <div>
                      <Label htmlFor="webhookUrl">Webhook URL</Label>
                      <Input
                        id="webhookUrl"
                        value={selectedNode.config.url || ''}
                        onChange={(e) => updateNode(selectedNode.id, {
                          config: { ...selectedNode.config, url: e.target.value }
                        })}
                        placeholder="https://api.example.com/webhook"
                      />
                    </div>
                    <div>
                      <Label htmlFor="webhookMethod">HTTP Method</Label>
                      <Select
                        value={selectedNode.config.method || 'POST'}
                        onValueChange={(value) => updateNode(selectedNode.id, {
                          config: { ...selectedNode.config, method: value }
                        })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="GET">GET</SelectItem>
                          <SelectItem value="POST">POST</SelectItem>
                          <SelectItem value="PUT">PUT</SelectItem>
                          <SelectItem value="DELETE">DELETE</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}
                
                {selectedNode.type === 'condition' && (
                  <>
                    <div>
                      <Label htmlFor="conditionField">Field to Check</Label>
                      <Input
                        id="conditionField"
                        value={selectedNode.config.field || ''}
                        onChange={(e) => updateNode(selectedNode.id, {
                          config: { ...selectedNode.config, field: e.target.value }
                        })}
                        placeholder="e.g., message.text, user.role"
                      />
                    </div>
                    <div>
                      <Label htmlFor="conditionOperator">Operator</Label>
                      <Select
                        value={selectedNode.config.operator || 'equals'}
                        onValueChange={(value) => updateNode(selectedNode.id, {
                          config: { ...selectedNode.config, operator: value }
                        })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="equals">Equals</SelectItem>
                          <SelectItem value="contains">Contains</SelectItem>
                          <SelectItem value="greater_than">Greater Than</SelectItem>
                          <SelectItem value="less_than">Less Than</SelectItem>
                          <SelectItem value="exists">Exists</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="conditionValue">Value</Label>
                      <Input
                        id="conditionValue"
                        value={selectedNode.config.value || ''}
                        onChange={(e) => updateNode(selectedNode.id, {
                          config: { ...selectedNode.config, value: e.target.value }
                        })}
                      />
                    </div>
                  </>
                )}
                
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowNodeConfig(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setShowNodeConfig(false)}>
                    Save Configuration
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default WorkflowBuilder;
