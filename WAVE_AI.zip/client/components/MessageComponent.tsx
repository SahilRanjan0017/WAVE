import React, { useState } from 'react';
import { 
  MoreHorizontal, 
  Reply, 
  Pin, 
  Bookmark, 
  Edit3, 
  Trash2, 
  Copy,
  Share,
  Star,
  Thread
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import EmojiReactions from './EmojiReactions';
import { Message, EmojiReactionSummary } from '@shared/api';
import { useAuth } from '../contexts/AuthContext';
import { useWebSocket } from '../contexts/WebSocketContext';

interface MessageComponentProps {
  message: Message;
  onReply?: (message: Message) => void;
  onEdit?: (message: Message) => void;
  onDelete?: (messageId: string) => void;
  onPin?: (messageId: string, channelId: string) => void;
  onBookmark?: (messageId: string) => void;
  onAddReaction?: (messageId: string, emoji: string, emojiName: string) => void;
  onRemoveReaction?: (messageId: string, emoji: string) => void;
  showThreadButton?: boolean;
  isInThread?: boolean;
}

export default function MessageComponent({
  message,
  onReply,
  onEdit,
  onDelete,
  onPin,
  onBookmark,
  onAddReaction,
  onRemoveReaction,
  showThreadButton = true,
  isInThread = false
}: MessageComponentProps) {
  const { user } = useAuth();
  const [showActions, setShowActions] = useState(false);
  const [showMore, setShowMore] = useState(false);

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const formatContent = (content: string) => {
    // Basic markdown-like formatting
    let formatted = content
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/~~(.*?)~~/g, '<del>$1</del>')
      .replace(/`(.*?)`/g, '<code class="bg-gray-100 px-1 py-0.5 rounded text-sm">$1</code>')
      .replace(/```([\s\S]*?)```/g, '<pre class="bg-gray-100 p-2 rounded text-sm overflow-x-auto"><code>$1</code></pre>')
      .replace(/^> (.+)$/gm, '<blockquote class="border-l-4 border-gray-300 pl-4 italic text-gray-600">$1</blockquote>');

    return formatted;
  };

  const isOwnMessage = user?.id === message.sender_id;

  const handleCopyLink = () => {
    // In a real app, generate proper message permalink
    const link = `${window.location.origin}/messages/${message.id}`;
    navigator.clipboard.writeText(link);
    setShowMore(false);
  };

  const handleCopyText = () => {
    navigator.clipboard.writeText(message.content);
    setShowMore(false);
  };

  const reactions: EmojiReactionSummary[] = message.reactions?.map(r => ({
    emoji: r.emoji,
    emoji_name: r.emoji_name,
    count: 1, // In real app, aggregate counts
    users: r.user ? [r.user] : [],
    user_reacted: r.user_id === user?.id
  })) || [];

  return (
    <div 
      className={`group hover:bg-gray-50 px-4 py-2 ${isInThread ? 'ml-8' : ''}`}
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => setShowActions(false)}
    >
      <div className="flex items-start space-x-3">
        {/* Avatar */}
        <Avatar className="h-9 w-9 flex-shrink-0">
          <AvatarImage src={message.sender?.avatar_url} />
          <AvatarFallback className="bg-blue-500 text-white text-sm font-medium">
            {message.sender?.full_name?.split(' ').map(n => n[0]).join('') || 'U'}
          </AvatarFallback>
        </Avatar>

        {/* Message Content */}
        <div className="flex-1 min-w-0">
          {/* Header */}
          <div className="flex items-baseline space-x-2 mb-1">
            <span className="font-semibold text-gray-900 text-sm">
              {message.sender?.full_name || 'Unknown User'}
            </span>
            <span className="text-xs text-gray-500">
              {formatTime(message.created_at)}
            </span>
            {message.is_edited && (
              <span className="text-xs text-gray-400">(edited)</span>
            )}
            {message.is_pinned && (
              <Pin className="h-3 w-3 text-gray-400" />
            )}
          </div>

          {/* Message Text */}
          <div 
            className="text-sm text-gray-900 leading-relaxed"
            dangerouslySetInnerHTML={{ __html: formatContent(message.content) }}
          />

          {/* File Attachment */}
          {message.file_url && (
            <div className="mt-2">
              {message.type === 'image' ? (
                <img 
                  src={message.file_url} 
                  alt="Uploaded image"
                  className="max-w-sm rounded-lg border"
                />
              ) : (
                <div className="flex items-center space-x-2 p-3 bg-gray-100 rounded-lg max-w-sm">
                  <Paperclip className="h-4 w-4 text-gray-500" />
                  <span className="text-sm text-gray-700">{message.file_name || 'File'}</span>
                </div>
              )}
            </div>
          )}

          {/* Thread Info */}
          {message.reply_count && message.reply_count > 0 && !isInThread && (
            <button
              onClick={() => onReply?.(message)}
              className="flex items-center space-x-1 mt-2 text-xs text-blue-600 hover:text-blue-800"
            >
              <Thread className="h-3 w-3" />
              <span>{message.reply_count} repl{message.reply_count === 1 ? 'y' : 'ies'}</span>
            </button>
          )}

          {/* Reactions */}
          <EmojiReactions
            messageId={message.id}
            reactions={reactions}
            onAddReaction={(emoji, emojiName) => onAddReaction?.(message.id, emoji, emojiName)}
            onRemoveReaction={(emoji) => onRemoveReaction?.(message.id, emoji)}
          />
        </div>

        {/* Quick Actions */}
        {showActions && (
          <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => onAddReaction?.(message.id, '👍', 'thumbs_up')}
                >
                  <span className="text-base">👍</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>Add reaction</TooltipContent>
            </Tooltip>

            {showThreadButton && !isInThread && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => onReply?.(message)}
                  >
                    <Reply className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Reply in thread</TooltipContent>
              </Tooltip>
            )}

            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => onBookmark?.(message.id)}
                >
                  <Bookmark className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Save for later</TooltipContent>
            </Tooltip>

            {/* More Actions */}
            <Popover open={showMore} onOpenChange={setShowMore}>
              <PopoverTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                >
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-48 p-1" align="end">
                <div className="space-y-1">
                  {isOwnMessage && (
                    <>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="w-full justify-start"
                        onClick={() => {
                          onEdit?.(message);
                          setShowMore(false);
                        }}
                      >
                        <Edit3 className="h-4 w-4 mr-2" />
                        Edit message
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="w-full justify-start text-red-600 hover:text-red-700"
                        onClick={() => {
                          onDelete?.(message.id);
                          setShowMore(false);
                        }}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete message
                      </Button>
                    </>
                  )}
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => onPin?.(message.id, message.channel_id || '')}
                  >
                    <Pin className="h-4 w-4 mr-2" />
                    Pin to channel
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start"
                    onClick={handleCopyLink}
                  >
                    <Share className="h-4 w-4 mr-2" />
                    Copy link
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start"
                    onClick={handleCopyText}
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Copy text
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
          </div>
        )}
      </div>
    </div>
  );
}
