import React, { useState, useRef, useEffect } from 'react';
import { Mic, MicOff, Square, Play, Pause, Trash2, Send, Video, VideoOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';

interface VoiceRecorderProps {
  onRecordingComplete: (blob: Blob, duration: number, type: 'audio' | 'video') => void;
  onCancel: () => void;
  maxDuration?: number; // in seconds
  allowVideo?: boolean;
}

export default function VoiceRecorder({ 
  onRecordingComplete, 
  onCancel, 
  maxDuration = 300, // 5 minutes
  allowVideo = true 
}: VoiceRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [recordingBlob, setRecordingBlob] = useState<Blob | null>(null);
  const [recordingType, setRecordingType] = useState<'audio' | 'video'>('audio');
  const [isVideoMode, setIsVideoMode] = useState(false);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const previewVideoRef = useRef<HTMLVideoElement | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    return () => {
      cleanup();
    };
  }, []);

  const cleanup = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
  };

  const startRecording = async () => {
    try {
      const constraints = isVideoMode 
        ? { 
            audio: { 
              echoCancellation: true, 
              noiseSuppression: true 
            }, 
            video: { 
              width: { ideal: 1280 }, 
              height: { ideal: 720 } 
            } 
          }
        : { 
            audio: { 
              echoCancellation: true, 
              noiseSuppression: true 
            } 
          };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;

      // Set up preview for video recording
      if (isVideoMode && previewVideoRef.current) {
        previewVideoRef.current.srcObject = stream;
      }

      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: isVideoMode 
          ? 'video/webm;codecs=vp9,opus' 
          : 'audio/webm;codecs=opus'
      });

      chunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { 
          type: isVideoMode ? 'video/webm' : 'audio/webm' 
        });
        setRecordingBlob(blob);
        setRecordingType(isVideoMode ? 'video' : 'audio');
        
        // Create URL for playback
        const url = URL.createObjectURL(blob);
        if (isVideoMode && videoRef.current) {
          videoRef.current.src = url;
        } else if (!isVideoMode && audioRef.current) {
          audioRef.current.src = url;
        }
      };

      mediaRecorderRef.current = mediaRecorder;
      mediaRecorder.start(100); // Collect data every 100ms
      setIsRecording(true);
      setDuration(0);

      // Start timer
      timerRef.current = setInterval(() => {
        setDuration(prev => {
          const newDuration = prev + 1;
          if (newDuration >= maxDuration) {
            stopRecording();
          }
          return newDuration;
        });
      }, 1000);

    } catch (error) {
      console.error('Error starting recording:', error);
      alert('Failed to access microphone/camera. Please check permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
    
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }

    setIsRecording(false);
  };

  const playRecording = () => {
    if (recordingType === 'video' && videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
    } else if (recordingType === 'audio' && audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
    }
    setIsPlaying(!isPlaying);
  };

  const deleteRecording = () => {
    setRecordingBlob(null);
    setDuration(0);
    setIsPlaying(false);
    
    if (audioRef.current) audioRef.current.src = '';
    if (videoRef.current) videoRef.current.src = '';
  };

  const sendRecording = () => {
    if (recordingBlob) {
      onRecordingComplete(recordingBlob, duration, recordingType);
      cleanup();
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercentage = (duration / maxDuration) * 100;

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardContent className="p-6">
        <div className="space-y-4">
          {/* Mode Selection */}
          {allowVideo && !isRecording && !recordingBlob && (
            <div className="flex items-center justify-center space-x-2">
              <Button
                variant={!isVideoMode ? "default" : "outline"}
                size="sm"
                onClick={() => setIsVideoMode(false)}
              >
                <Mic className="h-4 w-4 mr-2" />
                Audio
              </Button>
              <Button
                variant={isVideoMode ? "default" : "outline"}
                size="sm"
                onClick={() => setIsVideoMode(true)}
              >
                <Video className="h-4 w-4 mr-2" />
                Video
              </Button>
            </div>
          )}

          {/* Video Preview (during recording) */}
          {isRecording && isVideoMode && (
            <div className="relative bg-black rounded-lg overflow-hidden">
              <video
                ref={previewVideoRef}
                autoPlay
                muted
                playsInline
                className="w-full h-48 object-cover"
              />
              <div className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded-full text-xs flex items-center">
                <div className="w-2 h-2 bg-white rounded-full mr-1 animate-pulse" />
                REC
              </div>
            </div>
          )}

          {/* Recording Preview (after recording) */}
          {recordingBlob && recordingType === 'video' && (
            <div className="relative bg-black rounded-lg overflow-hidden">
              <video
                ref={videoRef}
                controls={false}
                className="w-full h-48 object-cover"
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                onEnded={() => setIsPlaying(false)}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <Button
                  variant="secondary"
                  size="lg"
                  onClick={playRecording}
                  className="rounded-full w-16 h-16"
                >
                  {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
                </Button>
              </div>
            </div>
          )}

          {/* Audio Preview (hidden audio element) */}
          {recordingBlob && recordingType === 'audio' && (
            <audio
              ref={audioRef}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              onEnded={() => setIsPlaying(false)}
              style={{ display: 'none' }}
            />
          )}

          {/* Duration and Progress */}
          <div className="text-center">
            <div className="text-2xl font-mono font-bold mb-2">
              {formatDuration(duration)}
            </div>
            {isRecording && (
              <Progress value={progressPercentage} className="w-full" />
            )}
            {maxDuration && (
              <div className="text-xs text-gray-500 mt-1">
                Max: {formatDuration(maxDuration)}
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center space-x-3">
            {!recordingBlob ? (
              // Recording controls
              <>
                <Button
                  variant="outline"
                  onClick={onCancel}
                  disabled={isRecording}
                >
                  Cancel
                </Button>
                
                <Button
                  variant={isRecording ? "destructive" : "default"}
                  size="lg"
                  onClick={isRecording ? stopRecording : startRecording}
                  className="w-16 h-16 rounded-full"
                >
                  {isRecording ? (
                    <Square className="h-6 w-6" />
                  ) : isVideoMode ? (
                    <Video className="h-6 w-6" />
                  ) : (
                    <Mic className="h-6 w-6" />
                  )}
                </Button>
              </>
            ) : (
              // Playback controls
              <>
                <Button
                  variant="outline"
                  onClick={deleteRecording}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
                
                {recordingType === 'audio' && (
                  <Button
                    variant="outline"
                    onClick={playRecording}
                    className="w-12 h-12 rounded-full"
                  >
                    {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  </Button>
                )}
                
                <Button
                  variant="default"
                  onClick={sendRecording}
                  className="w-12 h-12 rounded-full"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </>
            )}
          </div>

          {/* Recording Tips */}
          {!isRecording && !recordingBlob && (
            <div className="text-center text-xs text-gray-500 space-y-1">
              <p>Click to start recording</p>
              {isVideoMode ? (
                <p>Make sure your camera and microphone are enabled</p>
              ) : (
                <p>Make sure your microphone is enabled</p>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// Hook for voice message functionality
export function useVoiceMessage() {
  const [isRecording, setIsRecording] = useState(false);
  const [showRecorder, setShowRecorder] = useState(false);

  const startRecording = () => {
    setShowRecorder(true);
  };

  const handleRecordingComplete = async (blob: Blob, duration: number, type: 'audio' | 'video') => {
    try {
      // Create form data for file upload
      const formData = new FormData();
      const fileName = `${type}-message-${Date.now()}.webm`;
      formData.append('file', blob, fileName);

      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/files/upload', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData
      });

      if (response.ok) {
        const data = await response.json();
        setShowRecorder(false);
        return data.data; // Return file info for message sending
      }
    } catch (error) {
      console.error('Failed to upload voice message:', error);
    }
    return null;
  };

  const cancelRecording = () => {
    setShowRecorder(false);
    setIsRecording(false);
  };

  return {
    isRecording,
    showRecorder,
    startRecording,
    handleRecordingComplete,
    cancelRecording
  };
}
