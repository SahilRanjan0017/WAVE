import React, { useState, useEffect, useRef } from 'react';
import { 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  Monitor, 
  MonitorOff, 
  Phone, 
  PhoneOff, 
  Users,
  Settings,
  Volume2,
  VolumeX
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { useAuth } from '../contexts/AuthContext';
import { useWebSocket } from '../contexts/WebSocketContext';

interface HuddleParticipant {
  id: string;
  name: string;
  avatar?: string;
  isVideoEnabled: boolean;
  isAudioEnabled: boolean;
  isSpeaking: boolean;
  stream?: MediaStream;
}

interface HuddleRoomProps {
  channelId: string;
  isOpen: boolean;
  onClose: () => void;
  participants: HuddleParticipant[];
}

export default function HuddleRoom({ channelId, isOpen, onClose, participants }: HuddleRoomProps) {
  const { user } = useAuth();
  const { sendMessage } = useWebSocket();
  
  // Media states
  const [isVideoEnabled, setIsVideoEnabled] = useState(false);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState([80]);
  
  // Refs for media elements
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const peerConnectionsRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  
  // UI states
  const [showSettings, setShowSettings] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('disconnected');

  // Initialize media devices
  useEffect(() => {
    if (isOpen) {
      initializeMedia();
      setConnectionStatus('connecting');
    } else {
      cleanup();
    }

    return cleanup;
  }, [isOpen]);

  const initializeMedia = async () => {
    try {
      // Get user media (audio and optionally video)
      const constraints = {
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        },
        video: isVideoEnabled ? {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          frameRate: { ideal: 30 }
        } : false
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      localStreamRef.current = stream;

      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }

      // Set up WebRTC peer connections for each participant
      participants.forEach(participant => {
        if (participant.id !== user?.id) {
          setupPeerConnection(participant.id, stream);
        }
      });

      setConnectionStatus('connected');
    } catch (error) {
      console.error('Failed to initialize media:', error);
      setConnectionStatus('disconnected');
    }
  };

  const setupPeerConnection = (participantId: string, localStream: MediaStream) => {
    const peerConnection = new RTCPeerConnection({
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
      ]
    });

    // Add local stream to peer connection
    localStream.getTracks().forEach(track => {
      peerConnection.addTrack(track, localStream);
    });

    // Handle incoming stream
    peerConnection.ontrack = (event) => {
      const [remoteStream] = event.streams;
      // Handle remote stream (display in participant video element)
      console.log('Received remote stream from', participantId);
    };

    // Handle ICE candidates
    peerConnection.onicecandidate = (event) => {
      if (event.candidate) {
        // Send ICE candidate to remote peer via WebSocket
        sendMessage('ice_candidate', {
          candidate: event.candidate,
          target: participantId,
          huddle_id: channelId
        });
      }
    };

    peerConnectionsRef.current.set(participantId, peerConnection);
  };

  const toggleVideo = async () => {
    if (!localStreamRef.current) return;

    if (isVideoEnabled) {
      // Turn off video
      const videoTrack = localStreamRef.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.stop();
        localStreamRef.current.removeTrack(videoTrack);
      }
      setIsVideoEnabled(false);
    } else {
      // Turn on video
      try {
        const videoStream = await navigator.mediaDevices.getUserMedia({ 
          video: {
            width: { ideal: 1280 },
            height: { ideal: 720 },
            frameRate: { ideal: 30 }
          } 
        });
        
        const videoTrack = videoStream.getVideoTracks()[0];
        localStreamRef.current.addTrack(videoTrack);
        
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = localStreamRef.current;
        }
        
        setIsVideoEnabled(true);
      } catch (error) {
        console.error('Failed to enable video:', error);
      }
    }

    // Notify other participants about video state change
    sendMessage('huddle_video_toggle', {
      channel_id: channelId,
      user_id: user?.id,
      video_enabled: !isVideoEnabled
    });
  };

  const toggleAudio = () => {
    if (!localStreamRef.current) return;

    const audioTrack = localStreamRef.current.getAudioTracks()[0];
    if (audioTrack) {
      audioTrack.enabled = !audioTrack.enabled;
      setIsAudioEnabled(audioTrack.enabled);
      
      // Notify other participants about audio state change
      sendMessage('huddle_audio_toggle', {
        channel_id: channelId,
        user_id: user?.id,
        audio_enabled: audioTrack.enabled
      });
    }
  };

  const toggleScreenShare = async () => {
    if (isScreenSharing) {
      // Stop screen sharing
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach(track => track.stop());
        screenStreamRef.current = null;
      }
      setIsScreenSharing(false);
    } else {
      // Start screen sharing
      try {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: true
        });
        
        screenStreamRef.current = screenStream;
        setIsScreenSharing(true);

        // Replace video track with screen share track for all peer connections
        const screenTrack = screenStream.getVideoTracks()[0];
        peerConnectionsRef.current.forEach(async (peerConnection) => {
          const sender = peerConnection.getSenders().find(s => 
            s.track && s.track.kind === 'video'
          );
          if (sender) {
            await sender.replaceTrack(screenTrack);
          }
        });

        // Handle screen share end
        screenTrack.onended = () => {
          setIsScreenSharing(false);
          // Switch back to camera
          if (isVideoEnabled && localStreamRef.current) {
            const cameraTrack = localStreamRef.current.getVideoTracks()[0];
            if (cameraTrack) {
              peerConnectionsRef.current.forEach(async (peerConnection) => {
                const sender = peerConnection.getSenders().find(s => 
                  s.track && s.track.kind === 'video'
                );
                if (sender) {
                  await sender.replaceTrack(cameraTrack);
                }
              });
            }
          }
        };
      } catch (error) {
        console.error('Failed to start screen sharing:', error);
      }
    }
  };

  const leaveHuddle = () => {
    cleanup();
    onClose();
    
    // Notify other participants
    sendMessage('huddle_leave', {
      channel_id: channelId,
      user_id: user?.id
    });
  };

  const cleanup = () => {
    // Stop all media tracks
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => track.stop());
      localStreamRef.current = null;
    }

    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach(track => track.stop());
      screenStreamRef.current = null;
    }

    // Close all peer connections
    peerConnectionsRef.current.forEach(peerConnection => {
      peerConnection.close();
    });
    peerConnectionsRef.current.clear();

    setConnectionStatus('disconnected');
  };

  const getConnectionStatusColor = () => {
    switch (connectionStatus) {
      case 'connecting': return 'text-yellow-500';
      case 'connected': return 'text-green-500';
      case 'disconnected': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[80vh] p-0">
        <div className="flex flex-col h-full bg-gray-900 text-white rounded-lg overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between p-4 bg-gray-800 border-b border-gray-700">
            <div className="flex items-center space-x-3">
              <h3 className="text-lg font-semibold">Huddle Room</h3>
              <div className="flex items-center space-x-2">
                <Users className="h-4 w-4" />
                <span className="text-sm">{participants.length} participant{participants.length !== 1 ? 's' : ''}</span>
              </div>
              <div className={`text-sm ${getConnectionStatusColor()}`}>
                {connectionStatus}
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setShowSettings(!showSettings)}
            >
              <Settings className="h-4 w-4" />
            </Button>
          </div>

          {/* Video Grid */}
          <div className="flex-1 p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 h-full">
              {/* Local Video */}
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-2 h-full">
                  <div className="relative h-full bg-gray-700 rounded-lg overflow-hidden">
                    {isVideoEnabled || isScreenSharing ? (
                      <video
                        ref={localVideoRef}
                        autoPlay
                        muted
                        playsInline
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <Avatar className="h-16 w-16">
                          <AvatarFallback className="text-2xl">
                            {user?.full_name?.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                      </div>
                    )}
                    
                    <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 rounded px-2 py-1">
                      <span className="text-sm">{user?.full_name} (you)</span>
                    </div>
                    
                    <div className="absolute bottom-2 right-2 flex space-x-1">
                      {!isAudioEnabled && <MicOff className="h-4 w-4 text-red-500" />}
                      {isScreenSharing && <Monitor className="h-4 w-4 text-blue-500" />}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Remote Participants */}
              {participants.filter(p => p.id !== user?.id).map((participant) => (
                <Card key={participant.id} className="bg-gray-800 border-gray-700">
                  <CardContent className="p-2 h-full">
                    <div className="relative h-full bg-gray-700 rounded-lg overflow-hidden">
                      {participant.isVideoEnabled ? (
                        <div className="w-full h-full bg-gray-600 flex items-center justify-center">
                          <span className="text-sm text-gray-400">Video stream</span>
                        </div>
                      ) : (
                        <div className="flex items-center justify-center h-full">
                          <Avatar className="h-16 w-16">
                            <AvatarImage src={participant.avatar} />
                            <AvatarFallback className="text-2xl">
                              {participant.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                        </div>
                      )}
                      
                      <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 rounded px-2 py-1">
                        <span className="text-sm">{participant.name}</span>
                      </div>
                      
                      <div className="absolute bottom-2 right-2 flex space-x-1">
                        {!participant.isAudioEnabled && <MicOff className="h-4 w-4 text-red-500" />}
                        {participant.isSpeaking && (
                          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center space-x-4 p-4 bg-gray-800 border-t border-gray-700">
            <Button
              variant={isAudioEnabled ? "default" : "destructive"}
              size="lg"
              onClick={toggleAudio}
              className="w-12 h-12 rounded-full"
            >
              {isAudioEnabled ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
            </Button>

            <Button
              variant={isVideoEnabled ? "default" : "secondary"}
              size="lg"
              onClick={toggleVideo}
              className="w-12 h-12 rounded-full"
            >
              {isVideoEnabled ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
            </Button>

            <Button
              variant={isScreenSharing ? "default" : "secondary"}
              size="lg"
              onClick={toggleScreenShare}
              className="w-12 h-12 rounded-full"
            >
              {isScreenSharing ? <MonitorOff className="h-5 w-5" /> : <Monitor className="h-5 w-5" />}
            </Button>

            <Button
              variant="destructive"
              size="lg"
              onClick={leaveHuddle}
              className="w-12 h-12 rounded-full"
            >
              <PhoneOff className="h-5 w-5" />
            </Button>
          </div>

          {/* Settings Panel */}
          {showSettings && (
            <div className="absolute top-0 right-0 w-80 h-full bg-gray-800 border-l border-gray-700 p-4">
              <h4 className="text-lg font-semibold mb-4">Audio & Video Settings</h4>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Volume: {volume[0]}%
                  </label>
                  <Slider
                    value={volume}
                    onValueChange={setVolume}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm">Mute audio</span>
                  <Button
                    variant={isMuted ? "destructive" : "secondary"}
                    size="sm"
                    onClick={() => setIsMuted(!isMuted)}
                  >
                    {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Hook for managing huddle state
export function useHuddle(channelId: string) {
  const [isInHuddle, setIsInHuddle] = useState(false);
  const [participants, setParticipants] = useState<HuddleParticipant[]>([]);
  
  const startHuddle = async () => {
    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/huddles/start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          channel_id: channelId,
          is_video: true
        })
      });

      if (response.ok) {
        setIsInHuddle(true);
      }
    } catch (error) {
      console.error('Failed to start huddle:', error);
    }
  };

  const leaveHuddle = () => {
    setIsInHuddle(false);
    setParticipants([]);
  };

  return {
    isInHuddle,
    participants,
    startHuddle,
    leaveHuddle
  };
}
