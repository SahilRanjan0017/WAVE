import React, { createContext, useContext, useEffect, useState, useRef, ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { Message, TypingIndicator, UserPresence, Notification } from '@shared/api';

interface WebSocketContextType {
  isConnected: boolean;
  sendMessage: (type: string, data: any) => void;
  onMessage: (callback: (data: any) => void) => () => void;
  onTyping: (callback: (data: TypingIndicator) => void) => () => void;
  onPresenceUpdate: (callback: (data: UserPresence) => void) => () => void;
  onNotification: (callback: (data: Notification) => void) => () => void;
  joinChannel: (channelId: string) => void;
  leaveChannel: (channelId: string) => void;
  startTyping: (channelId: string) => void;
  stopTyping: (channelId: string) => void;
  updatePresence: (status: 'online' | 'away' | 'offline') => void;
}

const WebSocketContext = createContext<WebSocketContextType | undefined>(undefined);

interface WebSocketProviderProps {
  children: ReactNode;
}

export function WebSocketProvider({ children }: WebSocketProviderProps) {
  const { user } = useAuth();
  const [isConnected, setIsConnected] = useState(false);
  const ws = useRef<WebSocket | null>(null);
  const messageCallbacks = useRef<((data: any) => void)[]>([]);
  const typingCallbacks = useRef<((data: TypingIndicator) => void)[]>([]);
  const presenceCallbacks = useRef<((data: UserPresence) => void)[]>([]);
  const notificationCallbacks = useRef<((data: Notification) => void)[]>([]);
  const typingTimeouts = useRef<Map<string, NodeJS.Timeout>>(new Map());

  useEffect(() => {
    if (user) {
      connectWebSocket();
    } else {
      disconnectWebSocket();
    }

    return () => {
      disconnectWebSocket();
    };
  }, [user]);

  const connectWebSocket = () => {
    try {
      // Check if WebSocket is supported
      if (typeof WebSocket === 'undefined') {
        console.warn('WebSocket not supported in this environment');
        return;
      }

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}`;

      console.log('Attempting to connect to WebSocket:', wsUrl);
      ws.current = new WebSocket(wsUrl);

      // Set a connection timeout
      const connectionTimeout = setTimeout(() => {
        if (ws.current && ws.current.readyState === WebSocket.CONNECTING) {
          console.warn('WebSocket connection timeout');
          ws.current.close();
        }
      }, 10000); // 10 second timeout

      ws.current.onopen = () => {
        console.log('WebSocket connected successfully');
        clearTimeout(connectionTimeout);
        setIsConnected(true);

        // Authenticate the connection
        if (user) {
          const token = localStorage.getItem('auth_token');
          sendMessage('authenticate', { token, user });
        }
      };

      ws.current.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          handleWebSocketMessage(data);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error, 'Raw data:', event.data);
        }
      };

      ws.current.onclose = (event) => {
        console.log('WebSocket disconnected', {
          code: event.code,
          reason: event.reason,
          wasClean: event.wasClean
        });
        clearTimeout(connectionTimeout);
        setIsConnected(false);

        // Only reconnect if it wasn't a clean close and user is still logged in
        // Also avoid reconnecting on certain error codes
        if (!event.wasClean && user && ![1000, 1001, 1002, 1003].includes(event.code)) {
          console.log('Attempting to reconnect WebSocket in 5 seconds...');
          setTimeout(connectWebSocket, 5000);
        }
      };

      ws.current.onerror = (error) => {
        console.warn('WebSocket error occurred (this is normal in development):', {
          type: error.type,
          readyState: ws.current?.readyState,
          url: wsUrl
        });
        clearTimeout(connectionTimeout);
        setIsConnected(false);
      };
    } catch (error) {
      console.error('Failed to initialize WebSocket connection:', error);
      setIsConnected(false);
    }
  };

  const disconnectWebSocket = () => {
    if (ws.current) {
      ws.current.close();
      ws.current = null;
    }
    setIsConnected(false);
  };

  const handleWebSocketMessage = (data: any) => {
    try {
      switch (data.type) {
        case 'connected':
          console.log('WebSocket connection confirmed by server');
          break;

        case 'new_message':
        case 'new_direct_message':
        case 'message_reaction':
        case 'channel_update':
          messageCallbacks.current.forEach(callback => callback(data));
          break;

        case 'typing':
          typingCallbacks.current.forEach(callback => callback(data.data));
          break;

        case 'presence_update':
          presenceCallbacks.current.forEach(callback => callback(data.data));
          break;

        case 'notification':
          notificationCallbacks.current.forEach(callback => callback(data.data));
          break;

        case 'authenticated':
          console.log('WebSocket authenticated successfully');
          break;

        case 'error':
          console.error('WebSocket server error:', data.data);
          break;

        default:
          console.log('Unknown WebSocket message type:', data.type, data);
      }
    } catch (error) {
      console.error('Error handling WebSocket message:', error, data);
    }
  };

  const sendMessage = (type: string, data: any) => {
    if (ws.current && ws.current.readyState === WebSocket.OPEN) {
      try {
        const message = JSON.stringify({ type, data });
        ws.current.send(message);
        console.log('Sent WebSocket message:', { type, data });
      } catch (error) {
        console.error('Failed to send WebSocket message:', error, { type, data });
      }
    } else {
      console.warn('WebSocket not connected, cannot send message:', {
        type,
        data,
        readyState: ws.current?.readyState,
        connected: isConnected
      });
    }
  };

  const onMessage = (callback: (data: any) => void) => {
    messageCallbacks.current.push(callback);
    return () => {
      const index = messageCallbacks.current.indexOf(callback);
      if (index > -1) {
        messageCallbacks.current.splice(index, 1);
      }
    };
  };

  const onTyping = (callback: (data: TypingIndicator) => void) => {
    typingCallbacks.current.push(callback);
    return () => {
      const index = typingCallbacks.current.indexOf(callback);
      if (index > -1) {
        typingCallbacks.current.splice(index, 1);
      }
    };
  };

  const onPresenceUpdate = (callback: (data: UserPresence) => void) => {
    presenceCallbacks.current.push(callback);
    return () => {
      const index = presenceCallbacks.current.indexOf(callback);
      if (index > -1) {
        presenceCallbacks.current.splice(index, 1);
      }
    };
  };

  const onNotification = (callback: (data: Notification) => void) => {
    notificationCallbacks.current.push(callback);
    return () => {
      const index = notificationCallbacks.current.indexOf(callback);
      if (index > -1) {
        notificationCallbacks.current.splice(index, 1);
      }
    };
  };

  const joinChannel = (channelId: string) => {
    sendMessage('join_channel', { channelId });
  };

  const leaveChannel = (channelId: string) => {
    sendMessage('leave_channel', { channelId });
  };

  const startTyping = (channelId: string) => {
    sendMessage('typing', { channelId, isTyping: true });
    
    // Clear existing timeout for this channel
    const existingTimeout = typingTimeouts.current.get(channelId);
    if (existingTimeout) {
      clearTimeout(existingTimeout);
    }

    // Set timeout to stop typing after 3 seconds
    const timeout = setTimeout(() => {
      stopTyping(channelId);
    }, 3000);
    
    typingTimeouts.current.set(channelId, timeout);
  };

  const stopTyping = (channelId: string) => {
    sendMessage('typing', { channelId, isTyping: false });
    
    const timeout = typingTimeouts.current.get(channelId);
    if (timeout) {
      clearTimeout(timeout);
      typingTimeouts.current.delete(channelId);
    }
  };

  const updatePresence = (status: 'online' | 'away' | 'offline') => {
    sendMessage('presence', { status });
  };

  const value: WebSocketContextType = {
    isConnected,
    sendMessage,
    onMessage,
    onTyping,
    onPresenceUpdate,
    onNotification,
    joinChannel,
    leaveChannel,
    startTyping,
    stopTyping,
    updatePresence
  };

  return (
    <WebSocketContext.Provider value={value}>
      {children}
    </WebSocketContext.Provider>
  );
}

export function useWebSocket() {
  const context = useContext(WebSocketContext);
  if (context === undefined) {
    throw new Error('useWebSocket must be used within a WebSocketProvider');
  }
  return context;
}
