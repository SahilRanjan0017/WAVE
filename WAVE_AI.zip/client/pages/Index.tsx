import { useState, useEffect, useRef } from 'react';
import { 
  ChevronDown, 
  Hash, 
  Users, 
  Plus, 
  Search,
  Home,
  MessageSquare,
  Headphones,
  Send,
  Activity,
  MoreHorizontal,
  Bold,
  Italic,
  Strikethrough,
  Link,
  List,
  ListOrdered,
  Code,
  Quote,
  Smile,
  Paperclip,
  Mic,
  Video,
  Camera,
  AtSign,
  Calendar,
  FileText,
  X,
  LogOut,
  Check,
  Trash2,
  Settings,
  Bell,
  Star,
  Archive,
  HelpCircle,
  Shield,
  Zap,
  Briefcase,
  Globe,
  UserPlus,
  Phone,
  Monitor,
  Image,
  Gift,
  MapPin,
  Clock,
  Filter,
  Eye,
  Edit,
  Copy,
  Download,
  Share,
  BarChart3,
  Bot,
  Workflow,
  Database,
  Lock,
  Palette,
  Languages,
  Accessibility,
  Folder,
  PenTool,
  Save,
  StickyNote,
  Lightbulb,
  Wand2,
  Target,
  BookOpen,
  Layers,
  Brain,
  Cpu,
  Network,
  Radar,
  TrendingUp,
  Users2,
  CheckCircle,
  Play,
  Pause,
  Volume2,
  CloudRain,
  Sparkles,
  Command,
  Megaphone,
  Handshake,
  Timer,
  DollarSign,
  CreditCard,
  UserCheck,
  Building,
  Gauge
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useAuth } from '../contexts/AuthContext';
import { Todo, Message, ApiResponse, PaginatedResponse, SendMessageRequest, CreateTodoRequest } from '@shared/api';

// Import enterprise components
import { EnhancedSearch } from '../components/EnhancedSearch';
import { WorkflowBuilder } from '../components/WorkflowBuilder';
import { AppDirectory } from '../components/AppDirectory';
import { MeetingRooms } from '../components/MeetingRooms';
import { NotificationsPanel } from '../components/NotificationsPanel';
import { KnowledgeBase } from '../components/KnowledgeBase';
import EnhancedWhiteboard from '../components/EnhancedWhiteboard';

// Navigation items for the 5 major sections
const navItems = [
  { icon: MessageSquare, label: 'Communication Hub', active: false, view: 'communication', color: 'bg-blue-600' },
  { icon: Brain, label: 'AI Collaboration', active: false, view: 'ai-collaboration', color: 'bg-purple-600' },
  { icon: Workflow, label: 'Automation Center', active: false, view: 'automation', color: 'bg-green-600' },
  { icon: Search, label: 'Intelligence & Search', active: false, view: 'intelligence', color: 'bg-orange-600' },
  { icon: Shield, label: 'Enterprise Control', active: false, view: 'enterprise', color: 'bg-red-600' }
];

const channels = [
  { id: 'all-new-workspace', name: 'all-new-workspace', unread: false, type: 'channel' },
  { id: 'new-channel', name: 'new-channel', unread: false, type: 'channel' },
  { id: 'social', name: 'social', unread: false, type: 'channel' }
];

const formatButtons = [
  { icon: Bold, label: 'Bold', key: 'bold' },
  { icon: Italic, label: 'Italic', key: 'italic' },
  { icon: Strikethrough, label: 'Strikethrough', key: 'strikethrough' },
  { icon: Link, label: 'Link', key: 'link' },
  { icon: List, label: 'Bullet list', key: 'list' },
  { icon: ListOrdered, label: 'Numbered list', key: 'orderedList' },
  { icon: Code, label: 'Code', key: 'code' },
  { icon: Quote, label: 'Quote', key: 'quote' }
];

const attachButtons = [
  { icon: Plus, label: 'Add', key: 'add' },
  { icon: AtSign, label: 'Mention', key: 'mention' },
  { icon: Smile, label: 'Emoji', key: 'emoji' },
  { icon: Gift, label: 'GIF', key: 'gif' },
  { icon: Calendar, label: 'Schedule', key: 'schedule' },
  { icon: FileText, label: 'Snippet', key: 'snippet' },
  { icon: Paperclip, label: 'Attach', key: 'attach' },
  { icon: Image, label: 'Photo', key: 'photo' },
  { icon: Mic, label: 'Record audio', key: 'audio' },
  { icon: Video, label: 'Record video', key: 'video' },
  { icon: Monitor, label: 'Record screen', key: 'screen' }
];

const emojiList = ['😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇', '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚', '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🤩', '🥳', '😏', '😒', '😞', '😔', '😟', '😕', '🙁', '☹️', '😣', '😖', '😫', '😩', '🥺', '😢', '😭', '😤', '😠', '😡', '🤬', '🤯', '😳', '🥵', '🥶', '😱', '😨', '😰', '😥', '😓', '🤗', '🤔', '🤭', '🤫', '🤥', '😶', '😐', '😑', '😬', '🙄', '😯', '😦', '😧', '😮', '😲', '🥱', '😴', '🤤', '😪', '😵', '🤐', '🥴', '🤢', '🤮', '🤧', '😷', '🤒', '🤕'];

export default function Index() {
  const { user, logout } = useAuth();
  const [activeView, setActiveView] = useState('communication');
  const [activeTab, setActiveTab] = useState('Messages');
  const [messageText, setMessageText] = useState('');
  const [todos, setTodos] = useState<Todo[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newTodo, setNewTodo] = useState('');
  const [selectedChannel, setSelectedChannel] = useState('all-new-workspace');
  const [searchQuery, setSearchQuery] = useState('');
  const [loadingTodos, setLoadingTodos] = useState(false);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showCreateChannel, setShowCreateChannel] = useState(false);
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [showAppsDirectory, setShowAppsDirectory] = useState(false);
  const [showWorkflows, setShowWorkflows] = useState(false);
  const [showMeetings, setShowMeetings] = useState(false);
  const [showKnowledgeBase, setShowKnowledgeBase] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showWhiteboard, setShowWhiteboard] = useState(false);
  const [showCommandBar, setShowCommandBar] = useState(false);
  const [newChannelName, setNewChannelName] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [userStatus, setUserStatus] = useState('Active');
  const [customStatus, setCustomStatus] = useState('');
  const [notes, setNotes] = useState('');
  const [whiteboardContent, setWhiteboardContent] = useState('');
  const [commandQuery, setCommandQuery] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const directMessages = [
    { id: 'self', name: `${user?.full_name} (you)`, online: true, avatar: user?.full_name.split(' ').map(n => n[0]).join('') }
  ];

  // Fetch todos on component mount
  useEffect(() => {
    if (activeTab === 'To-do list') {
      fetchTodos();
    }
  }, [activeTab]);

  // Fetch messages when channel changes
  useEffect(() => {
    if (activeTab === 'Messages') {
      fetchMessages();
    }
  }, [selectedChannel, activeTab]);

  // Load notes for current channel
  useEffect(() => {
    if (activeTab === 'Notes') {
      fetchNotes();
    }
  }, [selectedChannel, activeTab]);

  // Command bar keyboard shortcut
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === '/' && !showCommandBar) {
        e.preventDefault();
        setShowCommandBar(true);
      }
      if (e.key === 'Escape') {
        setShowCommandBar(false);
        setCommandQuery('');
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [showCommandBar]);

  const getAuthToken = () => localStorage.getItem('auth_token');

  const fetchTodos = async () => {
    setLoadingTodos(true);
    try {
      const response = await fetch('/api/todos', {
        headers: {
          'Authorization': `Bearer ${getAuthToken()}`
        }
      });

      const data: ApiResponse<Todo[]> = await response.json();
      if (data.success && data.data) {
        setTodos(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch todos:', error);
    } finally {
      setLoadingTodos(false);
    }
  };

  const fetchMessages = async () => {
    setLoadingMessages(true);
    try {
      const response = await fetch(`/api/messages/channel/${selectedChannel}`, {
        headers: {
          'Authorization': `Bearer ${getAuthToken()}`
        }
      });

      const data: ApiResponse<PaginatedResponse<Message>> = await response.json();
      if (data.success && data.data) {
        setMessages(data.data.data);
      }
    } catch (error) {
      console.error('Failed to fetch messages:', error);
    } finally {
      setLoadingMessages(false);
    }
  };

  const fetchNotes = async () => {
    try {
      const response = await fetch(`/api/notes/${selectedChannel}`, {
        headers: {
          'Authorization': `Bearer ${getAuthToken()}`
        }
      });

      const data = await response.json();
      if (data.success && data.data) {
        setNotes(data.data.content || '');
      }
    } catch (error) {
      console.error('Failed to fetch notes:', error);
    }
  };

  const saveNotes = async () => {
    try {
      const response = await fetch('/api/notes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getAuthToken()}`
        },
        body: JSON.stringify({
          channel_id: selectedChannel,
          content: notes
        })
      });

      const data = await response.json();
      if (data.success) {
        console.log('Notes saved successfully');
      }
    } catch (error) {
      console.error('Failed to save notes:', error);
    }
  };

  // Auto-save notes every 5 seconds
  useEffect(() => {
    if (notes && activeTab === 'Notes') {
      const timeoutId = setTimeout(() => {
        saveNotes();
      }, 5000);
      return () => clearTimeout(timeoutId);
    }
  }, [notes, activeTab, selectedChannel]);

  const handleSendMessage = async () => {
    if (!messageText.trim()) return;

    try {
      const messageData: SendMessageRequest = {
        content: messageText,
        channel_id: selectedChannel,
        type: 'text'
      };

      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getAuthToken()}`
        },
        body: JSON.stringify(messageData)
      });

      const data: ApiResponse<Message> = await response.json();
      if (data.success && data.data) {
        setMessages(prev => [...prev, data.data!]);
        setMessageText('');
      }
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const handleCreateChannel = async () => {
    if (!newChannelName.trim()) return;

    try {
      const response = await fetch('/api/channels', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getAuthToken()}`
        },
        body: JSON.stringify({
          name: newChannelName,
          type: 'public',
          description: `Channel created by ${user?.full_name}`
        })
      });

      const data = await response.json();
      if (data.success) {
        setNewChannelName('');
        setShowCreateChannel(false);
        window.location.reload();
      }
    } catch (error) {
      console.error('Failed to create channel:', error);
    }
  };

  const handleInviteUser = async () => {
    if (!inviteEmail.trim()) return;

    try {
      const response = await fetch('/api/workspaces/current/invites', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getAuthToken()}`
        },
        body: JSON.stringify({
          email: inviteEmail,
          role: 'member'
        })
      });

      const data = await response.json();
      if (data.success) {
        setInviteEmail('');
        setShowInviteDialog(false);
        alert('Invitation sent successfully!');
      }
    } catch (error) {
      console.error('Failed to send invitation:', error);
    }
  };

  const handleFileUpload = () => {
    fileInputRef.current?.click();
  };

  const handleFileSelected = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setMessageText(prev => prev + `[File: ${file.name}]`);
    }
  };

  const insertEmoji = (emoji: string) => {
    setMessageText(prev => prev + emoji);
    setShowEmojiPicker(false);
  };

  const formatText = (format: string) => {
    const textarea = document.querySelector('textarea');
    if (textarea) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const selectedText = messageText.slice(start, end);
      
      let formattedText = selectedText;
      switch (format) {
        case 'bold':
          formattedText = `**${selectedText}**`;
          break;
        case 'italic':
          formattedText = `*${selectedText}*`;
          break;
        case 'strikethrough':
          formattedText = `~~${selectedText}~~`;
          break;
        case 'code':
          formattedText = `\`${selectedText}\``;
          break;
        case 'quote':
          formattedText = `> ${selectedText}`;
          break;
      }
      
      const newText = messageText.slice(0, start) + formattedText + messageText.slice(end);
      setMessageText(newText);
    }
  };

  const executeCommand = (command: string) => {
    const [action, ...params] = command.split(' ');
    
    switch (action.toLowerCase()) {
      case 'communication':
        setActiveView('communication');
        break;
      case 'ai':
      case 'collaboration':
        setActiveView('ai-collaboration');
        break;
      case 'automation':
      case 'workflow':
        setActiveView('automation');
        break;
      case 'search':
      case 'intelligence':
        setActiveView('intelligence');
        break;
      case 'admin':
      case 'enterprise':
        setActiveView('enterprise');
        break;
      case 'notes':
        setActiveTab('Notes');
        setActiveView('communication');
        break;
      case 'whiteboard':
        setShowWhiteboard(true);
        break;
      case 'meeting':
        setShowMeetings(true);
        break;
      default:
        console.log('Unknown command:', command);
    }
    
    setShowCommandBar(false);
    setCommandQuery('');
  };

  const renderMainContent = () => {
    switch (activeView) {
      case 'communication':
        return (
          <div className="h-full overflow-y-auto">
            <div className="w-full h-[70px] bg-gradient-to-r from-blue-600 to-cyan-600 text-2xl font-normal leading-8 pt-8 pb-6 text-white text-center">
              🚀 Unified Communication Hub - Messages, Threads, Files & More
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="h-full">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 text-base">
                      <MessageSquare className="h-5 w-5" />
                      Smart Messaging
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 pt-0 h-full flex flex-col">
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Rich formatting & threads
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        @mentions & notifications
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Emoji, GIF, reactions
                      </div>
                    </div>
                    <Button size="sm" className="w-full mt-auto" onClick={() => setActiveTab('Messages')}>
                      Open Messages
                    </Button>
                  </CardContent>
                </Card>

                <Card className="h-full">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Paperclip className="h-5 w-5" />
                      File Collaboration
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 pt-0 h-full flex flex-col">
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Drag & drop uploads
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Live file previews
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Version control
                      </div>
                    </div>
                    <Button size="sm" className="w-full mt-auto" onClick={handleFileUpload}>
                      Upload Files
                    </Button>
                  </CardContent>
                </Card>

                <Card className="h-full">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Star className="h-5 w-5" />
                      Smart Organization
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 pt-0 h-full flex flex-col">
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Pin important messages
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Smart folders
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Bulk actions
                      </div>
                    </div>
                    <Button size="sm" className="w-full mt-auto">
                      Organize
                    </Button>
                  </CardContent>
                </Card>

                <Card className="h-full">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Users className="h-5 w-5" />
                      Team Presence
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 pt-0 h-full flex flex-col">
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Real-time status
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Custom statuses
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Availability sync
                      </div>
                    </div>
                    <Button size="sm" className="w-full mt-auto" onClick={() => setShowProfile(true)}>
                      Set Status
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Enhanced messaging interface */}
              <div className="mt-8">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">Active Conversations</h3>
                  <Button onClick={() => setShowCreateChannel(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    New Channel
                  </Button>
                </div>
                
                <div className="bg-card rounded-lg border p-4">
                  <Tabs value={activeTab} onValueChange={setActiveTab}>
                    <TabsList>
                      <TabsTrigger value="Messages">Messages</TabsTrigger>
                      <TabsTrigger value="Notes">Smart Notes</TabsTrigger>
                      <TabsTrigger value="Files">Files</TabsTrigger>
                      <TabsTrigger value="Threads">Threads</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="Messages" className="mt-4">
                      {/* Message interface would go here */}
                      <div className="space-y-4">
                        {messages.length > 0 ? (
                          messages.map((message) => (
                            <div key={message.id} className="flex items-start space-x-3 p-3 bg-muted rounded-lg">
                              <Avatar className="h-8 w-8">
                                <AvatarFallback className="bg-blue-500 text-white">
                                  {message.sender?.full_name?.split(' ').map(n => n[0]).join('') || 'U'}
                                </AvatarFallback>
                              </Avatar>
                              <div className="flex-1">
                                <div className="flex items-center space-x-2">
                                  <span className="font-semibold">{message.sender?.full_name}</span>
                                  <span className="text-xs text-muted-foreground">
                                    {new Date(message.created_at).toLocaleTimeString()}
                                  </span>
                                </div>
                                <p className="text-sm mt-1">{message.content}</p>
                              </div>
                            </div>
                          ))
                        ) : (
                          <div className="text-center py-8">
                            <MessageSquare className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                            <h3 className="text-lg font-medium mb-2">Start a conversation</h3>
                            <p className="text-muted-foreground">Send your first message to get started</p>
                          </div>
                        )}
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="Notes">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">Channel Notes</h4>
                          <Button size="sm" onClick={saveNotes}>
                            <Save className="h-4 w-4 mr-2" />
                            Save
                          </Button>
                        </div>
                        <Textarea
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                          placeholder="Add notes for this channel... Auto-saves every 5 seconds"
                          className="min-h-[200px]"
                        />
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>
              </div>
            </div>
          </div>
        );

      case 'ai-collaboration':
        return (
          <div className="h-full overflow-y-auto">
            <div className="w-full h-[70px] bg-gradient-to-r from-purple-600 to-pink-600 text-2xl font-normal leading-8 pt-8 pb-6 text-white text-center">
              🧠 AI-Powered Collaboration - Meetings, Whiteboards, Transcription & AI Assistant
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Video className="h-5 w-5" />
                      Smart Meetings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        One-click video calls
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Live transcription & recording
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        AI meeting summaries
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Persistent meeting rooms
                      </div>
                    </div>
                    <Button size="sm" className="w-full" onClick={() => setShowMeetings(true)}>
                      <Video className="h-4 w-4 mr-2" />
                      Start Meeting
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <PenTool className="h-5 w-5" />
                      Collaborative Whiteboard
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Real-time drawing
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Shapes & templates
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Version history
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Export to directory
                      </div>
                    </div>
                    <Button size="sm" className="w-full" onClick={() => setShowWhiteboard(true)}>
                      <PenTool className="h-4 w-4 mr-2" />
                      Open Whiteboard
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Brain className="h-5 w-5" />
                      WAVE AI Assistant
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Meeting summaries
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Action item extraction
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Smart reminders
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Context-aware help
                      </div>
                    </div>
                    <Button size="sm" className="w-full">
                      <Brain className="h-4 w-4 mr-2" />
                      Ask WAVE AI
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BookOpen className="h-5 w-5" />
                      Smart Documentation
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Auto-generated docs
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Knowledge base
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Smart templates
                      </div>
                    </div>
                    <Button size="sm" className="w-full" onClick={() => setShowKnowledgeBase(true)}>
                      <BookOpen className="h-4 w-4 mr-2" />
                      Knowledge Base
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Mic className="h-5 w-5" />
                      Voice & Audio
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Voice messages
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Audio transcription
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Waveform visualization
                      </div>
                    </div>
                    <Button size="sm" className="w-full">
                      <Mic className="h-4 w-4 mr-2" />
                      Record Voice
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Sparkles className="h-5 w-5" />
                      AI Insights
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Sentiment analysis
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Team health metrics
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Performance insights
                      </div>
                    </div>
                    <Button size="sm" className="w-full">
                      <Sparkles className="h-4 w-4 mr-2" />
                      View Insights
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );

      case 'automation':
        return (
          <div className="h-full overflow-y-auto">
            <div className="w-full h-[70px] bg-gradient-to-r from-green-600 to-teal-600 text-2xl font-normal leading-8 pt-8 pb-6 text-white text-center">
              ⚡ Workflow & Automation Center - CRM, Tasks, Integrations & Approval Flows
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Workflow className="h-5 w-5" />
                      Visual Workflows
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Drag-and-drop builder
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Pre-built templates
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Approval workflows
                      </div>
                    </div>
                    <Button size="sm" className="w-full" onClick={() => setShowWorkflows(true)}>
                      <Workflow className="h-4 w-4 mr-2" />
                      Build Workflow
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5" />
                      Task Management
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        AI-extracted action items
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Smart reminders
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Progress tracking
                      </div>
                    </div>
                    <Button size="sm" className="w-full" onClick={() => setActiveTab('To-do list')}>
                      <Target className="h-4 w-4 mr-2" />
                      Manage Tasks
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Handshake className="h-5 w-5" />
                      CRM Integration
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Client conversations
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Deal tracking
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Document approvals
                      </div>
                    </div>
                    <Button size="sm" className="w-full">
                      <Handshake className="h-4 w-4 mr-2" />
                      CRM Dashboard
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Briefcase className="h-5 w-5" />
                      App Marketplace
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        50+ integrations
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        OAuth & webhooks
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Custom connectors
                      </div>
                    </div>
                    <Button size="sm" className="w-full" onClick={() => setShowAppsDirectory(true)}>
                      <Briefcase className="h-4 w-4 mr-2" />
                      Browse Apps
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Active Workflows</CardTitle>
                    <CardDescription>Monitor your automated processes</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="font-medium">PTO Approval</span>
                        </div>
                        <Badge variant="secondary">Running</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                          <span className="font-medium">Client Onboarding</span>
                        </div>
                        <Badge variant="secondary">Active</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                          <span className="font-medium">Invoice Processing</span>
                        </div>
                        <Badge variant="secondary">Pending</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                    <CardDescription>Frequently used automation shortcuts</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-3">
                      <Button variant="outline" size="sm">
                        <Timer className="h-4 w-4 mr-2" />
                        Set Reminder
                      </Button>
                      <Button variant="outline" size="sm">
                        <UserCheck className="h-4 w-4 mr-2" />
                        Request Approval
                      </Button>
                      <Button variant="outline" size="sm">
                        <Calendar className="h-4 w-4 mr-2" />
                        Schedule Meeting
                      </Button>
                      <Button variant="outline" size="sm">
                        <FileText className="h-4 w-4 mr-2" />
                        Create Document
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );

      case 'intelligence':
        return (
          <div className="h-full overflow-y-auto">
            <div className="w-full h-[70px] bg-gradient-to-r from-orange-600 to-red-600 text-2xl font-normal leading-8 pt-8 pb-6 text-white text-center">
              🔍 Intelligence & Search - Universal Search, Analytics & Knowledge Discovery
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Search className="h-5 w-5" />
                      Universal Search
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Cross-platform search
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Natural language queries
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Semantic understanding
                      </div>
                    </div>
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search anything..."
                        className="pl-9"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5" />
                      Analytics Dashboard
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Team productivity metrics
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Communication patterns
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Performance insights
                      </div>
                    </div>
                    <Button size="sm" className="w-full">
                      <BarChart3 className="h-4 w-4 mr-2" />
                      View Analytics
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Database className="h-5 w-5" />
                      Knowledge Hub
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Auto-generated wiki
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Smart categorization
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Contextual recommendations
                      </div>
                    </div>
                    <Button size="sm" className="w-full" onClick={() => setShowKnowledgeBase(true)}>
                      <Database className="h-4 w-4 mr-2" />
                      Explore Knowledge
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5" />
                      Sentiment Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Team mood tracking
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Project health scores
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Early warning alerts
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Team Sentiment</span>
                        <span className="font-medium">85%</span>
                      </div>
                      <Progress value={85} className="h-2" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Radar className="h-5 w-5" />
                      Smart Discovery
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Topic extraction
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Trend identification
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Content suggestions
                      </div>
                    </div>
                    <Button size="sm" className="w-full">
                      <Radar className="h-4 w-4 mr-2" />
                      Discover Insights
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Command className="h-5 w-5" />
                      Quick Commands
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Slash commands
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Keyboard shortcuts
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Voice commands
                      </div>
                    </div>
                    <Button size="sm" className="w-full" onClick={() => setShowCommandBar(true)}>
                      <Command className="h-4 w-4 mr-2" />
                      Open Command Bar
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <div className="mt-8">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Search Results</CardTitle>
                    <CardDescription>Your most relevant findings</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {searchQuery ? (
                      <div className="space-y-3">
                        <div className="p-3 border rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <MessageSquare className="h-4 w-4 text-blue-500" />
                            <span className="font-medium">Message Result</span>
                          </div>
                          <p className="text-sm text-muted-foreground">Found in #general channel</p>
                        </div>
                        <div className="p-3 border rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <FileText className="h-4 w-4 text-green-500" />
                            <span className="font-medium">Document Result</span>
                          </div>
                          <p className="text-sm text-muted-foreground">Meeting notes from last week</p>
                        </div>
                        <div className="p-3 border rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <PenTool className="h-4 w-4 text-purple-500" />
                            <span className="font-medium">Whiteboard Result</span>
                          </div>
                          <p className="text-sm text-muted-foreground">Project planning session</p>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <Search className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                        <h3 className="text-lg font-medium mb-2">Start searching</h3>
                        <p className="text-muted-foreground">Enter a query to search across all your content</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );

      case 'enterprise':
        return (
          <div className="h-full overflow-y-auto">
            <div className="w-full h-[70px] bg-gradient-to-r from-red-600 to-purple-600 text-2xl font-normal leading-8 pt-8 pb-6 text-white text-center">
              🛡️ Enterprise Control Center - Security, Compliance, Admin & Monitoring
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="h-5 w-5" />
                      Security & Compliance
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        SSO/SAML integration
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        End-to-end encryption
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        GDPR/CCPA compliance
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Audit logging
                      </div>
                    </div>
                    <Button size="sm" className="w-full" onClick={() => setShowAdminPanel(true)}>
                      <Shield className="h-4 w-4 mr-2" />
                      Security Center
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users2 className="h-5 w-5" />
                      User Management
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Role-based access
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        SCIM provisioning
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Group policies
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Onboarding flows
                      </div>
                    </div>
                    <Button size="sm" className="w-full" onClick={() => setShowInviteDialog(true)}>
                      <Users2 className="h-4 w-4 mr-2" />
                      Manage Users
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Gauge className="h-5 w-5" />
                      Performance Monitor
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Real-time metrics
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Load balancing
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Auto-scaling
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Health checks
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>System Health</span>
                        <span className="font-medium text-green-600">99.9%</span>
                      </div>
                      <Progress value={99.9} className="h-2" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <DollarSign className="h-5 w-5" />
                      Billing & Subscriptions
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Usage tracking
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Invoice management
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Plan optimization
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Cost analytics
                      </div>
                    </div>
                    <Button size="sm" className="w-full">
                      <DollarSign className="h-4 w-4 mr-2" />
                      Billing Portal
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>System Status</CardTitle>
                    <CardDescription>Real-time platform health</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span>API Services</span>
                        </div>
                        <Badge variant="secondary" className="bg-green-100 text-green-800">Operational</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span>Database</span>
                        </div>
                        <Badge variant="secondary" className="bg-green-100 text-green-800">Operational</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span>WebSocket Services</span>
                        </div>
                        <Badge variant="secondary" className="bg-green-100 text-green-800">Operational</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                          <span>File Storage</span>
                        </div>
                        <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">Maintenance</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Quick Admin Actions</CardTitle>
                    <CardDescription>Frequently used administrative tasks</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-3">
                      <Button variant="outline" size="sm">
                        <UserPlus className="h-4 w-4 mr-2" />
                        Add User
                      </Button>
                      <Button variant="outline" size="sm">
                        <Building className="h-4 w-4 mr-2" />
                        Create Workspace
                      </Button>
                      <Button variant="outline" size="sm">
                        <Lock className="h-4 w-4 mr-2" />
                        Security Audit
                      </Button>
                      <Button variant="outline" size="sm">
                        <BarChart3 className="h-4 w-4 mr-2" />
                        Usage Report
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );

      default:
        return renderMainContent();
    }
  };

  if (!user) {
    return null;
  }

  return (
    <div className="flex h-screen bg-slate-900 text-white">
      {/* Vertical Navigation Sidebar */}
      <div className="w-20 bg-purple-700 flex flex-col items-center py-4">
        {/* Logo */}
        <div className="w-12 h-12 bg-gray-200 rounded-lg flex items-center justify-center mb-6">
          <span className="text-lg font-bold text-purple-600">WA</span>
        </div>

        {/* Navigation Items */}
        <div className="flex flex-col space-y-4 flex-1">
          {navItems.map((item) => (
            <button
              key={item.label}
              onClick={() => setActiveView(item.view)}
              className={`w-12 h-12 rounded-lg flex flex-col items-center justify-center text-xs ${
                activeView === item.view 
                  ? `${item.color} text-white` 
                  : 'text-purple-200 hover:bg-purple-600 hover:text-white'
              }`}
              title={item.label}
            >
              <item.icon className="h-5 w-5 mb-1" />
            </button>
          ))}
        </div>

        {/* Add Button */}
        <Button
          className="w-12 h-12 rounded-full bg-purple-600 hover:bg-purple-500 mb-4"
          onClick={() => setShowCreateChannel(true)}
        >
          <Plus className="h-6 w-6" />
        </Button>

        {/* User Profile */}
        <Popover open={showProfile} onOpenChange={setShowProfile}>
          <PopoverTrigger asChild>
            <div className="relative cursor-pointer">
              <Avatar className="h-12 w-12">
                <AvatarFallback className="text-sm bg-green-500 text-white">
                  {user.full_name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div className="absolute -bottom-1 -right-1 h-4 w-4 bg-green-500 rounded-full border-2 border-purple-700" />
            </div>
          </PopoverTrigger>
          <PopoverContent className="w-80" side="right">
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Avatar className="h-12 w-12">
                  <AvatarFallback className="bg-green-500 text-white">
                    {user.full_name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold">{user.full_name}</h3>
                  <p className="text-sm text-muted-foreground">{user.email}</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <span className="text-sm">Status:</span>
                  <Select value={userStatus} onValueChange={setUserStatus}>
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Active">🟢 Active</SelectItem>
                      <SelectItem value="Away">🟡 Away</SelectItem>
                      <SelectItem value="Do not disturb">🔴 Do not disturb</SelectItem>
                      <SelectItem value="Invisible">⚫ Invisible</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <span className="text-sm">Custom Status:</span>
                  <Input
                    placeholder="What's your status?"
                    value={customStatus}
                    onChange={(e) => setCustomStatus(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Profile
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Settings className="h-4 w-4 mr-2" />
                  Preferences
                </Button>
                <Button variant="outline" className="w-full justify-start" onClick={logout}>
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out
                </Button>
              </div>
            </div>
          </PopoverContent>
        </Popover>
      </div>

      {/* Right Sidebar with Channels */}
      <div className="w-64 bg-purple-800 flex flex-col">
        {/* Workspace Header */}
        <div className="p-4 bg-purple-900">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-white rounded-sm flex items-center justify-center">
                <span className="text-xs font-bold text-purple-600">WA</span>
              </div>
              <span className="text-white font-semibold text-sm">WAVE AI Workspace</span>
              <ChevronDown className="h-4 w-4 text-white" />
            </div>
          </div>
        </div>

        <ScrollArea className="flex-1">
          {/* Channels Section */}
          <div className="px-3 py-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-purple-200 text-sm font-medium">Channels</span>
              <Plus 
                className="h-4 w-4 text-purple-200 cursor-pointer hover:text-white" 
                onClick={() => setShowCreateChannel(true)}
              />
            </div>
            
            <div className="space-y-1">
              {channels.map((channel) => (
                <button
                  key={channel.id}
                  onClick={() => {
                    setSelectedChannel(channel.id);
                    setActiveView('communication');
                    setActiveTab('Messages');
                  }}
                  className={`w-full flex items-center space-x-2 px-2 py-1 rounded text-sm ${
                    selectedChannel === channel.id && activeView === 'communication'
                      ? 'bg-purple-600 text-white' 
                      : 'text-purple-200 hover:bg-purple-600 hover:text-white'
                  }`}
                >
                  <Hash className="h-4 w-4" />
                  <span>{channel.name}</span>
                </button>
              ))}
              <button 
                onClick={() => setShowCreateChannel(true)}
                className="w-full flex items-center space-x-2 px-2 py-1 rounded text-sm text-purple-200 hover:bg-purple-600 hover:text-white"
              >
                <Plus className="h-4 w-4" />
                <span>Add channels</span>
              </button>
            </div>

            {/* Direct Messages */}
            <div className="mt-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-purple-200 text-sm font-medium">Direct messages</span>
                <Plus 
                  className="h-4 w-4 text-purple-200 cursor-pointer hover:text-white" 
                  onClick={() => setShowInviteDialog(true)}
                />
              </div>
              
              <div className="space-y-1">
                <div className="flex items-center space-x-2 px-2 py-1 rounded text-sm bg-purple-600 text-white">
                  <div className="relative">
                    <Avatar className="h-5 w-5">
                      <AvatarFallback className="text-xs bg-green-500 text-white">
                        {user.full_name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 bg-green-500 rounded-full border border-purple-800" />
                  </div>
                  <span>{user.full_name} (you)</span>
                </div>
                
                <button 
                  onClick={() => setShowInviteDialog(true)}
                  className="w-full flex items-center space-x-2 px-2 py-1 rounded text-sm text-purple-200 hover:bg-purple-600 hover:text-white"
                >
                  <Plus className="h-4 w-4" />
                  <span>Invite people</span>
                </button>
              </div>
            </div>

            {/* Apps Section */}
            <div className="mt-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-purple-200 text-sm font-medium">Apps</span>
                <Plus 
                  className="h-4 w-4 text-purple-200 cursor-pointer hover:text-white" 
                  onClick={() => setShowAppsDirectory(true)}
                />
              </div>
              
              <div className="space-y-1">
                <button className="w-full flex items-center justify-start space-x-2 px-2 py-1 rounded text-sm text-purple-200 hover:bg-purple-600 hover:text-white">
                  <div className="w-5 h-5 bg-blue-500 rounded flex items-center justify-center">
                    <Wand2 className="h-3 w-3 text-white" />
                  </div>
                  <span>WAVE AI Bot</span>
                </button>
                
                <button 
                  onClick={() => setShowAppsDirectory(true)}
                  className="w-full flex items-center space-x-2 px-2 py-1 rounded text-sm text-purple-200 hover:bg-purple-600 hover:text-white"
                >
                  <Plus className="h-4 w-4" />
                  <span>Add apps</span>
                </button>
              </div>
            </div>
          </div>
        </ScrollArea>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 bg-slate-800 flex flex-col overflow-hidden">
        {renderMainContent()}
      </div>

      {/* Command Bar */}
      {showCommandBar && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-96">
            <div className="flex items-center space-x-2 mb-4">
              <Zap className="h-5 w-5 text-gray-500" />
              <Input
                value={commandQuery}
                onChange={(e) => setCommandQuery(e.target.value)}
                placeholder="Type a command (communication, ai, automation, intelligence, enterprise)"
                className="flex-1"
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    executeCommand(commandQuery);
                  }
                }}
                autoFocus
              />
            </div>
            <div className="text-sm text-gray-500">
              Available commands: communication, ai-collaboration, automation, intelligence, enterprise
            </div>
          </div>
        </div>
      )}

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        className="hidden"
        onChange={handleFileSelected}
        multiple
      />

      {/* Dialogs and Modals */}
      <Dialog open={showCreateChannel} onOpenChange={setShowCreateChannel}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create a Channel</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Channel Name</label>
              <Input
                placeholder="e.g. marketing"
                value={newChannelName}
                onChange={(e) => setNewChannelName(e.target.value)}
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowCreateChannel(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreateChannel}>
                Create Channel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Invite People to WAVE AI</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Email Address</label>
              <Input
                placeholder="colleague@company.com"
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e.target.value)}
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowInviteDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleInviteUser}>
                Send Invitation
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Enterprise Feature Modals */}
      {showAppsDirectory && (
        <Dialog open={showAppsDirectory} onOpenChange={setShowAppsDirectory}>
          <DialogContent className="max-w-6xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle>WAVE AI App Directory</DialogTitle>
            </DialogHeader>
            <ScrollArea className="h-[70vh]">
              <AppDirectory />
            </ScrollArea>
          </DialogContent>
        </Dialog>
      )}

      {showWorkflows && (
        <Dialog open={showWorkflows} onOpenChange={setShowWorkflows}>
          <DialogContent className="max-w-6xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle>WAVE AI Workflow Builder</DialogTitle>
            </DialogHeader>
            <ScrollArea className="h-[70vh]">
              <WorkflowBuilder />
            </ScrollArea>
          </DialogContent>
        </Dialog>
      )}

      {showMeetings && (
        <Dialog open={showMeetings} onOpenChange={setShowMeetings}>
          <DialogContent className="max-w-6xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle>WAVE AI Meeting Rooms</DialogTitle>
            </DialogHeader>
            <ScrollArea className="h-[70vh]">
              <MeetingRooms />
            </ScrollArea>
          </DialogContent>
        </Dialog>
      )}

      {showKnowledgeBase && (
        <Dialog open={showKnowledgeBase} onOpenChange={setShowKnowledgeBase}>
          <DialogContent className="max-w-6xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle>WAVE AI Knowledge Base</DialogTitle>
            </DialogHeader>
            <ScrollArea className="h-[70vh]">
              <KnowledgeBase />
            </ScrollArea>
          </DialogContent>
        </Dialog>
      )}

      {showWhiteboard && (
        <Dialog open={showWhiteboard} onOpenChange={setShowWhiteboard}>
          <DialogContent className="max-w-7xl max-h-[90vh] p-0">
            <DialogHeader className="px-6 py-4">
              <DialogTitle>WAVE AI Collaborative Whiteboard</DialogTitle>
            </DialogHeader>
            <div className="h-[80vh]">
              <EnhancedWhiteboard
                channelId={selectedChannel}
                workspaceId="workspace-1"
                userId={user?.id || 'user-123'}
                onClose={() => setShowWhiteboard(false)}
              />
            </div>
          </DialogContent>
        </Dialog>
      )}

      {showAdminPanel && (
        <Dialog open={showAdminPanel} onOpenChange={setShowAdminPanel}>
          <DialogContent className="max-w-6xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle>WAVE AI Enterprise Control Center</DialogTitle>
            </DialogHeader>
            <ScrollArea className="h-[70vh]">
              <div className="space-y-6">
                <Tabs defaultValue="overview">
                  <TabsList>
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="users">Users</TabsTrigger>
                    <TabsTrigger value="security">Security</TabsTrigger>
                    <TabsTrigger value="analytics">Analytics</TabsTrigger>
                    <TabsTrigger value="billing">Billing</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="overview" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <Card>
                        <CardContent className="p-4">
                          <div className="text-2xl font-bold">1,234</div>
                          <div className="text-sm text-muted-foreground">Total Users</div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-4">
                          <div className="text-2xl font-bold">56</div>
                          <div className="text-sm text-muted-foreground">Active Channels</div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-4">
                          <div className="text-2xl font-bold">8,910</div>
                          <div className="text-sm text-muted-foreground">Messages Today</div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-4">
                          <div className="text-2xl font-bold">99.9%</div>
                          <div className="text-sm text-muted-foreground">Uptime</div>
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="users" className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="font-semibold">User Management</h3>
                      <Button>
                        <UserPlus className="h-4 w-4 mr-2" />
                        Add User
                      </Button>
                    </div>
                    <Card>
                      <CardContent className="p-4">
                        <div className="space-y-4">
                          <div className="flex items-center justify-between p-3 border rounded">
                            <div className="flex items-center space-x-3">
                              <Avatar>
                                <AvatarFallback>{user.full_name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-medium">{user.full_name}</div>
                                <div className="text-sm text-muted-foreground">{user.email}</div>
                              </div>
                            </div>
                            <Badge>Admin</Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                  
                  <TabsContent value="security" className="space-y-4">
                    <h3 className="font-semibold">Security Settings</h3>
                    <div className="space-y-4">
                      <Card>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-medium">Two-Factor Authentication</h4>
                              <p className="text-sm text-muted-foreground">Require 2FA for all users</p>
                            </div>
                            <Switch />
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-medium">SSO Integration</h4>
                              <p className="text-sm text-muted-foreground">Enable single sign-on</p>
                            </div>
                            <Switch />
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-medium">WAVE AI Security Monitoring</h4>
                              <p className="text-sm text-muted-foreground">AI-powered threat detection</p>
                            </div>
                            <Switch defaultChecked />
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="analytics" className="space-y-4">
                    <h3 className="font-semibold">WAVE AI Analytics Dashboard</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card>
                        <CardHeader>
                          <CardTitle>Message Activity</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="h-32 bg-muted rounded flex items-center justify-center">
                            <BarChart3 className="h-8 w-8 text-muted-foreground" />
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader>
                          <CardTitle>AI Features Usage</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="h-32 bg-muted rounded flex items-center justify-center">
                            <Brain className="h-8 w-8 text-muted-foreground" />
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>

                  <TabsContent value="billing" className="space-y-4">
                    <h3 className="font-semibold">Billing & Subscriptions</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card>
                        <CardHeader>
                          <CardTitle>Current Plan</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <div className="text-2xl font-bold">Enterprise Pro</div>
                            <div className="text-sm text-muted-foreground">$29/user/month</div>
                            <div className="text-sm">Next billing: Dec 1, 2024</div>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader>
                          <CardTitle>Usage This Month</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <div className="flex justify-between">
                              <span>Active Users</span>
                              <span>1,234 / 1,500</span>
                            </div>
                            <Progress value={82} />
                            <div className="flex justify-between">
                              <span>Storage</span>
                              <span>850GB / 1TB</span>
                            </div>
                            <Progress value={85} />
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </ScrollArea>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
