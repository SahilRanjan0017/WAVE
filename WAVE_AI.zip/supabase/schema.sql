-- =====================================================
-- WAVE AI - Complete Supabase Database Schema with RLS
-- =====================================================

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. CORE USER MANAGEMENT SECTION
-- =====================================================

-- User Profiles (linked to Supabase Auth)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users (id) ON DELETE CASCADE,
  username VARCHAR(24) NOT NULL UNIQUE,
  display_name VARCHAR(64),
  avatar_url TEXT,
  status_text VARCHAR(128),
  status_emoji VARCHAR(10),
  presence_status VARCHAR(20) DEFAULT 'offline' CHECK (presence_status IN ('online', 'away', 'busy', 'offline')),
  organization_id UUID,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now())
);

-- Workspaces
CREATE TABLE IF NOT EXISTS public.workspaces (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(64) NOT NULL UNIQUE,
  domain VARCHAR(128) UNIQUE,
  brand_color VARCHAR(8) DEFAULT '#6B46C1',
  logo_url TEXT,
  description TEXT,
  settings JSONB DEFAULT '{}',
  created_by UUID REFERENCES public.profiles (id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now())
);

-- Workspace Memberships
CREATE TABLE IF NOT EXISTS public.memberships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles (id) ON DELETE CASCADE,
  workspace_id UUID REFERENCES public.workspaces (id) ON DELETE CASCADE,
  role VARCHAR(32) NOT NULL DEFAULT 'member' CHECK (role IN ('owner', 'admin', 'member', 'guest')),
  permissions JSONB DEFAULT '{}',
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  UNIQUE(user_id, workspace_id)
);

-- 2. COMMUNICATION SECTION
-- =====================================================

-- Channels (public and private)
CREATE TABLE IF NOT EXISTS public.channels (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID REFERENCES public.workspaces(id) ON DELETE CASCADE,
  name VARCHAR(64) NOT NULL,
  display_name VARCHAR(64),
  description TEXT,
  is_private BOOLEAN NOT NULL DEFAULT false,
  is_archived BOOLEAN DEFAULT false,
  topic VARCHAR(250),
  purpose VARCHAR(250),
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  UNIQUE(workspace_id, name)
);

-- Channel Memberships
CREATE TABLE IF NOT EXISTS public.channel_memberships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id UUID REFERENCES public.channels(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  role VARCHAR(32) DEFAULT 'member' CHECK (role IN ('owner', 'admin', 'member')),
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  UNIQUE(channel_id, user_id)
);

-- Direct Message Groups
CREATE TABLE IF NOT EXISTS public.dm_groups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID REFERENCES public.workspaces(id) ON DELETE CASCADE,
  is_group BOOLEAN NOT NULL DEFAULT false,
  name VARCHAR(64),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now())
);

-- DM Group Members
CREATE TABLE IF NOT EXISTS public.dm_group_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dm_group_id UUID REFERENCES public.dm_groups(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  UNIQUE(dm_group_id, user_id)
);

-- Messages (channels or DMs)
CREATE TABLE IF NOT EXISTS public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id UUID REFERENCES public.channels(id) ON DELETE CASCADE,
  dm_group_id UUID REFERENCES public.dm_groups(id) ON DELETE CASCADE,
  author_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  content TEXT NOT NULL,
  message_type VARCHAR(16) DEFAULT 'text' CHECK (message_type IN ('text', 'file', 'image', 'video', 'audio', 'system')),
  parent_message_id UUID REFERENCES public.messages(id),
  thread_count INTEGER DEFAULT 0,
  reactions JSONB DEFAULT '{}',
  metadata JSONB DEFAULT '{}',
  is_edited BOOLEAN DEFAULT false,
  edited_at TIMESTAMP WITH TIME ZONE,
  is_pinned BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  CHECK ((channel_id IS NOT NULL) OR (dm_group_id IS NOT NULL))
);

-- File Attachments
CREATE TABLE IF NOT EXISTS public.attachments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id UUID REFERENCES public.messages(id) ON DELETE CASCADE,
  file_url TEXT NOT NULL,
  file_name VARCHAR(255),
  file_type VARCHAR(64),
  file_size INTEGER,
  uploaded_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now())
);

-- 3. AI COLLABORATION SECTION
-- =====================================================

-- Notes (Per Channel or DM)
CREATE TABLE IF NOT EXISTS public.notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id UUID REFERENCES public.channels(id) ON DELETE CASCADE,
  dm_group_id UUID REFERENCES public.dm_groups(id) ON DELETE CASCADE,
  created_by UUID REFERENCES public.profiles(id),
  content TEXT NOT NULL,
  version INTEGER DEFAULT 1,
  is_collaborative BOOLEAN DEFAULT true,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  CHECK ((channel_id IS NOT NULL) OR (dm_group_id IS NOT NULL))
);

-- Whiteboards
CREATE TABLE IF NOT EXISTS public.whiteboards (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID REFERENCES public.workspaces(id) ON DELETE CASCADE,
  channel_id UUID REFERENCES public.channels(id) ON DELETE CASCADE,
  dm_group_id UUID REFERENCES public.dm_groups(id) ON DELETE CASCADE,
  created_by UUID REFERENCES public.profiles(id),
  name VARCHAR(64) NOT NULL,
  description TEXT,
  thumbnail_url TEXT,
  board_data JSONB NOT NULL DEFAULT '{}',
  version INTEGER DEFAULT 1,
  is_template BOOLEAN DEFAULT false,
  collaborators UUID[] DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now())
);

-- Meetings
CREATE TABLE IF NOT EXISTS public.meetings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID REFERENCES public.workspaces(id) ON DELETE CASCADE,
  channel_id UUID REFERENCES public.channels(id) ON DELETE CASCADE,
  host_id UUID REFERENCES public.profiles(id),
  title VARCHAR(128) NOT NULL,
  description TEXT,
  start_time TIMESTAMP WITH TIME ZONE,
  end_time TIMESTAMP WITH TIME ZONE,
  meeting_type VARCHAR(32) DEFAULT 'scheduled' CHECK (meeting_type IN ('instant', 'scheduled', 'recurring')),
  status VARCHAR(32) DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'active', 'ended', 'cancelled')),
  recording_url TEXT,
  transcript TEXT,
  summary TEXT,
  action_items TEXT[],
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now())
);

-- Meeting Participants
CREATE TABLE IF NOT EXISTS public.meeting_participants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id UUID REFERENCES public.meetings(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.profiles(id),
  role VARCHAR(32) DEFAULT 'participant' CHECK (role IN ('host', 'co-host', 'participant')),
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  left_at TIMESTAMP WITH TIME ZONE,
  duration_minutes INTEGER
);

-- 4. AUTOMATION & WORKFLOW SECTION
-- =====================================================

-- Action Items (AI/Workflow-extracted TODOs)
CREATE TABLE IF NOT EXISTS public.action_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID REFERENCES public.workspaces(id),
  channel_id UUID REFERENCES public.channels(id),
  meeting_id UUID REFERENCES public.meetings(id),
  message_id UUID REFERENCES public.messages(id),
  assigned_to UUID REFERENCES public.profiles(id),
  created_by UUID REFERENCES public.profiles(id),
  title VARCHAR(255) NOT NULL,
  description TEXT,
  priority VARCHAR(16) DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  status VARCHAR(24) DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'completed', 'cancelled')),
  due_date TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  tags TEXT[],
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now())
);

-- Workflows
CREATE TABLE IF NOT EXISTS public.workflows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID REFERENCES public.workspaces(id) ON DELETE CASCADE,
  created_by UUID REFERENCES public.profiles(id),
  name VARCHAR(128) NOT NULL,
  description TEXT,
  trigger_type VARCHAR(64) NOT NULL,
  trigger_config JSONB DEFAULT '{}',
  actions JSONB NOT NULL DEFAULT '[]',
  is_active BOOLEAN DEFAULT true,
  execution_count INTEGER DEFAULT 0,
  last_executed TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now())
);

-- Workflow Executions
CREATE TABLE IF NOT EXISTS public.workflow_executions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_id UUID REFERENCES public.workflows(id) ON DELETE CASCADE,
  triggered_by UUID REFERENCES public.profiles(id),
  status VARCHAR(32) DEFAULT 'running' CHECK (status IN ('running', 'completed', 'failed', 'cancelled')),
  input_data JSONB DEFAULT '{}',
  output_data JSONB DEFAULT '{}',
  error_message TEXT,
  started_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  completed_at TIMESTAMP WITH TIME ZONE
);

-- 5. ENTERPRISE CONTROL SECTION
-- =====================================================

-- Notifications
CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  workspace_id UUID REFERENCES public.workspaces(id) ON DELETE CASCADE,
  title VARCHAR(255),
  content TEXT,
  type VARCHAR(24) NOT NULL,
  priority VARCHAR(16) DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
  action_url TEXT,
  metadata JSONB DEFAULT '{}',
  read BOOLEAN DEFAULT false,
  read_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now())
);

-- Audit Logs
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID REFERENCES public.workspaces(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.profiles(id),
  action VARCHAR(64) NOT NULL,
  resource_type VARCHAR(64),
  resource_id UUID,
  details JSONB DEFAULT '{}',
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now())
);

-- Integrations
CREATE TABLE IF NOT EXISTS public.integrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID REFERENCES public.workspaces(id) ON DELETE CASCADE,
  name VARCHAR(64) NOT NULL,
  type VARCHAR(64) NOT NULL,
  config JSONB NOT NULL DEFAULT '{}',
  is_active BOOLEAN DEFAULT true,
  installed_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now()),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now())
);

-- =====================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- =====================================================

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workspaces ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.channels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.channel_memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dm_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dm_group_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attachments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.whiteboards ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.meetings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.meeting_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.action_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workflows ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workflow_executions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.integrations ENABLE ROW LEVEL SECURITY;

-- RLS Policies for Profiles
CREATE POLICY "Users can view their own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update their own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can view profiles in their workspaces" ON public.profiles FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.memberships m1, public.memberships m2 
    WHERE m1.user_id = auth.uid() AND m2.user_id = profiles.id AND m1.workspace_id = m2.workspace_id
  )
);

-- RLS Policies for Workspaces
CREATE POLICY "Users can view their workspaces" ON public.workspaces FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.memberships WHERE user_id = auth.uid() AND workspace_id = workspaces.id)
);
CREATE POLICY "Workspace admins can update workspaces" ON public.workspaces FOR UPDATE USING (
  EXISTS (SELECT 1 FROM public.memberships WHERE user_id = auth.uid() AND workspace_id = workspaces.id AND role IN ('owner', 'admin'))
);

-- RLS Policies for Messages
CREATE POLICY "Users can view messages in their channels" ON public.messages FOR SELECT USING (
  (channel_id IS NOT NULL AND EXISTS (
    SELECT 1 FROM public.channel_memberships cm, public.channels c
    WHERE cm.user_id = auth.uid() AND cm.channel_id = messages.channel_id 
    AND c.id = messages.channel_id AND (c.is_private = false OR cm.channel_id IS NOT NULL)
  )) OR
  (dm_group_id IS NOT NULL AND EXISTS (
    SELECT 1 FROM public.dm_group_members dm
    WHERE dm.user_id = auth.uid() AND dm.dm_group_id = messages.dm_group_id
  ))
);

CREATE POLICY "Users can insert messages in their channels" ON public.messages FOR INSERT WITH CHECK (
  auth.uid() = author_id AND (
    (channel_id IS NOT NULL AND EXISTS (
      SELECT 1 FROM public.channel_memberships WHERE user_id = auth.uid() AND channel_id = messages.channel_id
    )) OR
    (dm_group_id IS NOT NULL AND EXISTS (
      SELECT 1 FROM public.dm_group_members WHERE user_id = auth.uid() AND dm_group_id = messages.dm_group_id
    ))
  )
);

-- RLS Policies for Notes
CREATE POLICY "Users can view notes in their channels/DMs" ON public.notes FOR SELECT USING (
  (channel_id IS NOT NULL AND EXISTS (
    SELECT 1 FROM public.channel_memberships WHERE user_id = auth.uid() AND channel_id = notes.channel_id
  )) OR
  (dm_group_id IS NOT NULL AND EXISTS (
    SELECT 1 FROM public.dm_group_members WHERE user_id = auth.uid() AND dm_group_id = notes.dm_group_id
  ))
);

CREATE POLICY "Users can modify notes in their channels/DMs" ON public.notes FOR ALL USING (
  (channel_id IS NOT NULL AND EXISTS (
    SELECT 1 FROM public.channel_memberships WHERE user_id = auth.uid() AND channel_id = notes.channel_id
  )) OR
  (dm_group_id IS NOT NULL AND EXISTS (
    SELECT 1 FROM public.dm_group_members WHERE user_id = auth.uid() AND dm_group_id = notes.dm_group_id
  ))
);

-- RLS Policies for Whiteboards
CREATE POLICY "Users can view whiteboards in their workspace" ON public.whiteboards FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.memberships WHERE user_id = auth.uid() AND workspace_id = whiteboards.workspace_id)
);

CREATE POLICY "Users can create whiteboards in their workspace" ON public.whiteboards FOR INSERT WITH CHECK (
  auth.uid() = created_by AND 
  EXISTS (SELECT 1 FROM public.memberships WHERE user_id = auth.uid() AND workspace_id = whiteboards.workspace_id)
);

CREATE POLICY "Users can update their own whiteboards or collaborative ones" ON public.whiteboards FOR UPDATE USING (
  created_by = auth.uid() OR auth.uid() = ANY(collaborators) OR
  EXISTS (SELECT 1 FROM public.memberships WHERE user_id = auth.uid() AND workspace_id = whiteboards.workspace_id AND role IN ('owner', 'admin'))
);

-- =====================================================
-- FUNCTIONS AND TRIGGERS
-- =====================================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = timezone('utc', now());
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_workspaces_updated_at BEFORE UPDATE ON public.workspaces FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_channels_updated_at BEFORE UPDATE ON public.channels FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_messages_updated_at BEFORE UPDATE ON public.messages FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_notes_updated_at BEFORE UPDATE ON public.notes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_whiteboards_updated_at BEFORE UPDATE ON public.whiteboards FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_meetings_updated_at BEFORE UPDATE ON public.meetings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_action_items_updated_at BEFORE UPDATE ON public.action_items FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_workflows_updated_at BEFORE UPDATE ON public.workflows FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_integrations_updated_at BEFORE UPDATE ON public.integrations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================

-- Messages indexes
CREATE INDEX IF NOT EXISTS idx_messages_channel_id ON public.messages(channel_id);
CREATE INDEX IF NOT EXISTS idx_messages_dm_group_id ON public.messages(dm_group_id);
CREATE INDEX IF NOT EXISTS idx_messages_author_id ON public.messages(author_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON public.messages(created_at);
CREATE INDEX IF NOT EXISTS idx_messages_parent_id ON public.messages(parent_message_id);

-- Channel memberships indexes
CREATE INDEX IF NOT EXISTS idx_channel_memberships_user_id ON public.channel_memberships(user_id);
CREATE INDEX IF NOT EXISTS idx_channel_memberships_channel_id ON public.channel_memberships(channel_id);

-- Workspace memberships indexes
CREATE INDEX IF NOT EXISTS idx_memberships_user_id ON public.memberships(user_id);
CREATE INDEX IF NOT EXISTS idx_memberships_workspace_id ON public.memberships(workspace_id);

-- Notifications indexes
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON public.notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON public.notifications(read);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON public.notifications(created_at);

-- Whiteboards indexes
CREATE INDEX IF NOT EXISTS idx_whiteboards_workspace_id ON public.whiteboards(workspace_id);
CREATE INDEX IF NOT EXISTS idx_whiteboards_channel_id ON public.whiteboards(channel_id);
CREATE INDEX IF NOT EXISTS idx_whiteboards_created_by ON public.whiteboards(created_by);

-- =====================================================
-- REALTIME SUBSCRIPTIONS
-- =====================================================

-- Enable realtime for key tables
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.notes;
ALTER PUBLICATION supabase_realtime ADD TABLE public.whiteboards;
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.channels;
ALTER PUBLICATION supabase_realtime ADD TABLE public.action_items;

-- =====================================================
-- INITIAL DATA
-- =====================================================

-- Create default workspace
INSERT INTO public.workspaces (name, description, brand_color) 
VALUES ('WAVE AI Workspace', 'Default workspace for WAVE AI collaboration platform', '#6B46C1')
ON CONFLICT (name) DO NOTHING;
