// Authentication Types
export interface User {
  id: string;
  email: string;
  username: string;
  full_name: string;
  avatar_url?: string;
  status: 'online' | 'away' | 'offline';
  created_at: string;
}

export interface AuthResponse {
  user: User;
  token: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface SignupRequest {
  email: string;
  password: string;
  username: string;
  full_name: string;
}

// Workspace Types
export interface Workspace {
  id: string;
  name: string;
  created_by: string;
  created_at: string;
  trial_ends_at?: string;
}

// Channel Types
export interface Channel {
  id: string;
  name: string;
  workspace_id: string;
  created_by: string;
  created_at: string;
  is_private: boolean;
  description?: string;
}

export interface ChannelMember {
  channel_id: string;
  user_id: string;
  joined_at: string;
  role: 'member' | 'admin';
}

// Message Types
export interface Message {
  id: string;
  sender_id: string;
  channel_id?: string;
  receiver_id?: string;
  content: string;
  type: 'text' | 'file' | 'image' | 'audio' | 'video';
  file_url?: string;
  is_edited: boolean;
  created_at: string;
  updated_at: string;
  sender?: User;
  reactions?: Reaction[];
}

export interface Reaction {
  id: string;
  message_id: string;
  user_id: string;
  emoji: string;
  created_at: string;
  user?: User;
}

// Direct Messages
export interface DirectMessage {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  type: 'text' | 'file' | 'image' | 'audio' | 'video';
  file_url?: string;
  is_edited: boolean;
  created_at: string;
  updated_at: string;
  sender?: User;
  receiver?: User;
}

// To-do Types
export interface Todo {
  id: string;
  user_id: string;
  content: string;
  completed: boolean;
  created_at: string;
  updated_at: string;
}

// Notification Types
export interface Notification {
  id: string;
  user_id: string;
  type: 'mention' | 'dm' | 'invite' | 'channel_add';
  title: string;
  message: string;
  read: boolean;
  created_at: string;
  related_id?: string; // message_id, channel_id, etc.
}

// API Response Types
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  page: number;
  limit: number;
  total: number;
  has_more: boolean;
}

// Request Types
export interface SendMessageRequest {
  content: string;
  channel_id?: string;
  receiver_id?: string;
  type?: 'text' | 'file' | 'image' | 'audio' | 'video';
  file_url?: string;
}

export interface CreateChannelRequest {
  name: string;
  workspace_id: string;
  description?: string;
  is_private?: boolean;
}

export interface UpdateProfileRequest {
  username?: string;
  full_name?: string;
  avatar_url?: string;
  status?: 'online' | 'away' | 'offline';
}

export interface CreateTodoRequest {
  content: string;
}

export interface UpdateTodoRequest {
  content?: string;
  completed?: boolean;
}

// Search Types
export interface SearchRequest {
  query: string;
  type?: 'messages' | 'channels' | 'users' | 'all';
  workspace_id?: string;
  limit?: number;
}

export interface SearchResult {
  type: 'message' | 'channel' | 'user';
  id: string;
  title: string;
  content: string;
  avatar_url?: string;
  created_at: string;
}
